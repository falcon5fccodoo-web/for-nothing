# ViperCryo verification and kit claims

## Requirements and data

- Node.js 22.13 or newer is required for the built-in `node:sqlite` module.
- The bot stores verification settings, IGN links, kit definitions, claim records, and audit events in `vipercryoverification.sqlite` beside the bot. This is separate from `coins.json`; existing economy data is not migrated or overwritten.
- Set `VERIFICATION_DB_PATH` in `.env` only if you want the SQLite file at a different location.
- Verification panel images uploaded with `/verification setup` or `/verification edit` are limited to 8 MB and supported formats are PNG, JPG, GIF, and WebP. The bot stores a validated local copy in `vipercryoverification-assets` beside the database so it can republish the image after a restart. Back up that folder along with the SQLite database.
- A submitted Minecraft IGN is format-checked and checked for duplicate registrations in this bot. The bot does **not** prove that the Discord member owns that Minecraft account.
- `/claim` creates a persistent claim record and can notify the configured log channel. It does not deliver an in-game kit. Staff must arrange any delivery separately.
- `!viper claim` uses the Minecraft chat event's sender name to find the existing IGN mapping and then checks the linked Discord account's current Verified role. Players without a confirmed mapping and Verified role are directed to `https://discord.gg/Wv9esffV95` to verify before claiming. The mapping remains username-only and does not prove Minecraft account ownership; usernames can be impersonated on servers that do not authenticate them. The command fails closed if Discord or the SQLite database cannot confirm the link and role.

## Discord setup

1. In the Discord Developer Portal, enable the **Server Members Intent** under Bot → Privileged Gateway Intents. The bot uses it to assign the Unverified role when a member joins.
2. Invite/update the bot with these permissions:
   - View Channels
   - Send Messages
   - Embed Links
   - Use Application Commands
   - Manage Roles
   - Manage Nicknames
3. In Server Settings → Roles, move the bot's role above both the Unverified and Verified roles. Role changes and nickname changes can still fail if Discord hierarchy or member-specific permissions prevent them.
4. Configure channel overwrites yourself. A common private-server arrangement denies `@everyone` access to normal channels, allows the Unverified role to view the verification channel, and grants normal access to the Verified role. Explicitly allow any channels that should remain visible before verification. The bot does not rewrite existing channel permissions.
5. In PowerShell, register slash commands for the server containing the configured `DISCORD_CHANNEL_ID`:

   ```powershell
   cd "C:\Users\Mahfuz\Desktop\ViperCryo bot"
   npm run register:commands
   ```

   The script resolves that channel's server and updates only `/verification`, `/kit`, and `/claim`; it preserves other commands registered by this application. To target another server, pass its ID: `npm run register:commands -- 123456789012345678`.
6. Start the bot:

   ```powershell
   npm start
   ```

   The bot also syncs these commands to each server it is in when it starts. Keep the process running.

## Configure verification

As a server administrator, run `/verification setup` and choose:

- A text verification channel
- Unverified and Verified roles
- Panel title, instructions, hex color such as `#7B2CBF`, and button label
- A private success message; `{ign}` is replaced with the submitted username
- Optional image attachment for the embed. To change it later, upload a replacement with `/verification edit`; choose `remove_image:true` to remove the current image.
- Optional log channel
- Whether members must verify again or retain verification after leaving and rejoining

The bot posts a persistent Verify button. Members click it, enter a 3–16 character Minecraft username, and receive the configured Verified role. The bot removes the Unverified role and sets that member's **server nickname** to the Minecraft IGN; this does not change their global Discord username. If Discord blocks the change, verification remains saved and the member is told to ask an administrator to grant the bot Manage Nicknames and move its role above the member's highest role.

Use `/verification edit` to change settings and republish the panel, `/verification config` to inspect settings, and `/verification status` to view counts or an optional member's status. `/verification reset user` resets a member's verification; `/verification reset all confirm:true` resets every member's verification and removes configured verification roles where possible; `/verification reset-ign` releases an IGN. Verification reset operations preserve kit history and configuration. Reset-all requires explicit confirmation.

## Kits

- Administrators create a record with `/kit create`. A global claim limit of `0` means unlimited.
- Use `/kit edit`, `/kit delete`, and `/kit list` to manage definitions.
- Verified members run `/claim kit:<name>`. Each Discord account can claim a kit once; the database also enforces the optional server-wide limit.
- `/kit logs` displays recent claim records. `/kit reset-user` clears one member's records. `/kit reset-all confirm:true` clears all claim records in that server and requires explicit confirmation.
- To enable `!viper claim`, create and enable the selected kit using `/kit create` and ensure a Shulker Box is in the bot's supported nearby chest/barrel storage. `VIPER_CLAIM_KIT` (default `PVP`) selects a kit from the existing `KIT_RULES`; the corresponding `/kit` record controls one-time and global limits. `VIPER_CLAIM_SEARCH_RADIUS_BLOCKS` controls the loaded-block search radius (default `32`, accepted range `1`–`128`). The bot scans supported loaded chests, trapped chests, and barrels in that radius, including both blocks of double chests. Within each chest it prefers the configured kit color, otherwise it withdraws the first Shulker Box found, confirms exactly one is in inventory, and immediately stops searching other chests. Logs include candidate coordinates, canonical item names/IDs, counts, metadata, and match decisions. Chest access, movement, and withdrawal errors are logged; each opened container is closed in a `finally` block. If access fails, it reports that no kit was taken. The bot requests TPA only after exactly one Shulker Box is confirmed in its inventory, requires a detected teleport countdown and confirms that it moved near that player, then drops exactly one box. Only a successfully dropped kit is counted. If delivery fails while the Shulker is still confirmed in the bot's inventory, the pending reservation is released and the player can retry without being counted. If the drop outcome is uncertain, the reservation remains to prevent duplicates; inspect the bot inventory and delivery state before an administrator uses `/kit reset-user` to release it.
- Every verified player, including GodMahfuz, can complete `!viper claim` only once per Discord account. There is no repeat-claim exception for this command. An outstanding reservation blocks another attempt until an administrator confirms the bot inventory/delivery state and resolves it with `/kit reset-user`.
- `VIPER_CLAIM_KILL_ENABLED` defaults to `true`. Immediately after a successful one-item Shulker drop and persistent claim record, the bot sends `/kill` as its own command; set it to `false` in the bot environment to disable this. The Minecraft server must permit the bot to use that command.

Example non-secret settings (add them to `.env` and restart the bot):

```dotenv
VIPER_CLAIM_KIT=PVP
VIPER_CLAIM_SEARCH_RADIUS_BLOCKS=32
VIPER_CLAIM_KILL_ENABLED=true
VIPER_RESPAWN_AUTHORIZED_USERNAME=GodMahfuz
VIPER_RESPAWN_RADIUS_BLOCKS=20
```

`VIPER_RESPAWN_RADIUS_BLOCKS` must be an integer from 1 to 128.

## In-game respawn command

- `!viper set resspwan` is restricted to `VIPER_RESPAWN_AUTHORIZED_USERNAME` (case-insensitive); `!viper set respawn` remains an alias.
- The bot searches for a paired bed within the configured radius of the authorized sender's current position, walks to it using the existing pathfinder, and activates it to set the **bot's own** respawn point. It reports success only when the server sends a respawn-point confirmation. This does not change the authorized player's respawn point.

## Data and operations

Back up `vipercryoverification.sqlite` while the bot is stopped (or use SQLite's online backup tools). Do not delete it to reset only one user's state; use the administrator reset commands. Configure the database file's access so only trusted operators can read it.
