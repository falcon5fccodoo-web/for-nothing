'use strict'

function getMatchingShulkerTypeIds(kitName, kitRules, itemsByName) {
  const rule = kitRules[kitName]
  if (!rule) return new Set()

  if (rule.anyShulker) return getAllShulkerTypeIds(itemsByName)

  let itemName
  if (rule.exactName) itemName = rule.exactName
  else if (rule.colorKeyword) itemName = rule.colorKeyword + '_shulker_box'
  if (!itemName) return new Set()

  const item = itemsByName[itemName]
  return item && Number.isInteger(item.id) ? new Set([item.id]) : new Set()
}

function getAllShulkerTypeIds(itemsByName) {
  return new Set(Object.entries(itemsByName)
    .filter(([name, item]) => name.endsWith('shulker_box') && item && Number.isInteger(item.id))
    .map(([, item]) => item.id))
}

function matchesKitShulker(item, kitName, kitRules, itemsByName) {
  if (!item || !Number.isInteger(item.type)) return false
  return getMatchingShulkerTypeIds(kitName, kitRules, itemsByName).has(item.type)
}

function isShulkerBox(item, itemsByName) {
  if (!item || !Number.isInteger(item.type)) return false
  return getAllShulkerTypeIds(itemsByName).has(item.type)
}

function inventoryItemCount(bot, itemType) {
  return bot.inventory.items()
    .filter(item => item.type === itemType)
    .reduce((count, item) => count + item.count, 0)
}

function waitForInventoryItemCount(bot, itemType, expectedCount, timeoutMs) {
  if (inventoryItemCount(bot, itemType) >= expectedCount) return Promise.resolve(true)

  return new Promise(resolve => {
    let settled = false
    const inventory = bot.inventory
    const finish = confirmed => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      if (inventory && typeof inventory.removeListener === 'function') {
        inventory.removeListener('updateSlot', checkInventory)
      }
      resolve(confirmed)
    }
    const checkInventory = () => {
      if (inventoryItemCount(bot, itemType) >= expectedCount) finish(true)
    }
    const timer = setTimeout(() => finish(false), timeoutMs)

    if (inventory && typeof inventory.on === 'function') {
      inventory.on('updateSlot', checkInventory)
    }
    checkInventory()
  })
}

function chestDescription(block) {
  return block && block.name ? block.name : 'unknown container'
}

function withTimeout(promise, timeoutMs, message, onTimeout) {
  let timer
  return Promise.race([
    promise,
    new Promise((resolve, reject) => {
      timer = setTimeout(() => {
        if (onTimeout) onTimeout()
        reject(new Error(message))
      }, timeoutMs)
    })
  ]).finally(() => clearTimeout(timer))
}

async function openContainerWithTimeout(bot, block, timeoutMs, log) {
  const existingListeners = new Set(bot.rawListeners('windowOpen'))
  const opening = bot.openContainer(block)
  const pendingListeners = bot.rawListeners('windowOpen')
    .filter(listener => !existingListeners.has(listener))
  let timedOut = false
  const closeLateWindow = window => {
    if (!timedOut) {
      bot.removeListener('windowOpen', closeLateWindow)
      return
    }
    bot.removeListener('windowOpen', closeLateWindow)
    try {
      Promise.resolve(bot.closeWindow(window)).catch(error => {
        log('[CLAIM] Could not close a chest window opened after timeout: ' + error.message)
      })
    } catch (error) {
      log('[CLAIM] Could not close a chest window opened after timeout: ' + error.message)
    }
  }
  bot.on('windowOpen', closeLateWindow)
  const removePendingListeners = () => {
    for (const listener of pendingListeners) bot.removeListener('windowOpen', listener)
  }

  opening.then(container => {
    bot.removeListener('windowOpen', closeLateWindow)
    if (!timedOut) return
    try {
      container.close()
    } catch (error) {
      log('[CLAIM] Could not close a chest that opened after timeout: ' + error.message)
    }
  }).catch(() => {
    bot.removeListener('windowOpen', closeLateWindow)
    removePendingListeners()
  })

  return withTimeout(opening, timeoutMs, 'Timed out waiting for the chest to open.', () => {
    timedOut = true
    removePendingListeners()
  })
}

async function findAndWithdrawKitShulker(options) {
  const {
    bot,
    kitName,
    kitRules,
    searchRadius,
    log = () => {},
    onProgress = async () => {},
    sleep = ms => new Promise(resolve => setTimeout(resolve, ms)),
    walkTimeoutMs = 15000,
    openTimeoutMs = 10000,
    withdrawTimeoutMs = 12000,
    inventoryConfirmTimeoutMs = 8000
  } = options
  const itemRegistry = bot.registry.itemsByName
  const matchingTypes = getMatchingShulkerTypeIds(kitName, kitRules, itemRegistry)
  const allShulkerTypes = getAllShulkerTypeIds(itemRegistry)
  const inventoryShulkers = bot.inventory.items().filter(item => allShulkerTypes.has(item.type))
  const inventoryCandidate = inventoryShulkers.find(item => matchingTypes.has(item.type)) || inventoryShulkers[0]
  if (inventoryCandidate) {
    const baselineCount = inventoryItemCount(bot, inventoryCandidate.type) - 1
    log('[CLAIM] Reusing one existing inventory Shulker Box item id=' + inventoryCandidate.type +
      ' name=' + inventoryCandidate.name + ' count=' + inventoryCandidate.count +
      ' for ' + kitName + '; skipping chest search.')
    await onProgress('Found a Shulker Box in my inventory; skipping chest search.')
    return {
      ok: true,
      type: inventoryCandidate.type,
      name: inventoryCandidate.name,
      baselineCount
    }
  }

  const blockTypes = ['chest', 'trapped_chest', 'barrel']
    .map(name => bot.registry.blocksByName[name])
    .filter(block => block && Number.isInteger(block.id))
    .map(block => block.id)
  log('[CLAIM] Starting loaded storage-block search within ' + searchRadius + ' blocks for kit ' + kitName + '.')
  await onProgress('Starting nearby chest search (' + searchRadius + '-block radius)...')
  if (blockTypes.length === 0) {
    log('[CLAIM] Active Minecraft block registry has no chest, trapped chest, or barrel IDs.')
    return { ok: false, reason: 'no_storage_blocks_in_registry' }
  }
  const positions = bot.findBlocks({
    matching: blockTypes,
    maxDistance: searchRadius,
    count: Number.MAX_SAFE_INTEGER
  })

  log('[CLAIM] Found ' + positions.length + ' supported storage blocks within ' + searchRadius + ' blocks.')
  await onProgress('Found ' + positions.length + ' nearby chests/barrels. Checking storage now...')
  if (positions.length === 0) return { ok: false, reason: 'no_chest' }
  if (matchingTypes.size === 0) {
    log('[CLAIM] Kit rule ' + kitName + ' does not resolve to a shulker item in the active Minecraft registry.')
    return { ok: false, reason: 'invalid_kit_rule' }
  }

  let inspectedCount = 0
  let accessFailureCount = 0
  let index = 0
  for (const position of positions) {
    index++
    const block = bot.blockAt(position)
    const coordinates = position.toString()
    if (!block) {
      accessFailureCount++
      log('[CLAIM] Skipping unloaded storage block at ' + coordinates + '.')
      continue
    }

    let container = null
    try {
      const distance = bot.entity.position.distanceTo(block.position.offset(0.5, 0.5, 0.5))
      if (distance > 6) {
        await onProgress('Walking to storage ' + index + ' of ' + positions.length + '...')
        log('[CLAIM] Walking ' + distance.toFixed(1) + ' blocks to ' + chestDescription(block) + ' at ' + coordinates + '.')
        if (!bot.pathfinder || !options.goals) {
          log('[CLAIM] Cannot reach storage at ' + coordinates + ': pathfinder is unavailable.')
          accessFailureCount++
          continue
        }
        if (bot.physicsEnabled === false) {
          log('[CLAIM] Enabling physics before navigating to storage.')
          bot.physicsEnabled = true
        }
        await withTimeout(
          bot.pathfinder.goto(new options.goals.GoalNear(block.position.x, block.position.y, block.position.z, 4)),
          walkTimeoutMs,
          'Timed out walking to storage at ' + coordinates + '.',
          () => bot.pathfinder.stop()
        )
      }

      await onProgress('Opening storage ' + index + ' of ' + positions.length + '...')
      log('[CLAIM] Opening ' + chestDescription(block) + ' at ' + coordinates + '.')
      container = await openContainerWithTimeout(bot, block, openTimeoutMs, log)
      inspectedCount++
      const containerItems = typeof container.containerItems === 'function'
        ? container.containerItems()
        : Number.isInteger(container.inventoryStart)
          ? container.slots.slice(0, container.inventoryStart).filter(Boolean)
          : null
      if (!containerItems) {
        accessFailureCount++
        log('[CLAIM] Container at ' + coordinates + ' did not expose valid container slots.')
        continue
      }

      for (const item of containerItems) {
        const matchesKit = matchingTypes.has(item.type)
        const matchesShulker = allShulkerTypes.has(item.type)
        log('[CLAIM] ' + coordinates + ' item id=' + item.type +
          ' name=' + (item.name || 'unknown') +
          ' count=' + item.count +
          ' metadata=' + (item.metadata == null ? 'none' : item.metadata) +
          (matchesKit ? ' accepted as configured ' + kitName + ' kit item.' :
            matchesShulker ? ' valid Shulker Box candidate.' :
              ' rejected; not a Shulker Box.'))
        if (!matchesShulker) continue

        const before = inventoryItemCount(bot, item.type)
        const candidateType = item.type
        const candidateName = item.name
        let withdrawalError = null
        try {
          await withTimeout(
            container.withdraw(candidateType, null, 1),
            withdrawTimeoutMs,
            'Timed out withdrawing item id=' + candidateType + ' from ' + coordinates + '.'
          )
        } catch (error) {
          withdrawalError = error
        }

        let containerClosed = true
        try {
          await container.close()
          container = null
        } catch (error) {
          containerClosed = false
          log('[CLAIM] Could not close storage after withdrawal at ' + coordinates + ': ' + error.message)
        }

        if (withdrawalError) {
          const afterError = inventoryItemCount(bot, candidateType)
          log('[CLAIM] Withdrawal failed for item id=' + candidateType + ' at ' + coordinates +
            ': ' + withdrawalError.message + '; inventory count ' + before + ' -> ' + afterError + '.')
          if (afterError !== before || !containerClosed) {
            return { ok: false, reason: 'withdraw_uncertain', reservationMustRemain: true }
          }
          if (/destination full|inventory full|no space/i.test(withdrawalError.message)) {
            return { ok: false, reason: 'withdraw_failed', error: withdrawalError.message }
          }
          return {
            ok: false,
            reason: 'withdraw_uncertain',
            reservationMustRemain: true,
            error: withdrawalError.message
          }
        }

        const after = inventoryItemCount(bot, candidateType)
        if (!containerClosed) {
          return { ok: false, reason: 'withdraw_uncertain', reservationMustRemain: true }
        }
        if (after !== before + 1) {
          await waitForInventoryItemCount(bot, candidateType, before + 1, inventoryConfirmTimeoutMs)
        }
        const confirmedCount = inventoryItemCount(bot, candidateType)
        if (confirmedCount === before + 1) {
          log('[CLAIM] Confirmed exactly one Shulker Box item id=' + candidateType +
            ' (' + candidateName + ') withdrawn from ' + coordinates + '. Stopping chest search.')
          if (!matchesKit) {
            log('[CLAIM] Used the first available Shulker Box because the configured ' + kitName + ' color was not in this chest.')
          }
          return {
            ok: true,
            type: candidateType,
            name: candidateName,
            baselineCount: before
          }
        }
        log('[CLAIM] Could not confirm exactly one item id=' + candidateType +
          ' withdrawn from ' + coordinates + '; inventory count ' + before + ' -> ' + confirmedCount +
          ' after waiting ' + inventoryConfirmTimeoutMs + 'ms for inventory synchronization.')
        return {
          ok: false,
          reason: 'withdraw_uncertain',
          reservationMustRemain: true
        }
      }
      log('[CLAIM] No Shulker Box found in ' + chestDescription(block) + ' at ' + coordinates + '.')
    } catch (error) {
      accessFailureCount++
      log('[CLAIM] Could not inspect storage at ' + coordinates + ': ' + error.message)
      if (/timed out/i.test(error.message)) {
        continue
      }
    } finally {
      if (container) {
        try {
          await container.close()
        } catch (error) {
          log('[CLAIM] Could not close storage at ' + coordinates + ': ' + error.message)
        }
      }
    }
  }

  if (accessFailureCount > 0) {
    return {
      ok: false,
      reason: inspectedCount > 0 ? 'partial_access' : 'access_failed'
    }
  }
  return { ok: false, reason: 'not_found' }
}

module.exports = {
  findAndWithdrawKitShulker,
  getMatchingShulkerTypeIds,
  isShulkerBox,
  matchesKitShulker
}
