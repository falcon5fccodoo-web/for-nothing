'use strict'

require('dotenv').config()

const { REST, Routes } = require('discord.js')
const { buildCommands } = require('./verification-system')

const token = process.env.DISCORD_TOKEN || ''
const requestedId = process.argv[2] || ''
const configuredChannelId = process.env.DISCORD_CHANNEL_ID || ''

if (!token) {
  console.error('DISCORD_TOKEN is required. Set it in .env before registering commands.')
  process.exit(1)
}
if (requestedId && !/^\d{17,20}$/.test(requestedId)) {
  console.error('Usage: node .\\register-commands.js [discord-guild-id]')
  process.exit(1)
}

const applicationId = Buffer.from(token.split('.')[0], 'base64url').toString('utf8')
if (!/^\d{17,20}$/.test(applicationId)) {
  console.error('Could not determine the Discord application ID from DISCORD_TOKEN.')
  process.exit(1)
}

async function main() {
  const rest = new REST({ version: '10' }).setToken(token)
  let guildId = requestedId
  if (!guildId) {
    if (!/^\d{17,20}$/.test(configuredChannelId)) {
      throw new Error('Provide a guild ID or configure DISCORD_CHANNEL_ID in .env.')
    }
    const channel = await rest.get(Routes.channel(configuredChannelId))
    guildId = channel && channel.guild_id
    if (!/^\d{17,20}$/.test(guildId || '')) throw new Error('DISCORD_CHANNEL_ID must point to a server text channel.')
  }
  const route = Routes.applicationGuildCommands(applicationId, guildId)
  const existing = await rest.get(route)
  const byName = new Map(existing.map(command => [command.name, command]))
  for (const command of buildCommands()) {
    const current = byName.get(command.name)
    if (current) {
      await rest.patch(Routes.applicationGuildCommand(applicationId, guildId, current.id), { body: command })
      console.log('Updated /' + command.name)
    } else {
      await rest.post(route, { body: command })
      console.log('Registered /' + command.name)
    }
  }
  console.log('Slash commands are ready for guild ' + guildId + '.')
}

main().catch(error => {
  console.error('Could not register slash commands:', error.message)
  process.exitCode = 1
})
