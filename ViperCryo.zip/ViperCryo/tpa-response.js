'use strict'

function parseTpaResponse(message) {
  const text = String(message || '')
    .replace(/§[0-9a-fk-or]/gi, '')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase()
  if (!text) return null

  if (/teleport request.{0,40}(?:denied|cancelled|canceled|expired)|cannot teleport|not online|too many teleport requests/.test(text)) {
    return { type: 'rejected' }
  }

  const countdown = text.match(/(?:teleporting|teleport(?:ation)?(?:\s+will)?|you will be teleported)\s+(?:in\s+)?(\d+)\s+seconds?/i)
  if (countdown) return { type: 'countdown', seconds: Number(countdown[1]) }

  if (/your request sent to .{1,40} was accepted|(?:\w+ )?(?:has )?accepted your (?:(?:teleport|tpa) )?request|(?:teleport|tpa) request (?:was )?accepted|teleport(?:ation)? (?:request )?(?:was )?(?:accepted|successful|complete|completed)|successfully teleported|teleported to\b/.test(text)) {
    return { type: 'accepted' }
  }

  return null
}

module.exports = { parseTpaResponse }
