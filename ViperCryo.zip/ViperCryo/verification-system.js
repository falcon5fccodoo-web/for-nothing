'use strict'

const path = require('path')
const fs = require('fs')
const crypto = require('crypto')
const axios = require('axios')
const { DatabaseSync } = require('node:sqlite')
const {
  ActionRowBuilder,
  AttachmentBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  EmbedBuilder,
  MessageFlags,
  ModalBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js')

const DB_PATH = process.env.VERIFICATION_DB_PATH
  ? path.resolve(process.env.VERIFICATION_DB_PATH)
  : path.join(__dirname, 'vipercryoverification.sqlite')
const ASSET_DIR = process.env.VERIFICATION_ASSET_DIR
  ? path.resolve(process.env.VERIFICATION_ASSET_DIR)
  : path.join(__dirname, 'vipercryoverification-assets')
const MAX_IMAGE_BYTES = 8 * 1024 * 1024
const IMAGE_TYPES = new Map([
  ['image/png', { extension: 'png', signature: buffer => buffer.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10])) }],
  ['image/jpeg', { extension: 'jpg', signature: buffer => buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff }],
  ['image/gif', { extension: 'gif', signature: buffer => ['GIF87a', 'GIF89a'].includes(buffer.subarray(0, 6).toString('ascii')) }],
  ['image/webp', { extension: 'webp', signature: buffer => buffer.subarray(0, 4).toString('ascii') === 'RIFF' && buffer.subarray(8, 12).toString('ascii') === 'WEBP' }]
])
const IGN_PATTERN = /^[A-Za-z0-9_]{3,16}$/
const KIT_PATTERN = /^[A-Za-z0-9_-]{1,32}$/
const VERIFY_BUTTON_ID = 'viper:verification:open'
const VERIFY_MODAL_ID = 'viper:verification:submit'
const COLOR_PATTERN = /^#[0-9a-fA-F]{6}$/

async function downloadDiscordImage(url) {
  const response = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 15000,
    maxContentLength: MAX_IMAGE_BYTES,
    maxBodyLength: MAX_IMAGE_BYTES,
    maxRedirects: 0
  })
  return Buffer.from(response.data)
}

async function saveUploadedImage(attachment, assetDir = ASSET_DIR, download = downloadDiscordImage) {
  if (!attachment || !attachment.contentType) {
    throw new Error('Upload a PNG, JPG, GIF, or WebP image with a recognized image type.')
  }
  const mimeType = attachment.contentType.split(';')[0].trim().toLowerCase()
  const imageType = IMAGE_TYPES.get(mimeType)
  if (!imageType) throw new Error('Only PNG, JPG, GIF, and WebP images are supported.')
  if (attachment.size > MAX_IMAGE_BYTES) throw new Error('The verification image must be 8 MB or smaller.')
  const url = new URL(attachment.url)
  if (url.protocol !== 'https:' || !['cdn.discordapp.com', 'media.discordapp.net'].includes(url.hostname)) {
    throw new Error('The image must be uploaded directly to Discord.')
  }
  const image = await download(url.toString())
  if (!image.length || image.length > MAX_IMAGE_BYTES || !imageType.signature(image)) {
    throw new Error('The uploaded file is not a valid ' + mimeType + ' image or exceeds the 8 MB limit.')
  }
  fs.mkdirSync(assetDir, { recursive: true })
  const fileName = crypto.randomUUID() + '.' + imageType.extension
  const finalPath = path.join(assetDir, fileName)
  const tempPath = finalPath + '.tmp'
  try {
    fs.writeFileSync(tempPath, image, { flag: 'wx' })
    fs.renameSync(tempPath, finalPath)
  } catch (error) {
    if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath)
    throw error
  }
  return fileName
}
function buildCommands() {
  const verification = new SlashCommandBuilder()
    .setName('verification')
    .setDescription('Configure and manage ViperCryo server verification')
    .addSubcommand(subcommand => subcommand
      .setName('setup')
      .setDescription('Set up verification for this server')
      .addChannelOption(option => option.setName('channel').setDescription('Channel for the verification panel').addChannelTypes(ChannelType.GuildText).setRequired(true))
      .addRoleOption(option => option.setName('unverified_role').setDescription('Role given to members who need verification').setRequired(true))
      .addRoleOption(option => option.setName('verified_role').setDescription('Role given after verification').setRequired(true))
      .addStringOption(option => option.setName('title').setDescription('Verification embed title').setMaxLength(256).setRequired(true))
      .addStringOption(option => option.setName('description').setDescription('Instructions shown in the verification panel').setMaxLength(4000).setRequired(true))
      .addStringOption(option => option.setName('color').setDescription('Embed color in #RRGGBB format').setMinLength(7).setMaxLength(7).setRequired(true))
      .addStringOption(option => option.setName('button_label').setDescription('Verify button label').setMaxLength(80).setRequired(true))
      .addStringOption(option => option.setName('success_message').setDescription('Private success message; {ign} is replaced with the IGN').setMaxLength(1000).setRequired(true))
      .addAttachmentOption(option => option.setName('image').setDescription('Optional image displayed in the verification embed'))
      .addChannelOption(option => option.setName('log_channel').setDescription('Optional verification and claim log channel').addChannelTypes(ChannelType.GuildText))
      .addStringOption(option => option.setName('rejoin_policy').setDescription('Whether previously verified members must verify again').addChoices(
        { name: 'Require verification again', value: 'reverify' },
        { name: 'Retain verification', value: 'retain' }
      )))
    .addSubcommand(subcommand => subcommand
      .setName('edit')
      .setDescription('Edit verification settings and refresh the panel')
      .addChannelOption(option => option.setName('channel').setDescription('Verification panel channel').addChannelTypes(ChannelType.GuildText))
      .addRoleOption(option => option.setName('unverified_role').setDescription('Unverified member role'))
      .addRoleOption(option => option.setName('verified_role').setDescription('Verified member role'))
      .addStringOption(option => option.setName('title').setDescription('Embed title').setMaxLength(256))
      .addStringOption(option => option.setName('description').setDescription('Embed instructions').setMaxLength(4000))
      .addAttachmentOption(option => option.setName('image').setDescription('Upload a replacement image for the verification embed'))
      .addBooleanOption(option => option.setName('remove_image').setDescription('Remove the current embed image'))
      .addStringOption(option => option.setName('color').setDescription('Embed color in #RRGGBB format').setMinLength(7).setMaxLength(7))
      .addStringOption(option => option.setName('button_label').setDescription('Verify button label').setMaxLength(80))
      .addStringOption(option => option.setName('success_message').setDescription('Private success message; {ign} is replaced with the IGN').setMaxLength(1000))
      .addChannelOption(option => option.setName('log_channel').setDescription('Optional log channel'))
      .addBooleanOption(option => option.setName('clear_log_channel').setDescription('Remove the configured log channel'))
      .addStringOption(option => option.setName('rejoin_policy').setDescription('Rejoin verification policy').addChoices(
        { name: 'Require verification again', value: 'reverify' },
        { name: 'Retain verification', value: 'retain' }
      )))
    .addSubcommand(subcommand => subcommand.setName('status').setDescription('Show verification status and member counts')
      .addUserOption(option => option.setName('user').setDescription('Optional member to inspect')))
    .addSubcommand(subcommand => subcommand.setName('config').setDescription('Show verification configuration for this server'))
    .addSubcommandGroup(group => group.setName('reset').setDescription('Reset verification data')
      .addSubcommand(subcommand => subcommand.setName('user').setDescription('Reset one member’s verification')
        .addUserOption(option => option.setName('member').setDescription('Member to reset').setRequired(true)))
      .addSubcommand(subcommand => subcommand.setName('all').setDescription('Reset all verification records and roles (requires confirmation)')
        .addBooleanOption(option => option.setName('confirm').setDescription('Confirm resetting all verification records').setRequired(true))))
    .addSubcommand(subcommand => subcommand.setName('reset-ign').setDescription('Release a Minecraft IGN registration')
      .addStringOption(option => option.setName('ign').setDescription('Minecraft username to release').setMinLength(3).setMaxLength(16).setRequired(true)))

  const kit = new SlashCommandBuilder()
    .setName('kit')
    .setDescription('Manage one-time kit claim records')
    .addSubcommand(subcommand => subcommand.setName('create').setDescription('Create a claimable kit')
      .addStringOption(option => option.setName('name').setDescription('Kit name').setMinLength(1).setMaxLength(32).setRequired(true))
      .addStringOption(option => option.setName('description').setDescription('What the kit claim represents').setMaxLength(1000).setRequired(true))
      .addBooleanOption(option => option.setName('available').setDescription('Allow members to claim this kit').setRequired(true))
      .addIntegerOption(option => option.setName('global_limit').setDescription('Maximum claims server-wide; 0 means unlimited').setMinValue(0).setRequired(true)))
    .addSubcommand(subcommand => subcommand.setName('edit').setDescription('Edit a kit’s claim settings')
      .addStringOption(option => option.setName('name').setDescription('Kit name to edit').setMinLength(1).setMaxLength(32).setRequired(true))
      .addStringOption(option => option.setName('description').setDescription('New description').setMaxLength(1000))
      .addBooleanOption(option => option.setName('available').setDescription('Allow or pause claims'))
      .addIntegerOption(option => option.setName('global_limit').setDescription('Maximum claims server-wide; 0 means unlimited').setMinValue(0)))
    .addSubcommand(subcommand => subcommand.setName('delete').setDescription('Disable and remove a kit from the claim list')
      .addStringOption(option => option.setName('name').setDescription('Kit name').setMinLength(1).setMaxLength(32).setRequired(true)))
    .addSubcommand(subcommand => subcommand.setName('list').setDescription('List kits available in this server'))
    .addSubcommand(subcommand => subcommand.setName('reset-user').setDescription('Reset one member’s claims and pending delivery for a kit')
      .addUserOption(option => option.setName('member').setDescription('Member whose claim to reset').setRequired(true))
      .addStringOption(option => option.setName('kit').setDescription('Kit name; omit to reset all this member’s claims').setMinLength(1).setMaxLength(32)))
    .addSubcommand(subcommand => subcommand.setName('reset-all').setDescription('Reset all claims and pending deliveries (requires explicit confirmation)')
      .addBooleanOption(option => option.setName('confirm').setDescription('Confirm permanently clearing all claim records').setRequired(true)))
    .addSubcommand(subcommand => subcommand.setName('logs').setDescription('Show recent kit claim records')
      .addStringOption(option => option.setName('kit').setDescription('Optional kit name to filter').setMinLength(1).setMaxLength(32))
      .addIntegerOption(option => option.setName('limit').setDescription('Number of entries (1-20)').setMinValue(1).setMaxValue(20)))

  const claim = new SlashCommandBuilder()
    .setName('claim')
    .setDescription('Claim a configured kit once per Discord account')
    .addStringOption(option => option.setName('kit').setDescription('Configured kit name').setMinLength(1).setMaxLength(32).setRequired(true))

  return [verification, kit, claim].map(command => command.toJSON())
}

class VerificationStore {
  constructor(filePath = DB_PATH) {
    this.db = new DatabaseSync(filePath)
    this.db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;')
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS verification_config (
        guild_id TEXT PRIMARY KEY,
        channel_id TEXT NOT NULL,
        unverified_role_id TEXT NOT NULL,
        verified_role_id TEXT NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        color TEXT NOT NULL,
        button_label TEXT NOT NULL,
        success_message TEXT NOT NULL,
        log_channel_id TEXT,
        rejoin_policy TEXT NOT NULL DEFAULT 'reverify',
        panel_message_id TEXT,
        updated_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS verifications (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        ign TEXT NOT NULL,
        ign_key TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('verified', 'pending')),
        verified_at TEXT,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (guild_id, user_id),
        UNIQUE (guild_id, ign_key)
      );
      CREATE TABLE IF NOT EXISTS kits (
        guild_id TEXT NOT NULL,
        name TEXT NOT NULL,
        name_key TEXT NOT NULL,
        description TEXT NOT NULL,
        available INTEGER NOT NULL DEFAULT 1 CHECK(available IN (0, 1)),
        global_limit INTEGER NOT NULL DEFAULT 0 CHECK(global_limit >= 0),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (guild_id, name_key)
      );
      CREATE TABLE IF NOT EXISTS kit_claims (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        ign TEXT NOT NULL,
        kit_name TEXT NOT NULL,
        kit_key TEXT NOT NULL,
        claimed_at TEXT NOT NULL,
        UNIQUE (guild_id, user_id, kit_key)
      );
      CREATE TABLE IF NOT EXISTS kit_delivery_reservations (
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        ign TEXT NOT NULL,
        kit_name TEXT NOT NULL,
        kit_key TEXT NOT NULL,
        reserved_at TEXT NOT NULL,
        PRIMARY KEY (guild_id, user_id, kit_key)
      );
      CREATE TABLE IF NOT EXISTS kit_delivery_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        ign TEXT NOT NULL,
        kit_name TEXT NOT NULL,
        kit_key TEXT NOT NULL,
        claimed_at TEXT NOT NULL
      );
      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        actor_id TEXT NOT NULL,
        action TEXT NOT NULL,
        details TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
    `)
    const configColumns = new Set(this.db.prepare('PRAGMA table_info(verification_config)').all().map(column => column.name))
    if (!configColumns.has('image_path')) this.db.exec('ALTER TABLE verification_config ADD COLUMN image_path TEXT')
  }

  now() { return new Date().toISOString() }

  getConfig(guildId) {
    return this.db.prepare('SELECT * FROM verification_config WHERE guild_id = ?').get(guildId) || null
  }

  saveConfig(guildId, config) {
    const now = this.now()
    this.db.prepare(`
      INSERT INTO verification_config (
        guild_id, channel_id, unverified_role_id, verified_role_id, title, description,
        color, button_label, success_message, log_channel_id, rejoin_policy, panel_message_id, image_path, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET
        channel_id=excluded.channel_id, unverified_role_id=excluded.unverified_role_id,
        verified_role_id=excluded.verified_role_id, title=excluded.title,
        description=excluded.description, color=excluded.color, button_label=excluded.button_label,
        success_message=excluded.success_message, log_channel_id=excluded.log_channel_id,
        rejoin_policy=excluded.rejoin_policy, panel_message_id=excluded.panel_message_id,
        image_path=excluded.image_path,
        updated_at=excluded.updated_at
    `).run(
      guildId, config.channel_id, config.unverified_role_id, config.verified_role_id,
      config.title, config.description, config.color, config.button_label,
      config.success_message, config.log_channel_id || null, config.rejoin_policy || 'reverify',
      config.panel_message_id || null, config.image_path || null, now
    )
  }

  updatePanelMessage(guildId, messageId) {
    this.db.prepare('UPDATE verification_config SET panel_message_id = ?, updated_at = ? WHERE guild_id = ?')
      .run(messageId, this.now(), guildId)
  }

  getVerification(guildId, userId) {
    return this.db.prepare('SELECT * FROM verifications WHERE guild_id = ? AND user_id = ?').get(guildId, userId) || null
  }

  getIgnOwner(guildId, ign) {
    return this.db.prepare('SELECT user_id FROM verifications WHERE guild_id = ? AND ign_key = ?')
      .get(guildId, ign.toLowerCase()) || null
  }

  getVerificationByIgn(guildId, ign) {
    return this.db.prepare('SELECT * FROM verifications WHERE guild_id = ? AND ign_key = ?')
      .get(guildId, ign.toLowerCase()) || null
  }

  setVerified(guildId, userId, ign) {
    const ignKey = ign.toLowerCase()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const owner = this.getIgnOwner(guildId, ign)
      if (owner && owner.user_id !== userId) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'ign_taken' }
      }
      const now = this.now()
      this.db.prepare(`
        INSERT INTO verifications (guild_id, user_id, ign, ign_key, status, verified_at, updated_at)
        VALUES (?, ?, ?, ?, 'verified', ?, ?)
        ON CONFLICT(guild_id, user_id) DO UPDATE SET
          ign=excluded.ign, ign_key=excluded.ign_key, status='verified',
          verified_at=excluded.verified_at, updated_at=excluded.updated_at
      `).run(guildId, userId, ign, ignKey, now, now)
      this.db.exec('COMMIT')
      return { ok: true, verified_at: now }
    } catch (error) {
      this.db.exec('ROLLBACK')
      if (String(error.message).includes('UNIQUE constraint failed')) return { ok: false, error: 'ign_taken' }
      throw error
    }
  }

  markPending(guildId, userId) {
    this.db.prepare("UPDATE verifications SET status = 'pending', updated_at = ? WHERE guild_id = ? AND user_id = ?")
      .run(this.now(), guildId, userId)
  }

  deleteVerificationUser(guildId, userId) {
    return this.db.prepare('DELETE FROM verifications WHERE guild_id = ? AND user_id = ?').run(guildId, userId).changes > 0
  }

  resetAllVerifications(guildId) {
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const users = this.db.prepare('SELECT user_id FROM verifications WHERE guild_id = ?')
        .all(guildId).map(row => row.user_id).sort()
      const deleted = this.db.prepare('DELETE FROM verifications WHERE guild_id = ?').run(guildId).changes
      this.db.exec('COMMIT')
      return { users, deleted }
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  deleteVerificationIgn(guildId, ign) {
    return this.db.prepare('DELETE FROM verifications WHERE guild_id = ? AND ign_key = ?').run(guildId, ign.toLowerCase()).changes
  }

  verificationCounts(guildId) {
    return this.db.prepare(`
      SELECT COUNT(*) AS total, SUM(CASE WHEN status='verified' THEN 1 ELSE 0 END) AS verified,
             SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) AS pending
      FROM verifications WHERE guild_id = ?
    `).get(guildId)
  }

  createKit(guildId, name, description, available, globalLimit) {
    const now = this.now()
    this.db.prepare(`
      INSERT INTO kits (guild_id, name, name_key, description, available, global_limit, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(guildId, name, name.toLowerCase(), description, available ? 1 : 0, globalLimit, now, now)
  }

  getKit(guildId, name) {
    return this.db.prepare('SELECT * FROM kits WHERE guild_id = ? AND name_key = ?')
      .get(guildId, name.toLowerCase()) || null
  }

  listKits(guildId) {
    return this.db.prepare('SELECT * FROM kits WHERE guild_id = ? ORDER BY name_key').all(guildId)
  }

  editKit(guildId, name, changes) {
    const fields = []
    const values = []
    if (changes.description !== undefined) { fields.push('description = ?'); values.push(changes.description) }
    if (changes.available !== undefined) { fields.push('available = ?'); values.push(changes.available ? 1 : 0) }
    if (changes.global_limit !== undefined) { fields.push('global_limit = ?'); values.push(changes.global_limit) }
    if (!fields.length) return false
    fields.push('updated_at = ?')
    values.push(this.now(), guildId, name.toLowerCase())
    return this.db.prepare(`UPDATE kits SET ${fields.join(', ')} WHERE guild_id = ? AND name_key = ?`).run(...values).changes > 0
  }

  deleteKit(guildId, name) {
    return this.db.prepare('DELETE FROM kits WHERE guild_id = ? AND name_key = ?')
      .run(guildId, name.toLowerCase()).changes > 0
  }

  claimKit(guildId, userId, name) {
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const verification = this.getVerification(guildId, userId)
      if (!verification || verification.status !== 'verified') {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'not_verified' }
      }
      const kit = this.getKit(guildId, name)
      if (!kit || !kit.available) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'unavailable' }
      }
      const duplicate = this.db.prepare('SELECT 1 FROM kit_claims WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
        .get(guildId, userId, kit.name_key)
      if (duplicate) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'already_claimed' }
      }
      const reserved = this.db.prepare('SELECT 1 FROM kit_delivery_reservations WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
        .get(guildId, userId, kit.name_key)
      if (reserved) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'delivery_in_progress' }
      }
      const delivered = this.db.prepare('SELECT 1 FROM kit_delivery_history WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
        .get(guildId, userId, kit.name_key)
      if (delivered) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'already_claimed' }
      }
      const claimCount = this.db.prepare('SELECT COUNT(*) AS count FROM kit_claims WHERE guild_id = ? AND kit_key = ?')
        .get(guildId, kit.name_key).count
      const reservationCount = this.db.prepare('SELECT COUNT(*) AS count FROM kit_delivery_reservations WHERE guild_id = ? AND kit_key = ?')
        .get(guildId, kit.name_key).count
      const historyCount = this.db.prepare('SELECT COUNT(*) AS count FROM kit_delivery_history WHERE guild_id = ? AND kit_key = ?')
        .get(guildId, kit.name_key).count
      const count = claimCount + reservationCount + historyCount
      if (kit.global_limit > 0 && count >= kit.global_limit) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'limit_reached' }
      }
      const claimedAt = this.now()
      this.db.prepare(`
        INSERT INTO kit_claims (guild_id, user_id, ign, kit_name, kit_key, claimed_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(guildId, userId, verification.ign, kit.name, kit.name_key, claimedAt)
      this.db.exec('COMMIT')
      return { ok: true, kit, ign: verification.ign, claimed_at: claimedAt }
    } catch (error) {
      this.db.exec('ROLLBACK')
      if (String(error.message).includes('UNIQUE constraint failed')) return { ok: false, error: 'already_claimed' }
      throw error
    }
  }

  reserveKitDelivery(guildId, userId, ign, kitName, allowRepeat = false) {
    const kitKey = kitName.toLowerCase()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const verification = this.getVerification(guildId, userId)
      if (!verification || verification.status !== 'verified' || verification.ign.toLowerCase() !== ign.toLowerCase()) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'not_verified' }
      }
      const kit = this.getKit(guildId, kitName)
      if (!kit || !kit.available) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'unavailable' }
      }
      const claimed = this.db.prepare('SELECT 1 FROM kit_claims WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
        .get(guildId, userId, kit.name_key)
      const reserved = this.db.prepare('SELECT 1 FROM kit_delivery_reservations WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
        .get(guildId, userId, kit.name_key)
      const delivered = this.db.prepare('SELECT 1 FROM kit_delivery_history WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
        .get(guildId, userId, kit.name_key)
      if (reserved) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'delivery_in_progress' }
      }
      if (!allowRepeat && (claimed || delivered)) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'already_claimed' }
      }
      const claimCount = this.db.prepare('SELECT COUNT(*) AS count FROM kit_claims WHERE guild_id = ? AND kit_key = ?')
        .get(guildId, kit.name_key).count
      const reservationCount = this.db.prepare('SELECT COUNT(*) AS count FROM kit_delivery_reservations WHERE guild_id = ? AND kit_key = ?')
        .get(guildId, kit.name_key).count
      const historyCount = this.db.prepare('SELECT COUNT(*) AS count FROM kit_delivery_history WHERE guild_id = ? AND kit_key = ?')
        .get(guildId, kit.name_key).count
      if (!allowRepeat && kit.global_limit > 0 && claimCount + reservationCount + historyCount >= kit.global_limit) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'limit_reached' }
      }
      this.db.prepare(`
        INSERT INTO kit_delivery_reservations (guild_id, user_id, ign, kit_name, kit_key, reserved_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(guildId, userId, ign, kit.name, kit.name_key, this.now())
      this.db.exec('COMMIT')
      return { ok: true }
    } catch (error) {
      this.db.exec('ROLLBACK')
      if (String(error.message).includes('UNIQUE constraint failed')) return { ok: false, error: 'already_claimed' }
      throw error
    }
  }

  completeKitDelivery(guildId, userId, kitName) {
    const kitKey = kitName.toLowerCase()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const reservation = this.db.prepare(`
        SELECT ign FROM kit_delivery_reservations
        WHERE guild_id = ? AND user_id = ? AND kit_key = ?
      `).get(guildId, userId, kitKey)
      if (!reservation) {
        this.db.exec('ROLLBACK')
        return { ok: false, error: 'reservation_missing' }
      }
      const claimedAt = this.now()
      const existingClaim = this.db.prepare(`
        SELECT 1 FROM kit_claims WHERE guild_id = ? AND user_id = ? AND kit_key = ?
      `).get(guildId, userId, kitKey)
      if (existingClaim) {
        this.db.prepare(`
          INSERT INTO kit_delivery_history (guild_id, user_id, ign, kit_name, kit_key, claimed_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(guildId, userId, reservation.ign, kitName, kitKey, claimedAt)
      } else {
        this.db.prepare(`
          INSERT INTO kit_claims (guild_id, user_id, ign, kit_name, kit_key, claimed_at)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(guildId, userId, reservation.ign, kitName, kitKey, claimedAt)
      }
      this.db.prepare('DELETE FROM kit_delivery_reservations WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
        .run(guildId, userId, kitKey)
      this.db.prepare(`
        INSERT INTO audit_logs (guild_id, actor_id, action, details, created_at)
        VALUES (?, ?, ?, ?, ?)
      `).run(guildId, userId, 'kit.delivery_complete', kitName + ':' + reservation.ign, claimedAt)
      this.db.exec('COMMIT')
      return { ok: true, ign: reservation.ign, claimed_at: claimedAt }
    } catch (error) {
      this.db.exec('ROLLBACK')
      if (String(error.message).includes('UNIQUE constraint failed')) return { ok: false, error: 'already_claimed' }
      throw error
    }
  }

  releaseKitDelivery(guildId, userId, kitName) {
    return this.db.prepare('DELETE FROM kit_delivery_reservations WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
      .run(guildId, userId, kitName.toLowerCase()).changes > 0
  }

  resetClaimsUser(guildId, userId, kitName) {
    if (kitName) {
      this.db.exec('BEGIN IMMEDIATE')
      try {
        const claims = this.db.prepare('DELETE FROM kit_claims WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
          .run(guildId, userId, kitName.toLowerCase()).changes
        const history = this.db.prepare('DELETE FROM kit_delivery_history WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
          .run(guildId, userId, kitName.toLowerCase()).changes
        const reservations = this.db.prepare('DELETE FROM kit_delivery_reservations WHERE guild_id = ? AND user_id = ? AND kit_key = ?')
          .run(guildId, userId, kitName.toLowerCase()).changes
        this.db.exec('COMMIT')
        return claims + history + reservations
      } catch (error) {
        this.db.exec('ROLLBACK')
        throw error
      }
    }
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const claims = this.db.prepare('DELETE FROM kit_claims WHERE guild_id = ? AND user_id = ?')
        .run(guildId, userId).changes
      const history = this.db.prepare('DELETE FROM kit_delivery_history WHERE guild_id = ? AND user_id = ?')
        .run(guildId, userId).changes
      const reservations = this.db.prepare('DELETE FROM kit_delivery_reservations WHERE guild_id = ? AND user_id = ?')
        .run(guildId, userId).changes
      this.db.exec('COMMIT')
      return claims + history + reservations
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  resetAllClaims(guildId) {
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const claims = this.db.prepare('DELETE FROM kit_claims WHERE guild_id = ?').run(guildId).changes
      const history = this.db.prepare('DELETE FROM kit_delivery_history WHERE guild_id = ?').run(guildId).changes
      const reservations = this.db.prepare('DELETE FROM kit_delivery_reservations WHERE guild_id = ?').run(guildId).changes
      this.db.exec('COMMIT')
      return claims + history + reservations
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  listClaims(guildId, kitName, limit) {
    const kitFilter = kitName ? ' AND kit_key = ?' : ''
    const values = kitName
      ? [guildId, kitName.toLowerCase(), guildId, kitName.toLowerCase(), limit]
      : [guildId, guildId, limit]
    return this.db.prepare(`
      SELECT user_id, ign, kit_name, claimed_at FROM (
        SELECT user_id, ign, kit_name, claimed_at FROM kit_claims WHERE guild_id = ?${kitFilter}
        UNION ALL
        SELECT user_id, ign, kit_name, claimed_at FROM kit_delivery_history WHERE guild_id = ?${kitFilter}
      ) ORDER BY claimed_at DESC LIMIT ?
    `).all(...values)
  }

  audit(guildId, actorId, action, details) {
    this.db.prepare('INSERT INTO audit_logs (guild_id, actor_id, action, details, created_at) VALUES (?, ?, ?, ?, ?)')
      .run(guildId, actorId, action, details, this.now())
  }
}

function createVerificationSystem(client, { log, findLegacyIgnOwner, dbPath, assetDir = ASSET_DIR }) {
  const store = new VerificationStore(dbPath || DB_PATH)

  function logError(context, error) {
    log('[Verification] ' + context + ': ' + (error && error.message || String(error)))
  }

  function isAdministrator(interaction) {
    return interaction.memberPermissions && interaction.memberPermissions.has(PermissionFlagsBits.Administrator)
  }

  function getGuildId(interaction) {
    return interaction.guildId
  }

  function getStoredImagePath(fileName) {
    if (!fileName) return null
    if (path.basename(fileName) !== fileName) throw new Error('Stored verification image path is invalid.')
    const filePath = path.join(assetDir, fileName)
    if (!fs.existsSync(filePath)) throw new Error('Stored verification image is missing. Upload it again with `/verification edit`.')
    return filePath
  }

  function makePanel(config) {
    const embed = new EmbedBuilder()
      .setColor(parseInt(config.color.slice(1), 16))
      .setTitle(config.title)
      .setDescription(config.description + '\n\n*Minecraft username format is checked; account ownership is not verified.*')
      .setFooter({ text: 'ViperCryo • Verification' })
    const imagePath = getStoredImagePath(config.image_path)
    if (imagePath) embed.setImage('attachment://' + path.basename(imagePath))
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(VERIFY_BUTTON_ID).setLabel(config.button_label).setStyle(ButtonStyle.Primary)
    )
    const payload = { embeds: [embed], components: [row] }
    if (imagePath) payload.files = [new AttachmentBuilder(imagePath)]
    return payload
  }

  async function getTextChannel(guild, channelId) {
    const channel = await guild.channels.fetch(channelId)
    if (!channel || !channel.isTextBased() || typeof channel.send !== 'function') throw new Error('Configured channel is missing or is not a text channel.')
    return channel
  }

  async function publishPanel(guild, config, previousConfig = config) {
    const channel = await getTextChannel(guild, config.channel_id)
    const botMember = guild.members.me || await guild.members.fetch(client.user.id)
    const permissions = channel.permissionsFor(botMember)
    if (!permissions ||
        !permissions.has(PermissionFlagsBits.ViewChannel) ||
        !permissions.has(PermissionFlagsBits.SendMessages) ||
        !permissions.has(PermissionFlagsBits.EmbedLinks)) {
      throw new Error('The bot needs View Channel, Send Messages, and Embed Links permissions in the verification channel.')
    }
    const message = await channel.send(makePanel(config))
    store.updatePanelMessage(guild.id, message.id)
    if (config.panel_message_id) {
      try {
        const oldChannel = await guild.channels.fetch(previousConfig.channel_id)
        const oldMessage = oldChannel && await oldChannel.messages.fetch(config.panel_message_id)
        if (oldMessage) await oldMessage.edit({ components: [] })
      } catch (error) {
        logError('Could not disable the previous verification panel', error)
      }
    }
    return message
  }

  async function sendLog(guild, config, text) {
    if (!config || !config.log_channel_id) return
    try {
      const channel = await getTextChannel(guild, config.log_channel_id)
      await channel.send({ content: text, allowedMentions: { parse: [] } })
    } catch (error) { logError('Could not write to configured log channel', error) }
  }

  function configSummary(config) {
    if (!config) return 'Verification is not configured. An administrator can run `/verification setup`.'
    return [
      '**Channel:** <#' + config.channel_id + '>',
      '**Unverified role:** <@&' + config.unverified_role_id + '>',
      '**Verified role:** <@&' + config.verified_role_id + '>',
      '**Log channel:** ' + (config.log_channel_id ? '<#' + config.log_channel_id + '>' : 'Not configured'),
      '**Rejoin policy:** ' + (config.rejoin_policy === 'retain' ? 'Retain verification' : 'Require verification again'),
      '**Embed image:** ' + (config.image_path ? 'Configured' : 'None'),
      '**Panel title:** ' + config.title,
      '**Panel message:** ' + (config.panel_message_id ? 'Published' : 'Not published')
    ].join('\n')
  }

  async function updateMemberRoles(member, config, verified) {
    const verifiedRole = member.guild.roles.cache.get(config.verified_role_id)
    const unverifiedRole = member.guild.roles.cache.get(config.unverified_role_id)
    if (!verifiedRole || !unverifiedRole) throw new Error('Configured verification role is missing.')
    if (verified) {
      await member.roles.add(verifiedRole, 'ViperCryo verification')
      if (member.roles.cache.has(unverifiedRole.id)) await member.roles.remove(unverifiedRole, 'ViperCryo verification')
    } else {
      if (member.roles.cache.has(verifiedRole.id)) await member.roles.remove(verifiedRole, 'Verification reset/rejoin policy')
      if (!member.roles.cache.has(unverifiedRole.id)) await member.roles.add(unverifiedRole, 'Verification required')
    }
  }

  async function handleVerificationCommand(interaction) {
    if (!isAdministrator(interaction)) {
      await interaction.reply({ content: 'Administrator permission is required for verification management.', flags: MessageFlags.Ephemeral })
      return
    }
    const guild = interaction.guild
    if (!guild) {
      await interaction.reply({ content: 'This command can only be used in a server.', flags: MessageFlags.Ephemeral })
      return
    }
    const group = interaction.options.getSubcommandGroup(false)
    const subcommand = interaction.options.getSubcommand()
    const guildId = getGuildId(interaction)

    if (group === 'reset' && subcommand === 'user') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral })
      const target = interaction.options.getUser('member', true)
      const config = store.getConfig(guildId)
      let roleUpdateFailed = false
      const removed = store.deleteVerificationUser(guildId, target.id)
      if (config) {
        try {
          const member = await guild.members.fetch(target.id)
          await updateMemberRoles(member, config, false)
        } catch (error) {
          roleUpdateFailed = true
          logError('Could not reset member roles for ' + target.id, error)
        }
      }
      store.audit(guildId, interaction.user.id, 'verification.reset_user', target.id)
      await sendLog(guild, config, '🔄 Verification reset for <@' + target.id + '> by <@' + interaction.user.id + '>.')
      await interaction.editReply((removed ? 'Verification was reset. Existing kit claims were preserved.' : 'No verification record existed.') +
        (roleUpdateFailed ? ' Role updates failed; check bot permissions and role hierarchy.' : ''))
      return
    }

    if (group === 'reset' && subcommand === 'all') {
      if (!interaction.options.getBoolean('confirm', true)) {
        await interaction.reply({
          content: 'No changes made. Run `/verification reset all confirm:true` only when you intend to clear every member’s verification.',
          flags: MessageFlags.Ephemeral
        })
        return
      }
      await interaction.deferReply({ flags: MessageFlags.Ephemeral })
      const config = store.getConfig(guildId)
      const result = store.resetAllVerifications(guildId)
      let roleUpdateFailures = 0
      if (config) {
        for (const userId of result.users) {
          try {
            const member = await guild.members.fetch(userId)
            await updateMemberRoles(member, config, false)
          } catch (error) {
            roleUpdateFailures++
            logError('Could not reset verification roles for ' + userId, error)
          }
        }
      }
      store.audit(guildId, interaction.user.id, 'verification.reset_all', 'deleted=' + result.deleted)
      await sendLog(guild, config, '🔄 All verification records were reset by <@' + interaction.user.id + '>. Kit claim history was preserved.')
      await interaction.editReply(
        'Reset ' + result.deleted + ' verification record(s). Kit claims and verification settings were preserved.' +
        (roleUpdateFailures ? ' Could not update Discord roles for ' + roleUpdateFailures + ' member(s); check bot permissions and role hierarchy.' : '')
      )
      return
    }

    if (subcommand === 'reset-ign') {
      const ign = interaction.options.getString('ign', true)
      if (!IGN_PATTERN.test(ign)) {
        await interaction.reply({ content: 'That Minecraft username format is invalid.', flags: MessageFlags.Ephemeral })
        return
      }
      await interaction.deferReply({ flags: MessageFlags.Ephemeral })
      const owner = store.getIgnOwner(guildId, ign)
      const removed = store.deleteVerificationIgn(guildId, ign)
      if (owner) {
        const config = store.getConfig(guildId)
        if (config) {
          try {
            const member = await guild.members.fetch(owner.user_id)
            await updateMemberRoles(member, config, false)
          } catch (error) { logError('Could not update roles after IGN reset for ' + owner.user_id, error) }
        }
      }
      store.audit(guildId, interaction.user.id, 'verification.reset_ign', ign)
      await sendLog(guild, store.getConfig(guildId), '🔄 Minecraft IGN `' + ign + '` was released by <@' + interaction.user.id + '>.')
      await interaction.editReply(removed ? 'Released IGN **' + ign + '**. Kit claim history was preserved.' : 'No verification record used that IGN.')
      return
    }

    if (subcommand === 'status') {
      const config = store.getConfig(guildId)
      const counts = store.verificationCounts(guildId)
      const target = interaction.options.getUser('user')
      let statusText = '**Verified:** ' + (counts.verified || 0) + ' • **Pending/reverify:** ' + (counts.pending || 0)
      if (target) {
        const record = store.getVerification(guildId, target.id)
        statusText += '\n<@' + target.id + '>: ' + (record ? '**' + record.status + '** as `' + record.ign + '`' : 'not registered')
      }
      await interaction.reply({ content: configSummary(config) + '\n\n' + statusText, flags: MessageFlags.Ephemeral })
      return
    }

    if (subcommand === 'config') {
      await interaction.reply({ content: configSummary(store.getConfig(guildId)), flags: MessageFlags.Ephemeral })
      return
    }

    if (subcommand === 'setup' || subcommand === 'edit') {
      await interaction.deferReply({ flags: MessageFlags.Ephemeral })
      const previous = store.getConfig(guildId)
      if (subcommand === 'edit' && !previous) {
        await interaction.editReply('Verification is not set up yet. Run `/verification setup` first.')
        return
      }
      const options = interaction.options
      const channel = options.getChannel('channel')
      const unverifiedRole = options.getRole('unverified_role')
      const verifiedRole = options.getRole('verified_role')
      const imageAttachment = options.getAttachment('image')
      const removeImage = subcommand === 'edit' && options.getBoolean('remove_image')
      if (imageAttachment && removeImage) {
        await interaction.editReply('Upload a replacement image or choose Remove image, but not both.')
        return
      }
      const config = {
        channel_id: channel ? channel.id : previous && previous.channel_id,
        unverified_role_id: unverifiedRole ? unverifiedRole.id : previous && previous.unverified_role_id,
        verified_role_id: verifiedRole ? verifiedRole.id : previous && previous.verified_role_id,
        title: options.getString('title') || previous && previous.title,
        description: options.getString('description') || previous && previous.description,
        color: options.getString('color') || previous && previous.color,
        button_label: options.getString('button_label') || previous && previous.button_label,
        success_message: options.getString('success_message') || previous && previous.success_message,
        image_path: previous && previous.image_path || null,
        log_channel_id: options.getBoolean('clear_log_channel') ? null :
          options.getChannel('log_channel') ? options.getChannel('log_channel').id :
            subcommand === 'setup' ? null : previous && previous.log_channel_id,
        rejoin_policy: options.getString('rejoin_policy') || previous && previous.rejoin_policy || 'reverify',
        panel_message_id: previous && previous.panel_message_id
      }
      if (!config.channel_id || !config.unverified_role_id || !config.verified_role_id ||
          !config.title || !config.description || !config.color || !config.button_label || !config.success_message) {
        await interaction.editReply('Missing configuration. Use `/verification setup` and fill in all required fields.')
        return
      }
      if (config.unverified_role_id === config.verified_role_id) {
        await interaction.editReply('Unverified and verified roles must be different.')
        return
      }
      if (!COLOR_PATTERN.test(config.color)) {
        await interaction.editReply('Color must be written as a hex color, for example `#7B2CBF`.')
        return
      }
      const botMember = guild.members.me || await guild.members.fetch(client.user.id)
      if (!botMember.permissions.has(PermissionFlagsBits.ManageRoles)) {
        await interaction.editReply('The bot needs the **Manage Roles** permission.')
        return
      }
      const selectedUnverifiedRole = guild.roles.cache.get(config.unverified_role_id)
      const selectedVerifiedRole = guild.roles.cache.get(config.verified_role_id)
      if (!selectedUnverifiedRole || !selectedVerifiedRole ||
          selectedUnverifiedRole.id === guild.id || selectedVerifiedRole.id === guild.id ||
          selectedUnverifiedRole.position >= botMember.roles.highest.position ||
          selectedVerifiedRole.position >= botMember.roles.highest.position) {
        await interaction.editReply('Both roles must exist and be below the bot’s highest role in Server Settings → Roles.')
        return
      }
      if (imageAttachment) {
        try {
          config.image_path = await saveUploadedImage(imageAttachment, assetDir)
        } catch (error) {
          logError('Could not store uploaded verification image', error)
          await interaction.editReply('Could not use that image: ' + error.message)
          return
        }
      } else if (removeImage) {
        config.image_path = null
      }
      store.saveConfig(guildId, config)
      try {
        const panel = await publishPanel(guild, config, previous)
        if (previous && previous.image_path && previous.image_path !== config.image_path) {
          try {
            const oldImagePath = path.join(assetDir, path.basename(previous.image_path))
            if (path.basename(previous.image_path) === previous.image_path && fs.existsSync(oldImagePath)) fs.unlinkSync(oldImagePath)
          } catch (error) { logError('Could not clean up replaced verification image', error) }
        }
        store.audit(guildId, interaction.user.id, 'verification.' + subcommand, JSON.stringify({
          channel_id: config.channel_id,
          unverified_role_id: config.unverified_role_id,
          verified_role_id: config.verified_role_id
        }))
        await interaction.editReply('✅ Verification settings saved and panel published in <#' + config.channel_id + '> (message `' + panel.id + '`).\nNew members will receive the Unverified role. Configure channel overwrites so only the verification channel and any explicitly allowed channels are visible before verification.')
      } catch (error) {
        logError('Could not publish verification panel', error)
        await interaction.editReply('Settings were saved, but the panel could not be published: ' + error.message)
      }
    }
  }

  async function handleKitAdmin(interaction) {
    if (!isAdministrator(interaction)) {
      await interaction.reply({ content: 'Administrator permission is required for kit management.', flags: MessageFlags.Ephemeral })
      return
    }
    const guildId = getGuildId(interaction)
    const guild = interaction.guild
    const action = interaction.options.getSubcommand()
    if (action === 'create') {
      const name = interaction.options.getString('name', true).trim()
      const description = interaction.options.getString('description', true).trim()
      const globalLimit = interaction.options.getInteger('global_limit', true)
      if (!KIT_PATTERN.test(name) || !description) {
        await interaction.reply({ content: 'Kit names may contain letters, numbers, `_`, and `-` (1–32 characters); description cannot be empty.', flags: MessageFlags.Ephemeral })
        return
      }
      try {
        store.createKit(guildId, name, description, interaction.options.getBoolean('available', true), globalLimit)
      } catch (error) {
        if (String(error.message).includes('UNIQUE constraint failed')) {
          await interaction.reply({ content: 'A kit with that name already exists.', flags: MessageFlags.Ephemeral })
          return
        }
        throw error
      }
      store.audit(guildId, interaction.user.id, 'kit.create', name)
      await interaction.reply({ content: '✅ Kit **' + name + '** created. Claims only record a claim; the bot does not deliver an in-game kit.', flags: MessageFlags.Ephemeral })
      return
    }
    if (action === 'edit') {
      const name = interaction.options.getString('name', true).trim()
      const changes = {
        description: interaction.options.getString('description'),
        available: interaction.options.getBoolean('available'),
        global_limit: interaction.options.getInteger('global_limit')
      }
      if (!store.getKit(guildId, name)) {
        await interaction.reply({ content: 'That kit does not exist.', flags: MessageFlags.Ephemeral })
        return
      }
      if (!store.editKit(guildId, name, changes)) {
        await interaction.reply({ content: 'Choose at least one setting to edit.', flags: MessageFlags.Ephemeral })
        return
      }
      store.audit(guildId, interaction.user.id, 'kit.edit', name)
      await interaction.reply({ content: '✅ Updated settings for **' + name + '**.', flags: MessageFlags.Ephemeral })
      return
    }
    if (action === 'delete') {
      const name = interaction.options.getString('name', true).trim()
      if (!store.deleteKit(guildId, name)) {
        await interaction.reply({ content: 'That kit does not exist.', flags: MessageFlags.Ephemeral })
        return
      }
      store.audit(guildId, interaction.user.id, 'kit.delete', name)
      await interaction.reply({ content: '✅ Kit removed from the claim list. Existing claim records are preserved.', flags: MessageFlags.Ephemeral })
      return
    }
    if (action === 'list') {
      const kits = store.listKits(guildId)
      const description = kits.length ? kits.map(kit =>
        '**' + kit.name + '** — ' + (kit.available ? 'Available' : 'Paused') +
        ' • Global claims: ' + (kit.global_limit ? kit.global_limit : 'Unlimited') +
        '\n' + kit.description
      ).join('\n\n') : 'No kits are configured. An administrator can use `/kit create`.'
      await interaction.reply({ embeds: [new EmbedBuilder().setColor(0x7B2CBF).setTitle('ViperCryo • Kit Claims').setDescription(description.slice(0, 4000))], flags: MessageFlags.Ephemeral })
      return
    }
    if (action === 'reset-user') {
      const user = interaction.options.getUser('member', true)
      const kit = interaction.options.getString('kit')
      const count = store.resetClaimsUser(guildId, user.id, kit && kit.trim())
      store.audit(guildId, interaction.user.id, 'kit.reset_user', user.id + (kit ? ':' + kit : ':all'))
      await interaction.reply({ content: 'Reset ' + count + ' claim, repeat-delivery, or pending-delivery record(s) for <@' + user.id + '>. Verification data was not changed.', flags: MessageFlags.Ephemeral })
      return
    }
    if (action === 'reset-all') {
      if (!interaction.options.getBoolean('confirm', true)) {
        await interaction.reply({ content: 'No changes made. Run `/kit reset-all confirm:true` only when you intend to reset all kit claim history.', flags: MessageFlags.Ephemeral })
        return
      }
      const count = store.resetAllClaims(guildId)
      store.audit(guildId, interaction.user.id, 'kit.reset_all', 'deleted=' + count)
      await interaction.reply({ content: '⚠️ Reset ' + count + ' kit claim, repeat-delivery, or pending-delivery record(s) for this server. Verification records remain unchanged.', flags: MessageFlags.Ephemeral })
      return
    }
    if (action === 'logs') {
      const kit = interaction.options.getString('kit')
      const limit = interaction.options.getInteger('limit') || 10
      const rows = store.listClaims(guildId, kit && kit.trim(), limit)
      const text = rows.length ? rows.map(row =>
        '`' + row.claimed_at.slice(0, 19).replace('T', ' ') + ' UTC` • **' + row.kit_name +
        '** • `' + row.ign + '` • <@' + row.user_id + '>'
      ).join('\n') : 'No claim records found.'
      await interaction.reply({ content: text.slice(0, 1900), flags: MessageFlags.Ephemeral })
    }
  }

  async function handleClaim(interaction) {
    const guild = interaction.guild
    if (!guild) {
      await interaction.reply({ content: 'Kit claims are available in a configured server only.', flags: MessageFlags.Ephemeral })
      return
    }
    const kitName = interaction.options.getString('kit', true).trim()
    if (!KIT_PATTERN.test(kitName)) {
      await interaction.reply({ content: 'Invalid kit name.', flags: MessageFlags.Ephemeral })
      return
    }
    await interaction.deferReply({ flags: MessageFlags.Ephemeral })
    const result = store.claimKit(guild.id, interaction.user.id, kitName)
    if (!result.ok) {
      const messages = {
        not_verified: 'Verify through this server’s verification panel before claiming a kit.',
        unavailable: 'That kit does not exist or is not currently available.',
        already_claimed: 'You have already claimed this kit. Each Discord account can claim it once.',
        limit_reached: 'The claim limit for this kit has been reached.'
      }
      await interaction.editReply(messages[result.error] || 'The claim could not be recorded.')
      return
    }
    const config = store.getConfig(guild.id)
    store.audit(guild.id, interaction.user.id, 'kit.claim', result.kit.name)
    await sendLog(guild, config, '📦 Kit claim recorded: **' + result.kit.name + '** for <@' + interaction.user.id + '> (`' + result.ign + '`). This is a claim record, not in-game delivery.')
    await interaction.editReply({
      content: '✅ Your one-time claim for **' + result.kit.name + '** is recorded for Minecraft IGN `' + result.ign + '`.\n' +
        'This bot records claims but does not automatically deliver the in-game kit. Contact staff if delivery is arranged separately.'
    })
  }

  async function onInteraction(interaction) {
    try {
      if (interaction.isChatInputCommand()) {
        if (!interaction.guildId) {
          await interaction.reply({ content: 'Use this command in a server.', flags: MessageFlags.Ephemeral })
          return
        }
        if (interaction.commandName === 'verification') return await handleVerificationCommand(interaction)
        if (interaction.commandName === 'kit') return await handleKitAdmin(interaction)
        if (interaction.commandName === 'claim') return await handleClaim(interaction)
      }

      if (interaction.isButton() && interaction.customId === VERIFY_BUTTON_ID) {
        const config = interaction.guildId && store.getConfig(interaction.guildId)
        if (!config || interaction.channelId !== config.channel_id) {
          await interaction.reply({ content: 'This verification panel is no longer active. Please use the current panel or contact an administrator.', flags: MessageFlags.Ephemeral })
          return
        }
        const existing = store.getVerification(interaction.guildId, interaction.user.id)
        if (existing && existing.status === 'verified') {
          await interaction.reply({ content: 'You are already verified as `' + existing.ign + '`.', flags: MessageFlags.Ephemeral })
          return
        }
        const modal = new ModalBuilder().setCustomId(VERIFY_MODAL_ID).setTitle('Verify your Minecraft IGN')
          .addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder().setCustomId('ign').setLabel('Minecraft Username (IGN)')
              .setPlaceholder('3–16 letters, numbers, or underscores')
              .setStyle(TextInputStyle.Short).setMinLength(3).setMaxLength(16).setRequired(true)
          ))
        await interaction.showModal(modal)
        return
      }

      if (interaction.isModalSubmit() && interaction.customId === VERIFY_MODAL_ID) {
        const guild = interaction.guild
        if (!guild) {
          await interaction.reply({ content: 'Verification must be completed in a server.', flags: MessageFlags.Ephemeral })
          return
        }
        const config = store.getConfig(guild.id)
        if (!config) {
          await interaction.reply({ content: 'Verification is not configured for this server. Contact an administrator.', flags: MessageFlags.Ephemeral })
          return
        }
        const ign = interaction.fields.getTextInputValue('ign').trim()
        if (!IGN_PATTERN.test(ign)) {
          await interaction.reply({ content: 'Invalid IGN. Use 3–16 letters, numbers, or underscores.', flags: MessageFlags.Ephemeral })
          return
        }
        const legacyOwner = findLegacyIgnOwner(ign)
        if (legacyOwner && legacyOwner !== interaction.user.id) {
          await interaction.reply({ content: 'That IGN is already linked to another Discord account in this bot. Contact an administrator if this is an error.', flags: MessageFlags.Ephemeral })
          return
        }
        const result = store.setVerified(guild.id, interaction.user.id, ign)
        if (!result.ok) {
          await interaction.reply({ content: 'That IGN is already registered to another Discord member.', flags: MessageFlags.Ephemeral })
          return
        }
        await interaction.deferReply({ flags: MessageFlags.Ephemeral })
        const member = await guild.members.fetch(interaction.user.id)
        const issues = []
        try { await updateMemberRoles(member, config, true) } catch (error) {
          logError('Could not update verification roles for ' + interaction.user.id, error)
          issues.push('I saved your verification, but could not update your roles. Please contact a server administrator.')
        }
        try { await member.setNickname(ign, 'Minecraft IGN verification') } catch (error) {
          logError('Could not set verified nickname for ' + interaction.user.id, error)
          issues.push('Your verification is saved, but I could not set your server nickname to your Minecraft IGN. Ask an administrator to grant me Manage Nicknames and move my bot role above your highest role.')
        }
        store.audit(guild.id, interaction.user.id, 'verification.complete', ign)
        await sendLog(guild, config, '✅ <@' + interaction.user.id + '> verified as Minecraft IGN `' + ign + '`.')
        const success = config.success_message.replace(/\{ign\}/gi, ign)
        await interaction.editReply({
          content: issues.length ? success + '\n\n⚠️ ' + issues.join(' ') : success,
        })
        return
      }
    } catch (error) {
      logError('Interaction handler failed', error)
      const message = 'The request could not be completed. Please try again or contact a server administrator.'
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp({ content: message, flags: MessageFlags.Ephemeral }).catch(e => logError('Could not send interaction error response', e))
      } else {
        await interaction.reply({ content: message, flags: MessageFlags.Ephemeral }).catch(e => logError('Could not send interaction error response', e))
      }
    }
  }

  async function onMemberJoin(member) {
    const config = store.getConfig(member.guild.id)
    if (!config) return
    const record = store.getVerification(member.guild.id, member.id)
    if (record && record.status === 'verified' && config.rejoin_policy === 'retain') {
      try {
        await updateMemberRoles(member, config, true)
      } catch (error) { logError('Could not restore retained verified roles for ' + member.id, error) }
      return
    }
    if (record && record.status === 'verified') store.markPending(member.guild.id, member.id)
    try {
      await updateMemberRoles(member, config, false)
    } catch (error) { logError('Could not assign unverified role to new member ' + member.id, error) }
  }

  async function registerCommands(guild) {
    const definitions = buildCommands()
    try {
      const existing = await guild.commands.fetch()
      for (const definition of definitions) {
        const current = existing.find(command => command.name === definition.name)
        if (current) await guild.commands.edit(current.id, definition)
        else await guild.commands.create(definition)
      }
      log('[Commands] Verification and claim commands synced for ' + guild.name)
    } catch (error) { logError('Could not sync slash commands for ' + guild.name, error) }
  }

  return {
    store,
    buildCommands,
    onInteraction,
    onMemberJoin,
    registerCommands
  }
}

module.exports = { VerificationStore, buildCommands, createVerificationSystem, saveUploadedImage }
