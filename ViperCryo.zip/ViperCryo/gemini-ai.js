'use strict'

const { GoogleGenAI } = require('@google/genai')

const DEFAULT_COOLDOWN_MS = 10000
const DEFAULT_TIMEOUT_MS = 45000
const MODEL_CACHE_MS = 15 * 60 * 1000
const MAX_CHAT_CHUNK_LENGTH = 180

function parseViperAiCommand(message) {
  const match = String(message || '').trim().match(/^!viper\s+ai(?:\s+([\s\S]*))?$/i)
  return match ? { question: String(match[1] || '').trim() } : null
}

function splitChatResponse(text, maxLength = MAX_CHAT_CHUNK_LENGTH) {
  const normalized = String(text || '').replace(/[\r\n\t]+/g, ' ').replace(/\s+/g, ' ').trim()
  if (!normalized) return []

  const chunks = []
  let chunk = ''
  const appendWord = word => {
    if (chunk && chunk.length + 1 + word.length > maxLength) {
      chunks.push(chunk)
      chunk = ''
    }
    if (word.length <= maxLength) {
      chunk = chunk ? chunk + ' ' + word : word
      return
    }
    for (const character of Array.from(word)) {
      if (chunk.length + character.length > maxLength) {
        chunks.push(chunk)
        chunk = ''
      }
      chunk += character
    }
  }

  for (const word of normalized.split(' ')) appendWord(word)
  if (chunk) chunks.push(chunk)
  return chunks
}

function formatMinecraftMessages(chunks) {
  return chunks.map(chunk => 'Gemini: ' + chunk)
}

function sanitizeProviderMessage(message) {
  return String(message || '')
    .replace(/AIza[0-9A-Za-z_-]{20,}/g, '[REDACTED_KEY]')
    .replace(/(api[_ -]?key\s*[:=]\s*)[^\s,;]+/gi, '$1[REDACTED]')
    .replace(/(Bearer\s+)[^\s]+/gi, '$1[REDACTED]')
    .replace(/[\r\n\t]+/g, ' ')
    .slice(0, 240)
}

function getErrorDetails(error) {
  const status = Number(error && (
    error.status ||
    error.statusCode ||
    (error.response && error.response.status)
  )) || null
  const timedOut = status === 408 || status === 504 || Boolean(error && (
    error.name === 'AbortError' ||
    error.name === 'TimeoutError' ||
    /timeout|timed out|aborted/i.test(String(error.message || ''))
  ))
  let errorType = 'request_failed'
  if (status === 401) errorType = 'invalid_api_key'
  else if (status === 403) errorType = 'access_denied'
  else if (status === 404) errorType = 'model_not_found'
  else if (status === 400) errorType = 'invalid_request'
  else if (status === 429) errorType = 'rate_limited'
  else if (timedOut) errorType = 'timeout'
  else if (status >= 500) errorType = 'service_unavailable'
  const providerMessage = sanitizeProviderMessage(error && error.message)
  return {
    error: errorType,
    status,
    ...(providerMessage ? { providerMessage } : {})
  }
}

function getModelId(model) {
  const name = String(model && model.name || '').trim()
  return name.replace(/^models\//i, '')
}

function supportsGenerateContent(model) {
  return Array.isArray(model && model.supportedActions) &&
    model.supportedActions.some(action => String(action).toLowerCase() === 'generatecontent')
}

function selectGenerateContentModel(models) {
  const candidates = (Array.isArray(models) ? models : [])
    .filter(supportsGenerateContent)
    .map(model => ({
      id: getModelId(model),
      displayName: String(model.displayName || '')
    }))
    .filter(model => model.id)
  if (!candidates.length) return null

  const isTextModel = model => !/(image|audio|tts|transcri|embed|live)/i.test(model.id + ' ' + model.displayName)
  const flashCandidates = candidates.filter(model => /flash/i.test(model.id + ' ' + model.displayName) && isTextModel(model))
  const preferredCandidates = flashCandidates.length ? flashCandidates : candidates.filter(isTextModel)
  const rankedCandidates = preferredCandidates.length ? preferredCandidates : candidates
  rankedCandidates.sort((a, b) => {
    const previewDifference = Number(/preview|experimental/i.test(a.id)) - Number(/preview|experimental/i.test(b.id))
    return previewDifference || a.id.localeCompare(b.id)
  })
  return rankedCandidates[0].id
}

function createGeminiAi({
  apiKey = process.env.GEMINI_API_KEY,
  cooldownMs = DEFAULT_COOLDOWN_MS,
  timeoutMs = DEFAULT_TIMEOUT_MS,
  modelCacheMs = MODEL_CACHE_MS,
  client,
  now = Date.now
} = {}) {
  const key = String(apiKey || '').trim()
  const aiClient = client || (key
    ? new GoogleGenAI({
      apiKey: key,
      httpOptions: { timeout: timeoutMs, retryOptions: { attempts: 1 } }
    })
    : null)
  const lastRequestAt = new Map()
  const inFlight = new Set()
  let selectedModel = null
  let selectedModelAt = 0
  let modelSelectionPromise = null
  let cachedAccessFailure = null

  async function discoverModel(forceRefresh = false) {
    if (!forceRefresh && cachedAccessFailure && now() < cachedAccessFailure.expiresAt) {
      throw Object.assign(new Error(cachedAccessFailure.providerMessage || 'Gemini API access denied'), {
        status: 403
      })
    }
    if (!forceRefresh && selectedModel && now() - selectedModelAt < modelCacheMs) return selectedModel
    if (forceRefresh || (cachedAccessFailure && now() >= cachedAccessFailure.expiresAt)) {
      cachedAccessFailure = null
    }
    if (modelSelectionPromise) return modelSelectionPromise
    modelSelectionPromise = (async () => {
      try {
        const models = []
        const pager = await aiClient.models.list({ config: { queryBase: true } })
        for await (const model of pager) models.push(model)
        const discoveredModel = selectGenerateContentModel(models)
        if (!discoveredModel) {
          const error = new Error('No model supporting generateContent is available')
          error.code = 'NO_COMPATIBLE_MODEL'
          throw error
        }
        selectedModel = discoveredModel
        selectedModelAt = now()
        return selectedModel
      } catch (error) {
        const details = getErrorDetails(error)
        if (details.status === 403) {
          cachedAccessFailure = {
            ...details,
            providerMessage: sanitizeProviderMessage(error && error.message),
            expiresAt: now() + modelCacheMs
          }
        }
        throw error
      }
    })()
    try {
      return await modelSelectionPromise
    } finally {
      modelSelectionPromise = null
    }
  }

  return {
    async answer(username, question) {
      if (!aiClient) return { ok: false, error: 'missing_key' }
      const playerKey = String(username || '').trim().toLowerCase()
      const prompt = String(question || '').trim()
      if (!playerKey || !prompt) return { ok: false, error: 'invalid_request' }
      if (inFlight.has(playerKey)) return { ok: false, error: 'in_progress' }

      const requestedAt = now()
      const previousRequestAt = lastRequestAt.get(playerKey)
      if (previousRequestAt !== undefined && requestedAt - previousRequestAt < cooldownMs) {
        return {
          ok: false,
          error: 'cooldown',
          retryAfterSeconds: Math.ceil((cooldownMs - (requestedAt - previousRequestAt)) / 1000)
        }
      }

      lastRequestAt.set(playerKey, requestedAt)
      if (lastRequestAt.size > 1000) {
        for (const [name, timestamp] of lastRequestAt) {
          if (requestedAt - timestamp >= cooldownMs) lastRequestAt.delete(name)
        }
      }
      inFlight.add(playerKey)
      try {
        let model
        try {
          model = await discoverModel()
        } catch (error) {
          if (error && error.code === 'NO_COMPATIBLE_MODEL') return { ok: false, error: 'no_compatible_model' }
          return { ok: false, ...getErrorDetails(error) }
        }

        let response
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            response = await aiClient.models.generateContent({
              model,
              contents: prompt,
              config: {
                systemInstruction: 'Answer the player helpfully in the language they used. Keep the answer concise and suitable for Minecraft chat. Do not provide commands for the bot to execute; you only answer with text.',
                maxOutputTokens: 256,
                temperature: 0.5,
                thinkingConfig: { thinkingLevel: 'low' }
              }
            })
            break
          } catch (error) {
            const details = getErrorDetails(error)
            if (details.status === 403) {
              cachedAccessFailure = {
                ...details,
                providerMessage: sanitizeProviderMessage(error && error.message),
                expiresAt: now() + modelCacheMs
              }
              return { ok: false, ...details }
            }
            if (details.status !== 404 || attempt > 0) return { ok: false, ...details }
            selectedModel = null
            selectedModelAt = 0
            try {
              const refreshedModel = await discoverModel(true)
              if (refreshedModel === model) return { ok: false, ...details }
              model = refreshedModel
            } catch (refreshError) {
              if (refreshError && refreshError.code === 'NO_COMPATIBLE_MODEL') {
                return { ok: false, error: 'no_compatible_model' }
              }
              return { ok: false, ...getErrorDetails(refreshError) }
            }
          }
        }
        const chunks = splitChatResponse(response && response.text)
        return chunks.length ? { ok: true, chunks } : { ok: false, error: 'empty_response' }
      } catch (error) {
        return { ok: false, ...getErrorDetails(error) }
      } finally {
        inFlight.delete(playerKey)
      }
    }
  }
}

module.exports = {
  createGeminiAi,
  formatMinecraftMessages,
  parseViperAiCommand,
  selectGenerateContentModel,
  sanitizeProviderMessage,
  splitChatResponse
}
