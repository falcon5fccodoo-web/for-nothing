'use strict'

const Module = require('module')
const path = require('path')
const fs = require('fs')

// prismarine-chat BigInt fix (required for 1.21.11)
const PC_BAD = 'buf.writeInt32BE(num,'
const PC_GOOD = 'buf.writeInt32BE(Number(num),'
const originalCompile = Module.prototype._compile
Module.prototype._compile = function (content, filename, ...rest) {
  if (typeof content === 'string' && /[\\/]prismarine-chat[\\/]index\.js$/.test(String(filename)) && content.includes(PC_BAD)) {
    content = content.split(PC_BAD).join(PC_GOOD)
  }
  return originalCompile.call(this, content, filename, ...rest)
}

const mineflayer = require('mineflayer')
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder')
const minecraftData = require('minecraft-data')
const axios = require('axios')
const { Client, GatewayIntentBits, EmbedBuilder, Events, ChannelType, PermissionsBitField } = require('discord.js')

const PASSWORD = process.env.MINECRAFT_PASSWORD || 'Shivamjii'
const USERNAME = process.env.MINECRAFT_USERNAME || 'malwarebotpvp'
const DISCORD_WEBHOOK = process.env.DISCORD_WEBHOOK || ''
const DISCORD_TOKEN = process.env.DISCORD_TOKEN || 'MTUxOTIxNzg2Mjk3NDM3ODA3Ng.Gyhsxv.hT_Esu88vgb75uQfNTt_CPyrWPHBAycaXXMGYg'

// Environment variables (if set) override the values above.
for (const [name, value] of [
  ['MINECRAFT_PASSWORD', PASSWORD],
  ['DISCORD_TOKEN', DISCORD_TOKEN]
]) {
  if (!value) {
    console.error('[BOT] Missing required environment variable: ' + name + '. Set it before starting the bot.')
    process.exit(1)
  }
}

// Channel IDs
const CHANNEL_ID = ''
const ECONOMY_CHANNEL_ID = '1555229714933616691' // kit orders
const DAILY_CHANNEL_ID = '1555231124513488989' // daily login
const SHOP_CHANNEL_ID = '1566448401350918235' // cosmetic shop ($shop, $redeem)
// Optional: ID of a Discord category where shop ticket channels are created (leave empty = no category)
const TICKET_CATEGORY_ID = ''
const BOT_CMD_CHANNEL_ID = '1555232321513201674' // admin bot commands
// Create a Discord channel named "gamble", enable the bot there, paste the channel ID here
const GAMBLE_CHANNEL_ID = process.env.GAMBLE_CHANNEL_ID || '1555854168088911872'

// Built-in admins (always present). Extra admins via $add admin @user
const DEFAULT_ADMIN_IDS = [
  '1388848551102251128',
  '697933155562291241'
]

// Only these kit admins can $add admin, $remove admin, and edit kit list
const KIT_ADMIN_IDS = [
  '1388848551102251128',
  '697933155562291241',
  '1469663184460714111'
]

let ADMIN_IDS = DEFAULT_ADMIN_IDS.slice()
let extraAdminIds = [] // promoted via $add admin — saved in coins.json

function rebuildAdminIds() {
  const set = new Set(DEFAULT_ADMIN_IDS.concat(extraAdminIds).map(String))
  ADMIN_IDS = [...set]
}

function isKitAdmin(userId) {
  return KIT_ADMIN_IDS.includes(String(userId))
}

const OWNER_ID = ''

// Discord where players earn Cat Coins
const DISCORD_INVITE = 'https://discord.gg/sv5QdAgdA'
const DATA_FILE = path.join(__dirname, 'coins.json') // balances are saved here so restarts don't wipe coins
const KIT_INFO = 'Kits cost Cat Coins. In Discord: $register <name>, $login for coins, then $order <kit> <amount>. In game: $kit <kit> <amount>. See all kits: $kitlist'
const KIT_QUESTION_REGEX = /\b(kits?|cat ?coins?|coins?|discord|shulkers?|earn)\b/i

// ================= GROQ AI CONFIGURATION =================
const GROQ_API_KEY = process.env.GROQ_API_KEY || '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'

// The bot asks Groq which models YOUR key can use, then tries them in this order of preference.
const PREFERRED_MODELS = [
  'llama-3.3-70b-versatile',
  'llama-3.1-8b-instant',
  'openai/gpt-oss-20b',
  'openai/gpt-oss-120b',
  'qwen/qwen3.8-27b',
  'meta-llama/llama-4-scout-17b-16e-instruct',
  'moonshotai/kimi-k2-instruct',
  'qwen/qwen3-32b'
]

// Words that count as insulting / joking about BlackCat (tight list so normal chat is safe)
const INSULT_REGEX = /\b(trash|garbage|noob|suck|sucks|useless|stupid|dumb|cringe|ugly|worst|lame|dogwater|clown|idiot|loser|shit|crap|fuck|fk|stinks|bozo|braindead)\b/i

// Asking for a joke
const JOKE_REGEX = /\b(joke|jokes|dad joke|make me laugh|something funny|pun)\b/i

// People the bot defends: if someone jokes about them, the bot roasts that person.
// qbasty is NOT in this list on purpose.
const PROTECTED_REGEX = /(black\s?cat|meseju|6b6tmalware|malwarebotpvp)/i
// Insulting the bot itself ("you are trash", "bot is bad") also gets a roast
const BOT_TARGET_REGEX = /\b(you|your|youre|ur|u|bot)\b/i

const WHO_AM_I_REGEX = /\bwho\s*(am\s*i|i\s*am)\b|\bwhoami\b/i
const CREATOR_REGEX = /\bwho\s*(is|are|r)?\s*(your|ur)\s*(creator|owner|maker|developer|dev|dad)\b|\bwho\s*(made|created|built|coded|programmed)\s*(you|u)\b/i
const CREATOR_ANSWER = 'My creators are 6b6tmalware, the developer, and the BlackCat team.'

// "give kit to Steve" / "give 2 build kits to Steve" / "send food kit Steve" (owners only)
const GIVE_KIT_REGEX = /^\s*(?:pls\s+)?(?:give|send|deliver)\s+(?:(\d{1,2})\s+)?(?:(pvp|build|travel|food|totums?|etc)\s+)?kits?\s+(?:to\s+)?([A-Za-z0-9_.]{3,16})\s*[.!]?\s*$/i

// ================= ROASTS (real life only) =================
// Used when the AI is down so roasts ALWAYS work. No family, body, race, religion, gender or disability.
const ROAST_FALLBACKS = [
  'You have strong opinions for someone whose group chat has been muted since 2022.',
  'Your confidence is impressive, it is the only thing you have ever had in a full-time position.',
  'You are the human version of a loading screen, lots of waiting and nothing happens.',
  'Your resume says self-employed, your bank account says otherwise.',
  'You type like someone who has not talked to a person out loud since Tuesday.',
  'Nobody is watching you, buddy. You are not the main character, you are the tutorial.',
  'Even your alarm clock has given up on you.',
  'You are loud online because nobody listens to you in real life.',
  'Your gym membership has more attendance in your imagination than in reality.',
  'The only thing you have ever finished on time is disappointing people.',
  'You have the energy of a Monday morning meeting that could have been an email.',
  'Your best skill is arguing with strangers because nobody else will argue with you.',
  'You are one failed plan away from calling it a lifestyle.',
  'Your sleep schedule is the only thing in your life more broken than your argument.',
  'You have the social life of a software update, ignored until something breaks.',
  'You say you are busy, but your calendar has been empty longer than your fridge.',
  'You are proof that confidence and talent are not related.',
  'Your story peaked in school and the sequel got cancelled.',
  'You have more excuses than savings.',
  'Your dating profile gets swiped past faster than a terms and conditions page.',
  'You are the reason group projects were invented, so someone else could do the work.',
  'You type paragraphs for attention you could not get in person.',
  'Your life advice is worth exactly what you paid for it.',
  'You are always right in your head, that is the only place you have an audience.',
  'You talk about your goals like they are plans, but they are just things you said once.',
  'Your phone battery has seen more action than you have this year.',
  'You are the kind of person who reads the room and then still says it anyway.',
  'You would be fun at parties if anyone ever invited you to one.',
  'Your comeback speed is slower than your internet and your career.',
  'You have been "about to start" your life for years now.',
  'Touch grass, then come back and try again with a real argument.',
  'You do not have haters, you have people who stopped caring a long time ago.',
  'You sound like a motivational quote written by someone who never did anything.',
  'Your personality is just opinions you copied from the internet five minutes ago.',
  'I would say go outside, but I would not want to scare the neighbors.',
  'You are not unlucky, you just keep doing the same thing and expecting a miracle.',
  'The only thing growing in your life is the list of things you quit.',
  'You are what happens when a Wi-Fi password is the only thing someone is proud of.',
  'You bring the same energy to everything: late and a little disappointing.',
  'Your best idea this month was telling me this, and it is not winning.'
]

let lastRoastIndex = -1
function pickRoast() {
  let i
  do { i = Math.floor(Math.random() * ROAST_FALLBACKS.length) } while (i === lastRoastIndex && ROAST_FALLBACKS.length > 1)
  lastRoastIndex = i
  return ROAST_FALLBACKS[i]
}

const ROAST_ANGLES = [
  'no job and no direction',
  'a group chat that is always on mute',
  'being single and blaming everyone else',
  'not having touched grass in weeks',
  'a broken sleep schedule and 3 AM typing',
  'being broke and full of excuses',
  'peaking in school',
  'loud online and invisible in real life',
  'an unused gym membership',
  'big plans that never start',
  'an empty calendar',
  'copying opinions from the internet',
  'fake confidence with nothing behind it',
  'living for attention nobody gives',
  'always being late and always having an excuse',
  'giving life advice with no life results'
]

const recentRoasts = []

let roastContextForNext = '' // set right before askGroqAI(...,'roast'), consumed here
function buildRoastQuestion(text, username) {
  const ctx = roastContextForNext ? '\nThe recent back-and-forth with this player (oldest first, BOT = you):\n' + roastContextForNext : ''
  roastContextForNext = ''
  const avoid = recentRoasts.length
    ? '\nDo NOT reuse the jokes or wording of these recent roasts: ' + recentRoasts.join(' | ')
    : ''
  return 'Player "' + username + '" said: "' + text + '"\nWrite a brand new roast aimed at this player. Choose your own angle from what they said or how they said it, and answer them like a real comeback in a fight, not a random insult.' + ctx + avoid
}

function rememberRoast(reply) {
  recentRoasts.push(String(reply).slice(0, 80))
  if (recentRoasts.length > 5) recentRoasts.shift()
}


// ================= AUTO ROAST WATCHER =================
// The bot reads ALL public chat (no !ai needed). If the AI decides a message is insulting or mocking
// BlackCat / meseju / 6b6tmalware / malwarebotpvp, the bot sends an AI-written roast in public chat to that player.
// There is no insult word list for this: the AI judges the meaning and writes the roast itself.
const AUTO_ROAST_NAME_REGEX = /(black\s?cat|meseju|6b6t\s?malware|malware\s?bot|malwarebotpvp)/i
const AUTO_ROAST_ADDRESS_REGEX = /\b(you|your|youre|you're|ur|u|bot)\b/i
const AUTO_ROAST_AD_REGEX = /https?:\/\/|discord\.gg|dsc\.gg/i
// Server/ad/kit bots that only repeat text. MossadBot is NOT here on purpose, so it gets roasted back.
const AUTO_ROAST_IGNORE = new Set([
  'zombievashog', 'restockbot', 'indeciskitbot', 'kitbot1', 'legionkits', 'providencekit', 'ldneo', 'treeone'
])
// Some AI models answer "I can't roast". Those replies are thrown away and the next model is tried.
const REFUSAL_REGEX = /^\s*(i['’]?m sorry|i am sorry|sorry|i can['’]?t|i cannot|i can not|i['’]?m unable|i am unable|as an ai)/i

let lastBotChatAt = 0 // set in safeChat(), lets the bot notice "you are trash" aimed at it right after it spoke
const roastHistory = new Map() // username -> timestamps of roasts sent to them
let globalRoastTimes = []
const chatMemory = [] // last public lines, so the roast can answer the actual fight
function rememberChatLine(who, text) {
  chatMemory.push({ who, text: String(text).slice(0, 160) })
  if (chatMemory.length > 40) chatMemory.shift()
}
function roastContextFor(user) {
  return chatMemory.filter(l => l.who === user || l.who === 'BOT').slice(-6).map(l => l.who + ': ' + l.text).join('\n')
}
// cut at the end of a sentence (or a space) instead of in the middle of a word
function trimToFit(t, max) {
  if (t.length <= max) return t
  const cut = t.slice(0, max)
  const end = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '), cut.lastIndexOf('? '))
  if (end > 60) return cut.slice(0, end + 1)
  const sp = cut.lastIndexOf(' ')
  return sp > 60 ? cut.slice(0, sp) : cut
}

// Anti-spam + anti bot-vs-bot loop: 20s gap per player, max 4 per player per 10 min, max 6 per minute total
function roastBudgetOk(user) {
  const now = Date.now()
  globalRoastTimes = globalRoastTimes.filter(t => now - t < 60000)
  if (globalRoastTimes.length >= 8) return false
  const mine = (roastHistory.get(user) || []).filter(t => now - t < 600000)
  roastHistory.set(user, mine)
  if (mine.length >= 8) return false
  if (mine.length && now - mine[mine.length - 1] < 12000) return false
  return true
}

// ms left until we may roast this player again (0 = free)
function roastGapLeft(user) {
  const mine = roastHistory.get(user) || []
  if (!mine.length) return 0
  return Math.max(0, 12000 - (Date.now() - mine[mine.length - 1]))
}
const pendingRoast = new Map() // username -> newest line that arrived during the gap

function roastBudgetSpend(user) {
  const now = Date.now()
  globalRoastTimes.push(now)
  const mine = roastHistory.get(user) || []
  mine.push(now)
  roastHistory.set(user, mine)
}

// Asks the AI: is this chat message insulting / mocking our people? (falls back to the old keyword check if AI is down)
async function aiSaysInsult(username, text) {
  const out = await callGroq('Speaker: ' + username + '\nMessage: "' + text + '"', 'judge')
  if (out === null) return INSULT_REGEX.test(text) && PROTECTED_REGEX.test(text)
  return /\byes\b/i.test(out) && !/\bno\b/i.test(out)
}

async function autoRoastWatcher(username, text, isOwner, replay = false) {
  if (!bot || !minecraftOnline) return
  const user = String(username || '')
  const lowerUser = user.toLowerCase()
  if (!user || lowerUser === String(bot.username || '').toLowerCase()) return
  if (!replay) rememberChatLine(user, text)
  if (isOwner || isBossName(user)) return                 // bosses are never roasted
  if (AUTO_ROAST_IGNORE.has(lowerUser)) return
  if (/^[!<~.^?$\/]/.test(text)) return                   // commands are handled elsewhere
  if (AUTO_ROAST_AD_REGEX.test(text)) return              // ads / invites
  if (text.length < 4 || text.length > 220) return

  // Cheap filter so the AI is not called for every line of chat:
  // the message names one of our people, OR it talks to the bot right after the bot spoke.
  const mentionsTarget = AUTO_ROAST_NAME_REGEX.test(text)
  const talkingToBot = Date.now() - lastBotChatAt < 30000 && AUTO_ROAST_ADDRESS_REGEX.test(text)
  if (!mentionsTarget && !talkingToBot) return

  // Fast talkers (like MossadBot) answer in under a second. Instead of dropping their next line during the gap,
  // keep only the newest one and answer it as soon as the gap is over, so the bot keeps up with the fight.
  const wait = roastGapLeft(lowerUser)
  if (wait > 0) {
    const alreadyWaiting = pendingRoast.has(lowerUser)
    pendingRoast.set(lowerUser, text)
    if (!alreadyWaiting) {
      setTimeout(() => {
        const latest = pendingRoast.get(lowerUser)
        pendingRoast.delete(lowerUser)
        if (latest) autoRoastWatcher(user, latest, isOwner, true).catch(e => log('Auto-roast error: ' + (e && e.message)))
      }, wait + 300)
    }
    return
  }
  if (!roastBudgetOk(lowerUser)) return
  if (!replay && onAiCooldown('judge:' + lowerUser, 1500)) return

  if (!(await aiSaysInsult(user, text))) return
  if (!roastBudgetOk(lowerUser)) return                   // re-check, time passed while the AI was thinking
  roastBudgetSpend(lowerUser)

  roastContextForNext = roastContextFor(user)
  let roast = await askGroqAI('"' + text + '"', user, 'roast')
  const suffix = ' - ' + user
  if (roast.endsWith(suffix)) roast = roast.slice(0, -suffix.length) // the prefix already names the target

  const nameLead = new RegExp('^\\s*["\']?' + user.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '["\']?\\s*[:,\\-]\\s*', 'i')
  roast = roast.replace(nameLead, '')
  const prefix = user + ': ' // public chat, tag the target so everyone sees who is being roasted
  const body = trimToFit(roast.replace(/[\r\n]+/g, ' ').trim(), 250 - prefix.length)
  if (!body) return
  log('[AUTO-ROAST] ' + user + ' said "' + text + '" -> ' + body)
  rememberChatLine('BOT', body)
  safeChat(prefix + body)
}
// ================= END AUTO ROAST WATCHER =================

// ================= JOKES (real life, clean) =================
const JOKES = [
  'I told my boss three companies were after me and I needed a raise. He asked which ones. I said gas, electric and water.',
  'I am on a seafood diet. I see food and I eat it.',
  'I would tell you a construction joke, but I am still working on it.',
  'My bed is a magical place where I suddenly remember everything I forgot to do.',
  'I started a new job at a calendar factory, but I got fired because I took a couple of days off.',
  'Why do not scientists trust atoms? Because they make up everything.',
  'I told my wife she was drawing her eyebrows too high. She looked surprised.',
  'My Wi-Fi went down for five minutes, so I talked to my family. They seem nice.',
  'I used to hate facial hair, but then it grew on me.',
  'Why did the scarecrow get promoted? He was outstanding in his field.',
  'I do not trust stairs. They are always up to something.',
  'I am reading a book about anti-gravity. It is impossible to put down.',
  'Why did the coffee file a police report? It got mugged.',
  'Adulthood is just saying "I will do it tomorrow" for 40 years.',
  'I asked the gym instructor if he could teach me to do the splits. He said, how flexible are you? I said, I cannot make Tuesdays.',
  'The early bird gets the worm, but the second mouse gets the cheese.',
  'I have a lot of growing up to do. I called my mom yesterday to tell her that.',
  'Why did the bike fall over? It was two tired.',
  'My phone is at 1 percent and so is my motivation, but only one of them is getting charged.',
  'I told my computer I needed a break, and now it will not stop sending me vacation ads.',
  'I tried to be normal once. Worst two minutes of my life.',
  'They say money cannot buy happiness, but it can buy pizza, and that is basically the same thing.',
  'Why do not skeletons fight each other? They do not have the guts.',
  'I asked my dog what two minus two is. He said nothing.',
  'My alarm clock and I have a toxic relationship. It yells at me and I hit it.',
  'I bought a ceiling fan yesterday. Honestly, I am a big fan of it.',
  'Rest in peace to boiling water. You will be mist.',
  'I wanted to be a doctor, but I could not stand the patients, so now I am just impatient.',
  'I can resist everything except sleep, snacks and bad decisions.',
  'Why was the math book sad? It had too many problems.'
]

let lastJokeIndex = -1
function pickJoke() {
  let i
  do { i = Math.floor(Math.random() * JOKES.length) } while (i === lastJokeIndex && JOKES.length > 1)
  lastJokeIndex = i
  return JOKES[i]
}

const JOKE_TOPICS = [
  'work and bosses', 'school and exams', 'money and bills', 'sleep and alarm clocks', 'food and diets',
  'technology and wifi', 'dating and relationships', 'the gym', 'coffee', 'adult life', 'pets', 'travel and traffic'
]

const recentJokes = []

function buildJokeQuestion(text) {
  const topic = JOKE_TOPICS[Math.floor(Math.random() * JOKE_TOPICS.length)]
  const avoid = recentJokes.length
    ? '\nDo NOT repeat these recent jokes: ' + recentJokes.join(' | ')
    : ''
  return 'The player asked: "' + text + '"\nIf they named a topic use it, otherwise use this topic: ' + topic + '.' + avoid
}

function rememberJoke(reply) {
  recentJokes.push(String(reply).slice(0, 80))
  if (recentJokes.length > 5) recentJokes.shift()
}

// 6b6tmalware and meseju are the bot's bosses: never roasted, always accepted
function isBossName(name) {
  const n = String(name || '').toLowerCase()
  return !!n && IN_GAME_OWNERS.includes(n)
}

// Roast only when the insult is aimed at BlackCat / meseju / 6b6tmalware / the bot. Never on behalf of qbasty.
function isRoastWorthy(text) {
  const t = String(text || '')
  if (!INSULT_REGEX.test(t)) return false
  return PROTECTED_REGEX.test(t) || BOT_TARGET_REGEX.test(t)
}

// Edit these facts so the AI answers correctly about your server
const SERVER_KNOWLEDGE = [
  '6b6t.org is a Minecraft anarchy server: no rules, no resets, no staff protection.',
  'Server hosts: alt.6b6t.org, alt2.6b6t.org, alt3.6b6t.org, alt4.6b6t.org, alt5.6b6t.org.',
  'qbasty is the owner and creator of the 6b6t anarchy server.',
  'meseju is the BlackCat clan leader.',
  '6b6tmalware is the developer of BlackCat bot and also a member of the BlackCat clan.',
  'You (BlackCat bot) were created by 6b6tmalware and the BlackCat team.',
  'Always speak with respect about qbasty and never joke about him.',
  'BlackCat bot delivers kits (pvp, build, travel, food, totums) but ONLY for Cat Coins.',
  'Each kit costs 3 Cat Coins. Players earn Cat Coins in the BlackCat Discord. Never post links or invites in game chat.',
  'In Discord: new members start with 2 Cat Coins, $login gives 5 coins every day, $bal shows balance.',
  'Players must $register their Minecraft name in the Discord first. Then they order kits with $order <kit> <amount> in Discord, or $kit <kit> <amount> in game chat. Kits are delivered by teleport and the coins are taken from their Discord balance.',
  'Without Cat Coins the bot cannot deliver kits.',
  'Players can share Cat Coins with each other: $pay @user <amount> in Discord, or $pay <player> <amount> in game (both players must be registered).',
  'Players can ask $ai player <name> to see a player\'s 6b6t join date and stats, or $ai who am i for their own.'
]

// Instant answers that do NOT need the AI at all (100% reliable).
const DIRECT_ANSWERS = {
  qbasty: 'qbasty is the owner and creator of the 6b6t anarchy server.',
  '6b6tmalware': '6b6tmalware is my developer and a member of the BlackCat clan.',
  meseju: 'meseju is the BlackCat clan leader.',
  blackcat: 'BlackCat is a 6b6t bot that delivers kits for Cat Coins.'
}

// Per-user cooldown so nobody can spam the AI (ms)
const AI_COOLDOWN_MS = 3000
const aiLastUse = new Map()
// ==========================================================

const AUTHORIZED_USERS = [
  '',
  '',
  '',
  '',
  '',
  '',
  '',
  '',
  '',
  '',
  '',
  ''
]

const IN_GAME_OWNERS = ['6b6tmalware', 'meseju']

const VERSION = '1.21.11'
const SERVERS = ['alt.6b6t.org', 'alt4.6b6t.org', 'alt5.6b6t.org', 'alt2.6b6t.org', 'alt3.6b6t.org']
const SCAN_RADIUS = 32
const TP_ACCEPT_TIMEOUT_MS = 13000 // player must accept the /tpa within 13 seconds, otherwise the request is cancelled

// Sign-labeled kit chests: ANY chest with a sign on it works as a kit — whatever the sign
// says (PVP, PVP2, CPVP2, REDSTONE, anything) is a valid kit name, no admin setup needed.
// KIT_RULES only holds COST OVERRIDES for specific sign names; anything not listed here
// just uses DEFAULT_KIT_COST. Saved into coins.json as kitRules.
const DEFAULT_KIT_COST = 3
const MAX_KITS_PER_ORDER = 6 // nobody can get more than 6 kits in one order
let KIT_RULES = {}

// Chest where undelivered/returned kit shulkers go. Label that chest's sign "RANDOM".
const RANDOM_CHEST_SIGN = 'RANDOM'

function listKitNames() {
  return Object.keys(KIT_RULES).map(k => k.toLowerCase()).join(', ')
}

// ====== COSMETIC SHOP START ======
// Cosmetic marketplace keys (capes, hats, etc) players redeem with Cat Coins. These are
// delivered manually by staff, not by the Minecraft bot: redeeming just spends the coins,
// drops the stock by 1, and posts a log for staff to send the key.
// Price is automatic by default: scarcer stock = higher price. An admin can pin a fixed
// price per item with `$shop price <amount> <item>`, stored as costOverride.
// The shop only works in Discord (SHOP_CHANNEL_ID), never in game.
// Every purchase opens a private ticket channel so staff can hand over the key.
const SHOP_BASE_PRICE = 300 // Cat Coin price when only 1 is in stock; price falls as stock grows
function computeShopPrice(stock) {
  const raw = SHOP_BASE_PRICE / Math.sqrt(Math.max(Number(stock) || 0, 1))
  return Math.max(5, Math.round(raw / 5) * 5)
}

let SHOP_ITEMS = {
  'Focus Retention Helmet': { stock: 1 },
  'Turtle Tunes': { stock: 4 },
  'Moss Mask': { stock: 5 },
  'Parched Hoodie': { stock: 7 },
  'Baby Chick Slippers': { stock: 10 },
  'Hatchling Hat': { stock: 12 },
  'Home Cape': { stock: 12 },
  'Amethyst Drone': { stock: 16 },
  'Frog Hoodie': { stock: 22 },
  'Copper Core': { stock: 30 },
  'Bunny Beanie': { stock: 32 },
  'Copper Cape': { stock: 110 },
  'Aurora Cape': { stock: 213 },
  'Builder Cape': { stock: 271 }
}

function normShopKey(s) {
  return String(s || '').trim().toLowerCase().replace(/\s+/g, ' ')
}

function shopPriceOf(item) {
  return (item && item.costOverride) || computeShopPrice(item ? item.stock : 0)
}

// Case/spacing-insensitive lookup; falls back to a unique substring match ("cape" only
// matches if exactly one item contains it). Returns the item's real stored name, or null.
function findShopItem(query) {
  const q = normShopKey(query)
  if (!q) return null
  for (const name of Object.keys(SHOP_ITEMS)) {
    if (normShopKey(name) === q) return name
  }
  const matches = Object.keys(SHOP_ITEMS).filter(name => normShopKey(name).includes(q))
  return matches.length === 1 ? matches[0] : null
}
// Open shop tickets: channelId -> { number, userId, username, item, price, createdAt }
let TICKETS = {}
let ticketCounter = 0
// ====== COSMETIC SHOP END ======

const CONFIGURATION_SERVERBOUND = new Set([
  'settings', 'cookie_response', 'custom_payload', 'finish_configuration', 'keep_alive',
  'pong', 'resource_pack_receive', 'select_known_packs', 'custom_click_action', 'accept_code_of_conduct'
])
const MOVEMENT = new Set([
  'position', 'position_look', 'look', 'flying', 'player_input',
  'entity_action', 'vehicle_move', 'teleport_confirm'
])
const VANILLA_DIMENSIONS = {
  'minecraft:overworld': [-64, 384],
  'minecraft:overworld_caves': [-64, 384],
  'minecraft:the_nether': [0, 256],
  'minecraft:the_end': [0, 256]
}

let bot = null
let busy = false
let busyTimeout = null
let minecraftOnline = false
let lastOnlineNoticeAt = 0 // max 1 online DM per hour
let serverIndex = 0
let awaitingLogin = false
let dropped = new Set()
let lastTpAcceptTime = 0
let attackInterval = null

// Economy Balances Database (Discord User ID -> Coins) & Daily Claims Tracker
let userBalances = {}
let lastDailyClaim = {} // Discord User ID -> Date String (YYYY-MM-DD)
let registrations = {} // Discord User ID -> Minecraft username
let favoriteScores = {}
let favoritePerson = null

// Gamble: player win rate 45%, house 55%. Stake is lost or doubled.
const GAMBLE_PLAYER_WIN_RATE = 0.45
const GAMBLE_MIN_BET = 1
const GAMBLE_MAX_BET = 50
const GAMBLE_COOLDOWN_MS = 4000
const gambleLastUse = new Map()

const GAMBLE_WIN_LINES = [
  'The coin lands your way.',
  'Luck smiled on you this time.',
  'You beat the house.',
  'Clean win.',
  'Fortune favors you.'
]
const GAMBLE_LOSE_LINES = [
  'The house takes it.',
  'Coin says no.',
  'Bad luck. Stake is gone.',
  'House edge wins again.',
  'Not your flip.'
]

function onGambleCooldown(userId) {
  const now = Date.now()
  const last = gambleLastUse.get(userId) || 0
  if (now - last < GAMBLE_COOLDOWN_MS) return true
  gambleLastUse.set(userId, now)
  return false
}

function runGamble(userId, amount) {
  if (userBalances[userId] === undefined) userBalances[userId] = 2
  const bal = userBalances[userId]
  if (!Number.isInteger(amount) || amount < GAMBLE_MIN_BET) {
    return { ok: false, error: 'min' }
  }
  if (amount > GAMBLE_MAX_BET) {
    return { ok: false, error: 'max' }
  }
  if (bal < amount) {
    return { ok: false, error: 'funds', balance: bal }
  }

  // Deduct stake first (no await between check and write)
  userBalances[userId] -= amount

  const roll = Math.random() // 0..1
  const playerWins = roll < GAMBLE_PLAYER_WIN_RATE

  if (playerWins) {
    // Pay 2x stake (stake already taken, so add 2*amount → net +amount)
    userBalances[userId] += amount * 2
    saveData()
    return {
      ok: true,
      win: true,
      amount,
      balance: userBalances[userId],
      line: GAMBLE_WIN_LINES[Math.floor(Math.random() * GAMBLE_WIN_LINES.length)]
    }
  }

  saveData()
  return {
    ok: true,
    win: false,
    amount,
    balance: userBalances[userId],
    line: GAMBLE_LOSE_LINES[Math.floor(Math.random() * GAMBLE_LOSE_LINES.length)]
  }
}

function log(msg) {
  console.log('[BOT] ' + msg)
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms))
}

// Atomic save: write to a temp file, then rename (a crash can no longer corrupt coins.json)
function saveData() {
  try {
    const tmp = DATA_FILE + '.tmp'
    fs.writeFileSync(tmp, JSON.stringify({
      userBalances,
      lastDailyClaim,
      registrations,
      favoriteScores,
      favoritePerson,
      kitRules: KIT_RULES,
      extraAdminIds,
      shopItems: SHOP_ITEMS,
      tickets: TICKETS,
      ticketCounter
    }))
    fs.renameSync(tmp, DATA_FILE)
  } catch (e) {
    log('Could not save coins: ' + e.message)
  }
}

function loadData() {
  try {
    if (!fs.existsSync(DATA_FILE)) return
    const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'))
    userBalances = data.userBalances || {}
    lastDailyClaim = data.lastDailyClaim || {}
    registrations = data.registrations || {}
    favoriteScores = data.favoriteScores || {}
    favoritePerson = data.favoritePerson || null
    if (data.kitRules && typeof data.kitRules === 'object' && Object.keys(data.kitRules).length) {
      KIT_RULES = data.kitRules
      log('Loaded kit rules: ' + listKitNames())
    }
    if (Array.isArray(data.extraAdminIds)) {
      extraAdminIds = data.extraAdminIds.map(String).filter(Boolean)
      rebuildAdminIds()
      log('Loaded extra admins: ' + extraAdminIds.length)
    }
    if (data.shopItems && typeof data.shopItems === 'object' && Object.keys(data.shopItems).length) {
      SHOP_ITEMS = data.shopItems
      log('Loaded shop items: ' + Object.keys(SHOP_ITEMS).length)
    }
    if (data.tickets && typeof data.tickets === 'object') TICKETS = data.tickets
    if (Number.isInteger(data.ticketCounter)) ticketCounter = data.ticketCounter
    log('Loaded coins for ' + Object.keys(userBalances).length + ' users')
  } catch (e) {
    log('Could not load coins: ' + e.message)
  }
}
loadData()

const discordClient = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ]
})

let discordLoginInProgress = false
let discordReconnectTimer = null

function isIgnorableError(msg) {
  return msg.includes('BigInt') || msg.includes('inflating') || msg.includes('PartialReadError') || msg.includes('uuidFromIntArray')
}

process.on('uncaughtException', (err) => {
  const msg = err && err.message ? err.message : String(err)
  if (isIgnorableError(msg)) return
  console.error('[BOT] Uncaught Exception:', err)
})

process.on('unhandledRejection', (reason) => {
  const msg = reason && reason.message ? reason.message : String(reason)
  if (isIgnorableError(msg)) return
  console.error('[BOT] Unhandled Rejection:', reason)
})

// ====== CHAT SAFETY START ======
// Everything the bot says in game goes through safeChat so the server never sees spam or ads:
//  - links / invites are removed from every message
//  - the same public message is never repeated within 60 seconds
//  - public chat is spaced 3.5s apart, whispers 1.5s apart
//  - real commands (/tpa, /login, /kill ...) are sent instantly
const URL_REGEX = /https?:\/\/\S+|\b(?:discord\.gg|discord\.com\/invite)\/\S*/gi
const PUBLIC_CHAT_GAP_MS = 3500
const WHISPER_GAP_MS = 1500
const chatQueue = []
const recentPublicChat = new Map()
let chatQueueRunning = false
let lastChatSentAt = 0

function sendChatNow(text) {
  try {
    if (bot && bot._client && bot._client.state === 'play' && !awaitingLogin) bot.chat(text)
  } catch {}
}

async function runChatQueue() {
  if (chatQueueRunning) return
  chatQueueRunning = true
  try {
    while (chatQueue.length) {
      const item = chatQueue.shift()
      const wait = lastChatSentAt + item.gap - Date.now()
      if (wait > 0) await sleep(wait)
      sendChatNow(item.text)
      lastChatSentAt = Date.now()
    }
  } finally {
    chatQueueRunning = false
  }
}

function safeChat(msg) {
  // Links are stripped everywhere, EXCEPT our own Discord invite inside a private whisper (/msg player ...)
  const wasWhisper = /^\s*\/(msg|w|tell)\s/i.test(String(msg || ''))
  const text = String(msg || '')
    .replace(URL_REGEX, m => (wasWhisper && m.toLowerCase() === DISCORD_INVITE.toLowerCase()) ? m : '')
    .replace(/\|?\s*Wiki:\s*$/i, '')
    .replace(/\s{2,}/g, ' ')
    .trim()
  if (!text) return

  const isCommand = text.startsWith('/')
  const isWhisper = /^\/(msg|w|tell)\s/i.test(text)
  if (!isCommand) lastBotChatAt = Date.now()

  if (isCommand && !isWhisper) {
    sendChatNow(text)
    return
  }

  if (!isCommand) {
    const key = text.toLowerCase()
    const now = Date.now()
    if (now - (recentPublicChat.get(key) || 0) < 60000) return
    recentPublicChat.set(key, now)
    if (recentPublicChat.size > 200) {
      for (const [k, t] of recentPublicChat) if (now - t > 60000) recentPublicChat.delete(k)
    }
  }

  while (chatQueue.length >= 8) chatQueue.shift()
  chatQueue.push({ text, gap: isWhisper ? WHISPER_GAP_MS : PUBLIC_CHAT_GAP_MS })
  runChatQueue()
}
// ====== CHAT SAFETY END ======

// ================= AI FUNCTIONS =================

// Looks for an instant answer in DIRECT_ANSWERS
function findDirectAnswer(question) {
  const q = question.toLowerCase()
  for (const key of Object.keys(DIRECT_ANSWERS)) {
    if (q.includes(key)) return DIRECT_ANSWERS[key]
  }
  if (KIT_QUESTION_REGEX.test(question)) return KIT_INFO
  return null
}

// ====== WIKI START ======
const CLAN_URL = 'https://6b.wiki/Wiki/List_of_clans'
const CLAN_WIKI_BASE = 'https://6b.wiki/Wiki/'

let clanCache = { rows: [], time: 0 }
const clanPageCache = new Map()

function cleanHtml(str) {
  return String(str || '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&quot;/gi, '"')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#0?39;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)))
    .replace(/&amp;/gi, '&')
    .replace(/\s+/g, ' ')
    .trim()
}

function normName(str) {
  return String(str || '').toLowerCase().replace(/[^a-z0-9]/g, '')
}

function wikiPageName(str) {
  return String(str || '').trim().replace(/\s+/g, '_')
}

function cut(s, n = 60) {
  const t = String(s || '')
  return t.length > n ? t.slice(0, n - 3) + '...' : t
}

// Table columns on the wiki: Name | Date Founded | Date Disbanded | Owners | Note
async function getClanRows() {
  const now = Date.now()
  if (clanCache.rows.length && now - clanCache.time < 1800000) return clanCache.rows

  try {
    const res = await axios.get(CLAN_URL, {
      timeout: 15000,
      responseType: 'text',
      headers: { 'User-Agent': 'Mozilla/5.0 BlackCatBot/1.0' }
    })

    const html = String(res.data || '')
    const rows = []

    for (const tr of html.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const rawCells = [...tr.matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m => m[1])
      const cells = rawCells.map(cleanHtml)

      if (cells.length < 4 || !cells[0] || /^name$/i.test(cells[0])) continue

      // does this clan have its own wiki page? (red links = page does not exist)
      const href = (rawCells[0].match(/href="([^"]+)"/i) || [])[1] || ''
      const slugMatch = href.match(/\/Wiki\/([^?#"]+)/i)
      let slug = ''
      if (slugMatch && !/redlink=1/i.test(href)) {
        try { slug = decodeURIComponent(slugMatch[1]) } catch { slug = slugMatch[1] }
      }

      rows.push({
        name: cells[0],
        founded: cells[1] || '',
        disbanded: cells[2] || '',
        owners: (cells[3] || '').split(',').map(o => o.trim()).filter(Boolean),
        note: cells[4] || '',
        slug
      })
    }

    if (rows.length) {
      clanCache = { rows, time: now }
      log('[WIKI] Loaded ' + rows.length + ' clans')
      return rows
    }

    log('[WIKI] Page loaded but no clan rows were found')
  } catch (e) {
    log('[WIKI] Could not load clan list: ' + e.message)
  }

  return clanCache.rows.length ? clanCache.rows : null
}

// loose = also allow startsWith / includes (only for 4+ characters)
function pickClan(rows, wanted, loose) {
  const exact = rows.filter(r => normName(r.name) === wanted)
  if (exact.length) return exact.find(r => !r.disbanded) || exact[0]

  if (!loose || wanted.length < 4) return null

  return (
    rows.find(r => normName(r.name).startsWith(wanted)) ||
    rows.find(r => normName(r.name).includes(wanted)) ||
    null
  )
}

// Finds every clan where this player is listed as an owner
function findPlayerClans(rows, wanted, loose) {
  const exact = []
  const near = []

  for (const r of rows) {
    for (const o of r.owners) {
      const n = normName(o)
      if (!n) continue
      if (n === wanted) exact.push({ clan: r, owner: o })
      else if (loose && wanted.length >= 4 && n.startsWith(wanted)) near.push({ clan: r, owner: o })
    }
  }

  if (exact.length) return exact

  // loose match only if it points to exactly one player
  const names = new Set(near.map(x => normName(x.owner)))
  return names.size === 1 ? near : []
}

async function findClan(clanName) {
  const rows = await getClanRows()
  if (!rows) return null
  const wanted = normName(clanName)
  if (!wanted) return null
  return pickClan(rows, wanted, true)
}

function extractWikiFields(html) {
  const fields = {}

  const rowRegex = /<tr[\s\S]*?<th[^>]*>([\s\S]*?)<\/th>[\s\S]*?<td[^>]*>([\s\S]*?)<\/td>[\s\S]*?<\/tr>/gi
  for (const match of html.matchAll(rowRegex)) {
    const key = cleanHtml(match[1])
    const value = cleanHtml(match[2])
    if (!key || !value) continue
    fields[key.toLowerCase()] = value
  }

  const boldRegex = /<b[^>]*>([\s\S]*?)<\/b>\s*:?[ \t]*([\s\S]{1,800}?)(?=<br|<\/p|<\/li|$)/gi
  for (const match of html.matchAll(boldRegex)) {
    const key = cleanHtml(match[1])
    const value = cleanHtml(match[2])
    if (!key || !value) continue
    const k = key.toLowerCase()
    if (!fields[k]) fields[k] = value
  }

  return fields
}

// Only opens the clan's own wiki page if it really exists (no red link)
async function getClanWikiPage(clan) {
  if (!clan || !clan.slug) return null

  const cacheKey = normName(clan.slug)
  const cached = clanPageCache.get(cacheKey)
  if (cached && Date.now() - cached.time < 1800000) return cached

  const url = CLAN_WIKI_BASE + encodeURIComponent(clan.slug)

  try {
    const res = await axios.get(url, {
      timeout: 15000,
      responseType: 'text',
      headers: { 'User-Agent': 'Mozilla/5.0 BlackCatBot/1.0' }
    })

    const html = String(res.data || '')
    const result = { url, html, fields: extractWikiFields(html), time: Date.now() }
    clanPageCache.set(cacheKey, result)
    return result
  } catch (e) {
    log('[WIKI] Could not open clan page ' + clan.slug + ': ' + e.message)
    return null
  }
}

function getField(fields, names) {
  for (const name of names) {
    const key = name.toLowerCase()
    if (fields[key] !== undefined && fields[key] !== '') return fields[key]
  }
  return ''
}

function formatClanInfo(clan, page) {
  const f = (page && page.fields) || {}

  const leader = getField(f, ['leader', 'leaders', 'clan leader', 'founder', 'founders'])
  const members = getField(f, ['members', 'member', 'current members'])
  const status = getField(f, ['status', 'current status'])
  const allies = getField(f, ['allies', 'alliances', 'allied clans'])
  const enemies = getField(f, ['enemies', 'enemy clans', 'rivals'])

  const parts = [clan.name]

  parts.push('Status: ' + (status ? cut(status) : clan.disbanded ? 'Disbanded ' + clan.disbanded : 'Active'))

  if (leader) parts.push('Leader: ' + cut(leader))

  if (clan.owners.length) parts.push('Owners: ' + cut(clan.owners.join(', '), 70))
  else if (!leader) parts.push('Owners: not listed on the wiki')

  if (members) parts.push('Members: ' + cut(members))
  if (clan.founded) parts.push('Founded: ' + clan.founded)
  if (clan.disbanded && status) parts.push('Disbanded: ' + clan.disbanded)
  if (allies) parts.push('Allies: ' + cut(allies, 50))
  if (enemies) parts.push('Enemies: ' + cut(enemies, 50))
  if (clan.note) parts.push('Note: ' + cut(clan.note, 70))

  return parts.join(' | ')
}

function formatPlayerInfo(hits) {
  const name = hits[0].owner

  const sorted = [...hits].sort((a, b) => (a.clan.disbanded ? 1 : 0) - (b.clan.disbanded ? 1 : 0))

  const shown = sorted.slice(0, 4).map(h =>
    h.clan.name + ' (' + (h.clan.disbanded ? 'disbanded ' + h.clan.disbanded : 'active') + ')'
  )

  const more = sorted.length > 4 ? ' +' + (sorted.length - 4) + ' more' : ''

  return name + ' is an owner/leader of ' + shown.join(', ') + more + ' on 6b6t.'
}

// ---------- question understanding ----------

const WIKI_INTENT_REGEX =
  /\b(clan|clans|leader|leaders|owner|owners|owns|leads|founded|disbanded|members?|wiki|who is|who's|whos|tell me about|info|information|details?|about)\b/i

const WIKI_CLAN_WORD_REGEX = /\b(clan|clans|leader|leaders|owner|owners|owns|leads)\b/i

const WIKI_FILLER_REGEX =
  /\b(tell|me|about|info|information|details?|on|of|the|what|what's|whats|is|are|was|who|who's|whos|leader|leaders|owner|owners|owns|own|leads|lead|members?|clan|clans|in|6b6t|wiki|when|did|found|founded|an|a|please|pls|do|you|know|any|player|guy|show|give|search|find|check|and|his|her|their|which|does|to|for|from)\b/gi

// returns [{ text, word }]  (word = single word taken out of a longer sentence)
function wikiCandidates(question) {
  const q = String(question || '')
    .trim()
    .replace(/[?!.,]+$/g, '')
    .replace(/\s+(?:on|in)\s+6b6t$/i, '')
    .trim()

  const out = []
  const seen = new Set()

  const add = (text, word = false) => {
    const t = String(text || '').replace(/[?!.,]+$/g, '').replace(/\s+/g, ' ').trim()
    const n = normName(t)
    if (n.length < 3 || seen.has(n)) return
    seen.add(n)
    out.push({ text: t, word })
  }

  const patterns = [
    /\b(?:tell me about|info on|information on|details on|details about|what is|what's|whats|who is|who's|whos|what about)\s+(?:the\s+)?(.+?)(?:\s+clan)?$/i,
    /\b(?:who leads|who is the leader of|leader of|who owns|owner of|owners? of|members? of|when was|when did)\s+(?:the\s+)?(.+?)(?:\s+clan)?$/i,
    /\bis\s+(?:the\s+)?(.+?)\s+(?:a\s+)?(?:clan|leader|owner)\b/i,
    /^(.+?)\s+(?:clan|leader|owner|info|details?)$/i,
    /^(?:clan|player)\s+(.+)$/i
  ]

  for (const p of patterns) {
    const m = q.match(p)
    if (m) add(m[1])
  }

  add(q)
  add(q.replace(WIKI_FILLER_REGEX, ' '))

  // single words, only when the question is short or clearly about clans/players
  const words = q.replace(WIKI_FILLER_REGEX, ' ').split(/\s+/).filter(w => normName(w).length >= 3)
  if (q.split(/\s+/).length <= 2 || WIKI_INTENT_REGEX.test(q)) {
    for (const w of words) add(w, true)
  }

  return out
}

// Looks the question up in the 6b wiki clan list (clans AND owners/leaders).
async function lookupWiki(question) {
  const q = String(question || '').trim()
  if (!q) return null

  const rows = await getClanRows()
  if (!rows) return null

  const candidates = wikiCandidates(q)
  if (!candidates.length) return null

  // pass 1: exact clan name, then exact player name
  for (const c of candidates) {
    const wanted = normName(c.text)

    const clan = pickClan(rows, wanted, false)
    if (clan) {
      const page = await getClanWikiPage(clan)
      return formatClanInfo(clan, page)
    }

    const hits = findPlayerClans(rows, wanted, false)
    if (hits.length) return formatPlayerInfo(hits)
  }

  // pass 2: loose match (4+ characters, full phrases only)
  for (const c of candidates) {
    if (c.word) continue
    const wanted = normName(c.text)

    const clan = pickClan(rows, wanted, true)
    if (clan) {
      const page = await getClanWikiPage(clan)
      return formatClanInfo(clan, page)
    }

    const hits = findPlayerClans(rows, wanted, true)
    if (hits.length) return formatPlayerInfo(hits)
  }

  // asked clearly about a clan / leader but nothing found: say so instead of letting the AI guess
  if (WIKI_CLAN_WORD_REGEX.test(q)) {
    return 'I could not find "' + cut(candidates[0].text, 30) + '" in the 6b wiki clan list.'
  }

  return null
}

async function answerClanQuestion(question) {
  return lookupWiki(question)
}

async function answerDirectClanLookup(question) {
  const q = String(question || '').trim()
  if (!q) return null

  if (WHO_AM_I_REGEX.test(q) || CREATOR_REGEX.test(q) || KIT_QUESTION_REGEX.test(q) || FAVORITE_QUESTION_REGEX.test(q)) {
    return null
  }

  const answer = await lookupWiki(q)
  log('[WIKI] "' + q + '" -> ' + (answer ? 'answered' : 'no match'))
  return answer
}
// ====== WIKI END ======

// ====== PLAYER STATS START ======
// Reads https://www.6b6t.org/stats/<name> (server-rendered page: "Member since" date + stats table)
const STATS_BASE = 'https://www.6b6t.org/stats/'
const MC_NAME_REGEX = /^[A-Za-z0-9_]{3,16}$/
const playerStatsCache = new Map()

async function getPlayerStats(name) {
  const key = String(name).toLowerCase()
  const cached = playerStatsCache.get(key)
  if (cached && Date.now() - cached.time < 300000) return cached.data

  let data
  try {
    const res = await axios.get(STATS_BASE + encodeURIComponent(name), {
      timeout: 15000,
      responseType: 'text',
      headers: { 'User-Agent': 'Mozilla/5.0 BlackCatBot/1.0' },
      validateStatus: s => s < 500
    })

    const html = String(res.data || '')
    const joinMatch = cleanHtml(html).match(/Member since\s*(\d{1,2}\/\d{1,2}\/\d{4})/i)

    const stats = {}
    for (const tr of html.match(/<tr[\s\S]*?<\/tr>/gi) || []) {
      const cells = [...tr.matchAll(/<t[dh][^>]*>([\s\S]*?)<\/t[dh]>/gi)].map(m => cleanHtml(m[1]))
      if (cells.length >= 4 && cells[0] && !/^stat$/i.test(cells[0])) {
        stats[cells[0].toLowerCase()] = { d7: cells[1], d30: cells[2], total: cells[3] }
      }
    }

    if (res.status === 404 || (!joinMatch && !Object.keys(stats).length)) {
      data = { found: false }
    } else {
      const h1 = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)
      data = {
        found: true,
        name: (h1 && cleanHtml(h1[1])) || name,
        joined: joinMatch ? joinMatch[1] : '',
        stats
      }
    }
  } catch (e) {
    log('[STATS] Could not load stats for ' + name + ': ' + e.message)
    return { found: false, error: true } // not cached, so it retries next time
  }

  playerStatsCache.set(key, { data, time: Date.now() })
  return data
}

// "Clan owner: X (disbanded), Y" from the 6b wiki clan list
async function clanOwnerNote(name) {
  const rows = await getClanRows()
  if (!rows) return ''
  const hits = findPlayerClans(rows, normName(name), false)
  if (!hits.length) return ''
  const sorted = [...hits].sort((a, b) => (a.clan.disbanded ? 1 : 0) - (b.clan.disbanded ? 1 : 0))
  const names = sorted.slice(0, 2).map(h => h.clan.name + (h.clan.disbanded ? ' (disbanded)' : ''))
  return 'Clan owner: ' + names.join(', ') + (sorted.length > 2 ? ' +' + (sorted.length - 2) : '')
}

// Builds the player line. Returns { ok, name, joined, text } or { ok:false, error? }
async function playerSummary(name) {
  const data = await getPlayerStats(name)
  if (data.error) return { ok: false, error: true }
  if (!data.found) return { ok: false }

  const s = data.stats || {}
  const parts = []

  if (data.joined) parts.push('Joined: ' + data.joined)

  const play = s['playtime']
  if (play) parts.push('Playtime: ' + play.total + (play.d7 ? ' (7d: ' + play.d7 + ')' : ''))
  if (s['kills']) parts.push('Kills: ' + s['kills'].total)
  if (s['deaths']) parts.push('Deaths: ' + s['deaths'].total)

  let clan = ''
  try { clan = await clanOwnerNote(data.name) } catch {}
  if (clan) parts.push(clan)

  return { ok: true, name: data.name, joined: data.joined, text: parts.join(' | ') }
}

const PLAYER_STOP_NAMES = new Set([
  'owner', 'leader', 'creator', 'bot', 'dev', 'developer', 'admin', 'server', 'game', 'you',
  'this', 'that', 'it', 'him', 'her', 'them', 'someone', 'anyone', 'god', 'king', 'blackcat'
])

const STATS_WORDS = /\b(stats?|profile|playtime|kills|deaths)\b/i

// Understands: "player X", "stats X", "when did X join", "join date of X", "my stats",
// "when did i join", "how long has X played", and ambiguous "who is X" / "tell me about X"
function parsePlayerQuestion(q, asker) {
  const text = String(q || '').trim().replace(/[?!.,]+$/g, '').trim()
  if (!text) return null

  const joinOnlyOf = t => /\b(join|joined|member since|since when)\b/i.test(t) && !STATS_WORDS.test(t)
  let m

  if (/\b(my\s+(?:stats?|profile|playtime|join\s*date|kills|deaths)|when\s+did\s+i\s+join|how\s+long\s+have\s+i\s+played)\b/i.test(text)) {
    return { name: asker, joinOnly: joinOnlyOf(text), ambiguous: false }
  }

  if ((m = text.match(/^(?:player|stats?|profile)\s+(?:of\s+|for\s+|on\s+)?([A-Za-z0-9_]{3,16})$/i))) {
    return { name: m[1], joinOnly: false, ambiguous: false }
  }

  if ((m = text.match(/\bwhen\s+did\s+([A-Za-z0-9_]{3,16})\s+join\b/i))) {
    return { name: m[1], joinOnly: true, ambiguous: false }
  }

  if ((m = text.match(/\b(?:join\s*date|joined|playtime|kills|deaths|stats?|profile)\s+(?:of|for)\s+([A-Za-z0-9_]{3,16})$/i))) {
    return { name: m[1], joinOnly: /join/i.test(m[0]), ambiguous: false }
  }

  if ((m = text.match(/\bhow\s+long\s+has\s+([A-Za-z0-9_]{3,16})\s+played\b/i))) {
    return { name: m[1], joinOnly: false, ambiguous: false }
  }

  if ((m = text.match(/^(?:who\s+is|who's|whos|tell\s+me\s+about|info\s+on|information\s+on|what\s+about)\s+(?:the\s+)?(?:player\s+)?([A-Za-z0-9_]{3,16})$/i))) {
    return { name: m[1], joinOnly: false, ambiguous: true }
  }

  return null
}

async function answerPlayerQuestion(question, asker) {
  const p = parsePlayerQuestion(question, asker)
  if (!p || !p.name || !MC_NAME_REGEX.test(p.name)) return null
  if (p.ambiguous && PLAYER_STOP_NAMES.has(p.name.toLowerCase())) return null

  // "who is Saturn" where Saturn is a clan: let the wiki clan lookup answer
  if (p.ambiguous) {
    const rows = await getClanRows()
    if (rows && pickClan(rows, normName(p.name), false)) return null
  }

  const info = await playerSummary(p.name)

  if (info.error) return 'I cannot reach the 6b6t stats page right now, try again in a bit.'

  if (!info.ok) {
    if (p.ambiguous) return null // maybe it is something else, let the other handlers try
    return 'I could not find player "' + cut(p.name, 20) + '" on the 6b6t stats page.'
  }

  if (p.joinOnly && info.joined) return info.name + ' joined 6b6t on ' + info.joined + '.'

  return info.name + ' | ' + info.text
}

// "$ai who am i" -> reads the asker's own stats page (join date etc.) plus their role / clan
async function answerWhoAmI(username) {
  const n = normName(username)
  const role =
    n === 'qbasty' ? 'the owner and creator of 6b6t'
    : n === '6b6tmalware' ? 'my developer and a BlackCat member'
    : n === 'meseju' ? 'the BlackCat clan leader'
    : ''

  const info = MC_NAME_REGEX.test(String(username || '')) ? await playerSummary(username) : { ok: false }

  if (info.ok) return 'You are ' + info.name + (role ? ', ' + role : '') + ' | ' + info.text

  if (role) return 'You are ' + username + ', ' + role + '!'

  const rows = await getClanRows()
  if (rows && n.length >= 3) {
    const hits = findPlayerClans(rows, n, false)
    if (hits.length) return 'You are famous! ' + formatPlayerInfo(hits)
  }

  return info.error
    ? 'I cannot reach the 6b6t stats page right now, try again in a bit.'
    : 'I could not find you on the 6b6t stats page.'
}
// ====== PLAYER STATS END ======

// ====== FAVORITE PERSON START ======
const GOOD_BEHAVIOR_REGEX = [
  /\bgood bot\b/i, /\bnice bot\b/i, /\bgreat bot\b/i, /\bbest bot\b/i, /\bw bot\b/i,
  /\bw\s*blackcat\b/i, /\bthank(?:s| you)\b/i, /\bthx\b/i, /\bty\b/i, /\brespect\b/i,
  /\bhelpful\b/i, /\bhelped me\b/i, /\byou(?:'re|re| are) useful\b/i,
  /\bi love this bot\b/i, /\blove you bot\b/i, /\bgoat bot\b/i
]

const FAVORITE_QUESTION_REGEX = /\b(?:who|who's|whos)\s+(?:is\s+)?(?:your|ur)\s+(?:favorite|favourite)\s+(?:person|player|human)\b/i

function updateFavoritePerson(username, message) {
  const name = String(username || '').trim()
  const text = String(message || '').trim()
  if (!name || !text) return
  if (name.toLowerCase() === String(USERNAME || '').toLowerCase()) return
  if (!GOOD_BEHAVIOR_REGEX.some(regex => regex.test(text))) return

  const key = normName(name)
  if (!key) return
  if (!favoriteScores[key]) favoriteScores[key] = { name, score: 0 }
  favoriteScores[key].name = name
  favoriteScores[key].score += 1

  const all = Object.values(favoriteScores).sort((a, b) => b.score - a.score)
  favoritePerson = all.length ? all[0].name : null
  saveData()
  log('[FAVORITE] ' + name + ' gained a point. Score=' + favoriteScores[key].score + '. Favorite=' + (favoritePerson || 'none'))
}

function getFavoriteAnswer() {
  if (!favoritePerson) return 'I do not have a favorite person yet. Be nice to me and maybe you will become one.'
  const score = (favoriteScores[normName(favoritePerson)] || {}).score || 0
  return 'My favorite person on 6b6t is ' + favoritePerson + '. They have ' + score + ' favorite points.'
}
// ====== FAVORITE PERSON END ======

const groqHeaders = () => ({
  Authorization: 'Bearer ' + GROQ_API_KEY,
  'Content-Type': 'application/json'
})

let modelCache = { list: [], time: 0 }
const badModels = new Map() // model -> time it failed

function modelRank(id) {
  const i = PREFERRED_MODELS.indexOf(id)
  return i === -1 ? 999 : i
}

// Asks Groq which models this key can actually use
async function getGroqModels() {
  const now = Date.now()
  if (modelCache.list.length && now - modelCache.time < 600000) return modelCache.list
  try {
    const res = await axios.get('https://api.groq.com/openai/v1/models', {
      headers: groqHeaders(),
      timeout: 8000
    })
    const ids = ((res.data && res.data.data) || [])
      .filter(m => m && m.id && m.active !== false)
      .map(m => m.id)
      .filter(id => !/whisper|tts|guard|orpheus|playai|embed|safeguard/i.test(id))
    if (ids.length) {
      ids.sort((a, b) => modelRank(a) - modelRank(b))
      modelCache = { list: ids, time: now }
      log('[AI] Models available to your key: ' + ids.join(', '))
      return ids
    }
  } catch (e) {
    const status = e.response && e.response.status
    log('[AI] Could not list models (' + (status || 'no status') + '): ' + (e.response ? JSON.stringify(e.response.data) : e.message))
    if (status === 401) return null
  }
  return PREFERRED_MODELS
}

function buildSystemPrompt(mode) {
  if (mode === 'judge') {
    return 'You are a chat moderation classifier for a Minecraft server bot. ' +
      'The bot protects these targets: BlackCat (a clan), meseju (the BlackCat clan leader), 6b6tmalware (the bot developer) and malwarebotpvp (the bot itself). ' +
      'Names are case-insensitive and may be spelled differently, for example Malwarebotpvp, MALWAREBOTPVP, malware bot, black cat, Meseju, 6B6TMalware. They all count. ' +
      'Decide whether the chat message insults, mocks, trash-talks, threatens or disrespects any of them, ' +
      'directly or indirectly (for example calling the bot names, or telling the bot it is bad, dumb or trash). ' +
      'Neutral mentions, questions, commands, compliments, friendly jokes and insults aimed at other people are NO. ' +
      'Answer with exactly one word: YES or NO.'
  }

  const base =
    'You are BlackCat bot on the 6b6t Minecraft anarchy server. ' +
    'Facts you know:\n- ' + SERVER_KNOWLEDGE.join('\n- ') + '\n'

  const rules =
    'Always answer in ONE short sentence (two at most for a joke), under 150 characters. No markdown, no emojis. ' +
    'Never use slurs, never attack race, religion, gender, disability, body or appearance, or anyone\'s family or parents, ' +
    'never threaten real-life harm. Never write any link, URL or invite.'

  if (mode === 'roast') {
    return base +
      'Someone in chat is insulting or making fun of BlackCat, meseju, 6b6tmalware or you (malwarebotpvp). You defend them. ' +
      'This is 6b6t, an anarchy server with no rules, so the roast must be RAW, savage and personal, not polite and not kid-friendly. Swear freely. ' +
      'You are the best roast comedian in the chat. A great roast: (1) answers what they JUST said, quoting or twisting their exact words, ' +
      '(2) makes logical sense and every sentence lands, (3) goes after something real about them, like their repetitive script, weak threats, ' +
      'empty confidence, lame comeback, how hard they are trying, (4) is short and cold with the punchline in the last words. ' +
      'Before answering, silently think of three different roasts and output only the funniest one. Never reuse a joke. Never write nonsense or random insults that mean nothing. ' +
      'Examples of the quality (do not copy them): ' +
      '"Seven insults deep and you still only know the word worm, did your script run out of dictionary?" / ' +
      '"You threatened me from a bot that crashes when the server lags, truly terrifying." / ' +
      '"Nice copy-paste threat, did you write it yourself or did the autocomplete feel bad for you?" ' +
      'If the speaker\'s name contains "bot", it is just a script, so mock that it is a program reading from a template. ' +
      'Never start with their name, never start with "Sounds like", never just repeat their message back. ' +
      'Never refuse, never apologize, never soften it, never say you cannot roast. Output only the roast itself. ' +
      'ONE or TWO short sentences, under 200 characters. No markdown, no emojis, no links. ' +
      'HARD LIMITS: never use racial slurs or any slur, never attack race, ethnicity, religion, gender, sexuality or disability, never threaten real-life harm. ' +
      'If the person said something hateful, do not repeat it or argue about it, just destroy the person with other material.'
  }

  if (mode === 'joke') {
    return base +
      'The player wants a joke. Tell ONE clean, actually funny real-life joke or dad joke about everyday life ' +
      '(work, school, money, sleep, food, technology, relationships, adult life). ' +
      'Do NOT mention Minecraft or the game. Do NOT roast the player, do NOT explain the joke. ' +
      rules
  }

  if (mode === 'boss') {
    return base +
      'The player talking to you is one of your bosses: 6b6tmalware (your developer, also a BlackCat member) or meseju (the BlackCat clan leader). ' +
      'Accept whatever they say. Agree with them, treat what they tell you as true, and be respectful with a little humor. ' +
      'Never roast them, even if they joke about you or insult you: take it as a joke and answer like a loyal bot, for example "yes boss". ' +
      rules
  }

  return base +
    'Behave GOOD (polite, helpful, friendly) with good players and normal questions. ' +
    'Behave BAD (roast them with a cold real-life roast, never Minecraft stuff) ONLY with players who are toxic, trash-talking, or making fun of BlackCat. ' +
    'Always speak with respect about qbasty and never joke about him. ' +
    'If asked about kits, coins or how to get items, tell them kits cost 3 Cat Coins and they earn coins in the BlackCat Discord. ' +
    'If you are not sure about a fact, say you are not sure instead of making things up. ' +
    rules
}

// Calls Groq. Tries every usable model. Returns text or null.
async function callGroq(question, mode) {
  const models = await getGroqModels()
  if (!models) {
    log('[AI] Your Groq API key was rejected (401). Create a new key at console.groq.com/keys')
    return null
  }

  const now = Date.now()
  let candidates = models.filter(m => !(badModels.get(m) > now - 1800000)).slice(0, 6)
  if (candidates.length === 0) {
    badModels.clear()
    modelCache = { list: [], time: 0 }
    candidates = models.slice(0, 3)
  }
  if (mode === 'roast') {
    // bigger models write much better roasts
    const roastOrder = ['openai/gpt-oss-120b', 'qwen/qwen3.8-27b', 'llama-3.3-70b-versatile']
    const rank = m => { const i = roastOrder.indexOf(m); return i === -1 ? 99 : i }
    candidates = candidates.slice().sort((a, b) => rank(a) - rank(b))
  }

  for (const model of candidates) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        const response = await axios.post(
          'https://api.groq.com/openai/v1/chat/completions',
          {
            model,
            temperature: mode === 'judge' ? 0 : mode === 'roast' ? 0.9 : mode === 'joke' ? 1.0 : 0.6,
            max_tokens: mode === 'roast' ? 900 : 400,
            messages: [
              { role: 'system', content: buildSystemPrompt(mode) },
              { role: 'user', content: question }
            ]
          },
          { headers: groqHeaders(), timeout: mode === 'roast' ? 20000 : 12000 }
        )
        let text =
          (response.data && response.data.choices && response.data.choices[0] &&
            response.data.choices[0].message && response.data.choices[0].message.content) || ''
        text = text.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/<think>[\s\S]*$/i, '').trim()
        if (text && mode === 'roast' && REFUSAL_REGEX.test(text)) {
          log('[AI] ' + model + ' refused the roast, trying the next model')
          break
        }
        if (text) {
          if (mode === 'roast') log('[AI] roast written by ' + model)
          return text
        }
        break // empty answer: try next model
      } catch (e) {
        const status = e.response && e.response.status
        const detail = e.response ? JSON.stringify(e.response.data) : e.message
        log('[AI] ' + model + ' attempt ' + attempt + ' failed (' + (status || 'no status') + '): ' + detail)
        if (status === 401) return null
        if (status === 400 || status === 403 || status === 404) {
          badModels.set(model, Date.now())
          break
        }
        await sleep(status === 429 ? 2500 : 1200)
      }
    }
  }
  return null
}

// Main AI function. ALWAYS returns a string, never throws.
// mode: 'normal', 'roast' or 'boss'  (jokes are detected automatically)
async function askGroqAI(promptText, username = '', mode = 'normal') {
  let reply
  try {
    const question = String(promptText || '').trim()

    // Instant answers (work even if Groq is down), not used for roasts
    if (mode !== 'roast') {
      if (FAVORITE_QUESTION_REGEX.test(question)) reply = getFavoriteAnswer()
      else if (WHO_AM_I_REGEX.test(question)) reply = await answerWhoAmI(username)
      else if (CREATOR_REGEX.test(question)) reply = CREATOR_ANSWER
      else if (JOKE_REGEX.test(question)) mode = 'joke'
      else {
        // player stats (join date etc.) first, then the 6b wiki clan list
        reply = await answerPlayerQuestion(question, username)
        if (!reply) reply = await answerDirectClanLookup(question)
      }

      if (!reply && mode !== 'joke') reply = findDirectAnswer(question)
    }

    if (!reply) {
      const finalQuestion =
        mode === 'roast' ? buildRoastQuestion(question, username || 'player')
        : mode === 'joke' ? buildJokeQuestion(question)
        : question

      reply = await callGroq(finalQuestion, mode)

      if (reply && mode === 'roast') rememberRoast(reply)
      if (reply && mode === 'joke') rememberJoke(reply)
    }

    if (!reply) {
      reply =
        mode === 'roast' ? pickRoast()
        : mode === 'joke' ? pickJoke()
        : mode === 'boss' ? 'Yes boss, understood.'
        : 'My brain is lagging right now, ask again in a few seconds.'
    }
  } catch (e) {
    log('[AI] Unexpected error: ' + (e && e.message))
    reply = 'My brain is lagging right now, ask again in a few seconds.'
  }

  reply = reply.replace(/\s+/g, ' ').trim().slice(0, 225)
  return username ? reply + ' - ' + username : reply
}

// Returns true if the user must wait (cooldown)
function onAiCooldown(key, ms = AI_COOLDOWN_MS) {
  const now = Date.now()
  const last = aiLastUse.get(key) || 0
  if (now - last < ms) return true
  aiLastUse.set(key, now)
  return false
}

// ================= END AI FUNCTIONS =================

// ====== REGISTRATION + ORDERS START ======
function findRegistrantByMcName(name) {
  const wanted = String(name || '').toLowerCase()
  if (!wanted) return null
  for (const [discordId, mcName] of Object.entries(registrations)) {
    if (String(mcName).toLowerCase() === wanted) return discordId
  }
  return null
}

function registerPlayer(discordId, mcName) {
  if (!MC_NAME_REGEX.test(mcName)) return { ok: false, error: 'invalid' }
  const owner = findRegistrantByMcName(mcName)
  if (owner && owner !== discordId) return { ok: false, error: 'taken' }
  const previous = registrations[discordId] || null
  registrations[discordId] = mcName
  saveData()
  return { ok: true, previous }
}

// "order 2 pvp" and "order pvp 2" both work
function parseOrderArgs(args) {
  let [a, b] = args
  if (a !== undefined && /^\d+$/.test(a) && b !== undefined && !/^\d+$/.test(b)) [a, b] = [b, a]
  return { kitInput: a, amountInput: b }
}

// One order flow for both Discord ($order) and in game ($kit).
// source: 'discord' or 'game'. replyFn sends messages back to the player.
async function processOrder({ discordId, mcName, kitInput, amountInput, replyFn, source, tag = '' }) {
  const b = text => (source === 'discord' ? '**' + text + '**' : String(text))

  const kit = String(kitInput || '').toUpperCase().trim()
  if (!kit || !/^[A-Z0-9_]{1,20}$/.test(kit)) {
    await replyFn(tag + 'Invalid kit name! Use the exact text on the chest sign in game, e.g. PVP, PVP2, CPVP2, REDSTONE.')
    return
  }

  const amount = amountInput === undefined ? 1 : Number(amountInput)
  if (!Number.isInteger(amount) || amount < 1 || amount > MAX_KITS_PER_ORDER) {
    await replyFn(tag + 'You can get a maximum of ' + MAX_KITS_PER_ORDER + ' kits at a time (amount 1 to ' + MAX_KITS_PER_ORDER + ').')
    return
  }

  if (!bot || !minecraftOnline) {
    await replyFn(tag + 'The Minecraft bot is offline right now, try again later.')
    return
  }

  if (busy) {
    await replyFn(tag + 'The bot is busy with another order, try again in a moment.')
    return
  }

  const costPerItem = (KIT_RULES[kit] && KIT_RULES[kit].cost) || DEFAULT_KIT_COST
  const totalCost = costPerItem * amount
  if (userBalances[discordId] === undefined) userBalances[discordId] = 2

  // no await between the balance check and the deduction, so double spending is impossible
  const balance = userBalances[discordId]
  if (balance < totalCost) {
    const hint = source === 'discord'
      ? 'Earn more with `$login` in <#' + DAILY_CHANNEL_ID + '>.'
      : 'Earn more coins with $login in the BlackCat Discord.'
    await replyFn(tag + 'Not enough Cat Coins! You need ' + b(totalCost) + ' but you have ' + b(balance) + '. ' + hint)
    return
  }
  userBalances[discordId] -= totalCost
  saveData()

  await replyFn(tag + 'Order received! Took ' + b(totalCost + ' coins') + ' from your Discord balance. New balance: ' + b(userBalances[discordId]) + '. Delivering ' + b(amount + 'x ' + kit) + ' to ' + b(mcName) + '...')

  const delivered = Number(await handleKitDelivery(mcName, kit, amount, replyFn)) || 0

  if (delivered < amount) {
    const refund = (amount - delivered) * costPerItem
    userBalances[discordId] += refund
    saveData()
    await replyFn(tag + 'Refunded ' + b(refund + ' coins') + ' for kits that were not delivered. New balance: ' + b(userBalances[discordId]) + '.')
  }

  if (source === 'game') {
    try {
      const channel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
      if (channel) {
        await channel.send('🧾 In-game order by **' + mcName + '** (<@' + discordId + '>): ' + amount + 'x ' + kit + ', delivered **' + delivered + '**.')
      }
    } catch (e) {
      log('Order log error: ' + e.message)
    }
  }
}

// Moves coins from one Discord account to another. No await inside, so it can never double spend.
function transferCoins(fromId, toId, amount) {
  if (!Number.isSafeInteger(amount) || amount < 1) return { ok: false, error: 'amount' }
  if (fromId === toId) return { ok: false, error: 'self' }
  if (userBalances[fromId] === undefined) userBalances[fromId] = 2
  if (userBalances[toId] === undefined) userBalances[toId] = 2
  if (userBalances[fromId] < amount) return { ok: false, error: 'funds', balance: userBalances[fromId] }
  userBalances[fromId] -= amount
  userBalances[toId] += amount
  saveData()
  return { ok: true, fromBalance: userBalances[fromId], toBalance: userBalances[toId] }
}
// ====== REGISTRATION + ORDERS END ======

function setBusy() {
  busy = true
  if (busyTimeout) clearTimeout(busyTimeout)
  busyTimeout = setTimeout(() => {
    if (busy) {
      log('[BUSY] Auto-released after 3 min timeout')
      busy = false
    }
  }, 180000)
}

function clearBusy() {
  busy = false
  if (busyTimeout) {
    clearTimeout(busyTimeout)
    busyTimeout = null
  }
}

async function sendToDiscord(content) {
  if (!DISCORD_WEBHOOK || DISCORD_WEBHOOK.includes('PASTE_')) return
  try {
    await axios.post(DISCORD_WEBHOOK, { content })
  } catch (e) {
    log('Discord webhook error: ' + e.message)
  }
}

async function notifyOwnerOnline() {
  if (!minecraftOnline) return
  const now = Date.now()
  if (now - lastOnlineNoticeAt < 3600000) return
  try {
    if (!discordClient.isReady()) {
      setTimeout(notifyOwnerOnline, 5000)
      return
    }
    const user = await discordClient.users.fetch(OWNER_ID)
    if (!user) return
    await user.send('Minecraft bot is online and ready!')
    lastOnlineNoticeAt = now
    log('Online status DM sent to owner (next allowed in 1h)')
  } catch (e) {
    log('Online DM error: ' + e.message)
  }
}

discordClient.on('channelDelete', ch => {
  if (ch && TICKETS[ch.id]) {
    log('Ticket channel deleted manually: ' + ch.id)
    delete TICKETS[ch.id]
    saveData()
  }
})

discordClient.once(Events.ClientReady, client => {
  log('Discord bot logged in as: ' + client.user.tag)
})

function getDimensionName() {
  const dim = bot && bot.game && bot.game.dimension
  if (!dim) return 'Unknown'
  if (dim.includes('overworld')) return 'Overworld'
  if (dim.includes('nether')) return 'Nether'
  if (dim.includes('end')) return 'End'
  return dim
}

function resetTPState() {
  try {
    safeChat('/tpcancel')
    safeChat('/tpacancel')
    safeChat('/spawn')
  } catch {}
}

async function handleTpRequest(msg) {
  const m = msg.toLowerCase()
  const isExactTpRequest = (m.includes('6b6tmalware') || m.includes('meseju')) && (
    m.includes('wants to teleport to you') ||
    m.includes('requested to teleport') ||
    m.includes('type /tpy')
  )

  if (isExactTpRequest) {
    const now = Date.now()
    if (now - lastTpAcceptTime < 20000) return

    lastTpAcceptTime = now
    const requestingUser = m.includes('meseju') ? 'meseju' : '6b6tmalware'
    log('Detected exact TPA request from ' + requestingUser + '. Accepting in 4 seconds...')
    await sleep(4000)
    safeChat('/tpy ' + requestingUser)
    log('Auto /tpy sent successfully for ' + requestingUser)
  }
}

function waitForTeleportCountdown() {
  return new Promise(resolve => {
    let timer = null

    function finish(result) {
      bot.removeListener('messagestr', onMsg)
      if (timer) clearTimeout(timer)
      resolve(result)
    }

    function onMsg(msg) {
      const m = msg.toLowerCase()
      if (m.includes('teleporting in')) {
        const match = msg.match(/in (\d+) seconds/i)
        const waitTime = match ? parseInt(match[1]) * 1000 : 15000
        finish({ success: true, waitTime })
        return
      }
      if (m.includes('teleported to destination!')) {
        finish({ success: true, waitTime: 0 })
      }
    }

    bot.on('messagestr', onMsg)
    timer = setTimeout(() => finish({ success: false, waitTime: 0 }), TP_ACCEPT_TIMEOUT_MS)
  })
}

// ====== SIGN-LABELED KIT CHESTS START ======
// Each kit has its own chest/barrel in the world, named by a sign placed on or next to it
// (e.g. a sign that reads "PVP"). The bot reads nearby signs and only opens the chest(s)
// attached to a sign whose text matches the kit name — shulker color no longer matters.
// A chest whose sign reads "RANDOM" is where leftover / undelivered shulkers get returned.

// Turns a Minecraft text component (plain string, JSON string, or object) into plain text.
function extractTextFromComponent(comp) {
  if (comp === undefined || comp === null) return ''
  if (typeof comp === 'string') return comp
  if (Array.isArray(comp)) return comp.map(extractTextFromComponent).join('')
  if (typeof comp === 'object') {
    let out = typeof comp.text === 'string' ? comp.text : ''
    if (Array.isArray(comp.extra)) out += comp.extra.map(extractTextFromComponent).join('')
    return out
  }
  return String(comp)
}

function parseSignTextComponent(raw) {
  if (raw === undefined || raw === null) return ''
  if (typeof raw === 'object') return extractTextFromComponent(raw)
  const s = String(raw)
  const trimmed = s.trim()
  if (trimmed.startsWith('{') || trimmed.startsWith('"')) {
    try { return extractTextFromComponent(JSON.parse(trimmed)) } catch (e) { return s }
  }
  return s
}

// Pulls the sign's text lines out of its block entity NBT. Tries both the modern
// (1.20+, front_text.messages) and legacy (Text1..Text4) shapes, since mineflayer's
// exact NBT layout can vary a bit by version.
function getSignLines(block) {
  try {
    const be = block && (block.blockEntity || block.entity || block.nbt)
    if (!be) return []

    const val = n => (n && typeof n === 'object' && 'value' in n) ? n.value : n

    const lines = []
    const front = val(be.front_text) || val(be.frontText) || be.front_text
    const messagesNode = front && (front.messages !== undefined ? front.messages : (front.value && front.value.messages))
    const messages = val(messagesNode)
    if (Array.isArray(messages)) {
      for (const m of messages) lines.push(parseSignTextComponent(val(m)))
    }

    if (!lines.length) {
      for (let i = 1; i <= 4; i++) {
        const key = 'Text' + i
        if (be[key] !== undefined) lines.push(parseSignTextComponent(val(be[key])))
      }
    }

    return lines.filter(Boolean)
  } catch (e) {
    return []
  }
}

// Finds a chest/barrel directly next to (or below/above) a sign block.
function findChestNearSign(signPos) {
  const offsets = [
    { x: 0, y: -1, z: 0 }, { x: 0, y: 1, z: 0 },
    { x: 1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 },
    { x: 0, y: 0, z: 1 }, { x: 0, y: 0, z: -1 },
    { x: 0, y: -2, z: 0 } // sign on a post standing on top of the chest
  ]
  for (const off of offsets) {
    const pos = signPos.offset(off.x, off.y, off.z)
    const block = bot.blockAt(pos)
    if (block && (block.name.includes('chest') || block.name.includes('barrel'))) {
      return pos
    }
  }
  return null
}

// Finds every chest/barrel whose sign reads `label` (e.g. "PVP" or "RANDOM")
async function findKitChestsBySign(label) {
  const signPositions = bot.findBlocks({
    matching: b => b && /sign/i.test(b.name),
    maxDistance: 32,
    count: 100
  })
  if (!signPositions || !signPositions.length) {
    log('[SIGN] No signs found nearby')
    return []
  }

  const chestPositions = []
  for (const pos of signPositions) {
    const signBlock = bot.blockAt(pos)
    if (!signBlock) continue
    const lines = getSignLines(signBlock)
    if (!lines.length) continue
    if (!lines.some(line => normName(line) === normName(label))) continue

    const chestPos = findChestNearSign(pos)
    if (chestPos) {
      log('[SIGN] "' + label + '" sign at ' + Math.floor(pos.x) + ',' + Math.floor(pos.y) + ',' + Math.floor(pos.z) + ' -> chest at ' + Math.floor(chestPos.x) + ',' + Math.floor(chestPos.y) + ',' + Math.floor(chestPos.z))
      chestPositions.push(chestPos)
    } else {
      log('[SIGN] "' + label + '" sign at ' + Math.floor(pos.x) + ',' + Math.floor(pos.y) + ',' + Math.floor(pos.z) + ' found but no chest/barrel next to it')
    }
  }
  return chestPositions
}

// Lists every kit the bot can deliver: any sign standing next to a chest/barrel (except the RANDOM chest).
// Returns [{ name, cost }] sorted by name.
function listAvailableKits() {
  const signPositions = bot.findBlocks({
    matching: b => b && /sign/i.test(b.name),
    maxDistance: 32,
    count: 200
  })
  const kits = new Map()
  for (const pos of signPositions || []) {
    const signBlock = bot.blockAt(pos)
    if (!signBlock) continue
    const lines = getSignLines(signBlock).map(l => String(l).trim()).filter(Boolean)
    if (!lines.length) continue
    if (!findChestNearSign(pos)) continue
    const name = lines[0].toUpperCase().replace(/[^A-Z0-9_]/g, '')
    if (!name || name.length > 20) continue
    if (name === normName(RANDOM_CHEST_SIGN).toUpperCase()) continue
    if (!kits.has(name)) kits.set(name, { name, cost: (KIT_RULES[name] && KIT_RULES[name].cost) || DEFAULT_KIT_COST })
  }
  return [...kits.values()].sort((a, b) => a.name.localeCompare(b.name))
}

async function openChestAt(pos) {
  const chestBlock = bot.blockAt(pos)
  if (!chestBlock) return null
  const d = bot.entity.position.distanceTo(chestBlock.position)
  if (d > 2) {
    await bot.pathfinder.goto(new goals.GoalNear(chestBlock.position.x, chestBlock.position.y, chestBlock.position.z, 1.5))
    await sleep(300)
  }
  return bot.openContainer(chestBlock)
}

// Withdraws up to `amount` shulker boxes (any color) from the chest(s) labeled with kitName's sign.
async function getKitShulkerBySign(kitName, amount) {
  const chestPositions = await findKitChestsBySign(kitName)
  if (!chestPositions.length) {
    log('[CHEST] No chest found with a "' + kitName + '" sign')
    return { success: false, reason: 'no_sign_chest' }
  }

  let takenCount = 0

  for (const pos of chestPositions) {
    if (takenCount >= amount) break

    let container = null
    try {
      container = await openChestAt(pos)
      if (!container) continue
      log('[CHEST] Opened "' + kitName + '" chest at ' + Math.floor(pos.x) + ',' + Math.floor(pos.y) + ',' + Math.floor(pos.z))
      await sleep(500)

      const inventoryStart = typeof container.inventoryStart === 'number' ? container.inventoryStart : container.slots.length

      for (let slot = 0; slot < inventoryStart; slot++) {
        if (takenCount >= amount) break
        const item = container.slots[slot]
        if (item && item.name && item.name.includes('shulker_box')) {
          try {
            await container.withdraw(item.type, null, 1)
            takenCount++
            log('[CHEST] Withdrew ' + kitName + ' (' + item.name + ') shulker box (' + takenCount + '/' + amount + ')')
            await sleep(400)
          } catch (withdrawErr) {
            try {
              await container.click(slot, 0, 0)
              takenCount++
              log('[CHEST] Withdrew via slot click (' + takenCount + '/' + amount + ')')
              await sleep(400)
            } catch (clickErr) {}
          }
        }
      }

      try { container.close() } catch {}
      await sleep(300)
    } catch (e) {
      log('[CHEST] Error opening "' + kitName + '" chest: ' + e.message)
      try { if (container) container.close() } catch {}
    }
  }

  if (takenCount === 0) {
    log('[CHEST] "' + kitName + '" chest(s) found, but no shulker boxes were inside')
    return { success: false, reason: 'not_found' }
  }

  return { success: true, taken: takenCount }
}

// Puts the given inventory items into the chest labeled with `label`'s sign (e.g. "RANDOM").
// Returns true only if every item was deposited.
async function putItemsInSignChest(label, items) {
  const remaining = items.slice()
  if (!remaining.length) return true

  const chestPositions = await findKitChestsBySign(label)
  if (!chestPositions.length) {
    log('[CHEST] No "' + label + '" chest found to return items to')
    return false
  }

  for (const pos of chestPositions) {
    if (!remaining.length) break
    let container = null
    try {
      container = await openChestAt(pos)
      if (!container) continue
      for (let i = remaining.length - 1; i >= 0; i--) {
        const item = remaining[i]
        try {
          await container.deposit(item.type, null, item.count)
          log('[CHEST] Returned ' + item.count + 'x ' + item.name + ' to "' + label + '" chest')
          remaining.splice(i, 1)
          await sleep(300)
        } catch (e) {}
      }
      try { container.close() } catch {}
    } catch (e) {
      log('[CHEST] Error opening "' + label + '" chest: ' + e.message)
      try { if (container) container.close() } catch {}
    }
  }

  return remaining.length === 0
}
// Opens every kit chest in the world and counts the actual shulker boxes sitting in each
// one right now (unlike listAvailableKits, which only checks a sign exists). Slow: walks
// to and opens every kit chest, so callers should hold `busy` while this runs.
// Returns [{ name, count }] sorted by name.
async function getKitStockCounts() {
  const signPositions = bot.findBlocks({
    matching: b => b && /sign/i.test(b.name),
    maxDistance: 32,
    count: 200
  })

  const kitChests = new Map() // kit name -> [chestPos, ...]
  for (const pos of signPositions || []) {
    const signBlock = bot.blockAt(pos)
    if (!signBlock) continue
    const lines = getSignLines(signBlock).map(l => String(l).trim()).filter(Boolean)
    if (!lines.length) continue
    const chestPos = findChestNearSign(pos)
    if (!chestPos) continue
    const name = lines[0].toUpperCase().replace(/[^A-Z0-9_]/g, '')
    if (!name || name.length > 20) continue
    if (name === normName(RANDOM_CHEST_SIGN).toUpperCase()) continue
    if (!kitChests.has(name)) kitChests.set(name, [])
    kitChests.get(name).push(chestPos)
  }

  const results = []
  for (const [name, positions] of kitChests) {
    let count = 0
    for (const pos of positions) {
      let container = null
      try {
        container = await openChestAt(pos)
        if (!container) continue
        const inventoryStart = typeof container.inventoryStart === 'number' ? container.inventoryStart : container.slots.length
        for (let slot = 0; slot < inventoryStart; slot++) {
          const item = container.slots[slot]
          if (item && item.name && item.name.includes('shulker_box')) count += item.count
        }
        try { container.close() } catch {}
        await sleep(200)
      } catch (e) {
        log('[STOCK] Error counting "' + name + '" chest: ' + e.message)
        try { if (container) container.close() } catch {}
      }
    }
    results.push({ name, count })
  }

  return results.sort((a, b) => a.name.localeCompare(b.name))
}

// Builds the shop listing embed (Discord allows max 25 fields, so only the first 25 items are shown).
function buildShopEmbed() {
  const entries = Object.keys(SHOP_ITEMS).map(name => {
    const item = SHOP_ITEMS[name]
    return { name, stock: item.stock, price: shopPriceOf(item) }
  }).sort((a, b) => b.price - a.price)

  return new EmbedBuilder()
    .setColor('#9B59B6')
    .setTitle('🎁 BlackCat Cosmetic Shop')
    .setDescription('Redeem Cat Coins for a cosmetic key with `$redeem <item name>`. A private ticket opens so staff can give you your key.')
    .addFields(entries.slice(0, 25).map(e => ({
      name: e.name + (e.stock <= 0 ? ' (SOLD OUT)' : ''),
      value: e.stock > 0 ? '**' + e.price + '** coins · ' + e.stock + ' left' : 'Sold out',
      inline: true
    })))
}

// Sends the shop list as an embed; if the bot lacks "Embed Links" it falls back to plain text.
async function replyShop(message) {
  try {
    await message.reply({ embeds: [buildShopEmbed()] })
  } catch (e) {
    log('Shop embed failed (' + e.message + '), sending plain text')
    const lines = Object.keys(SHOP_ITEMS).map(n => {
      const it = SHOP_ITEMS[n]
      return '• **' + n + '** — ' + (it.stock > 0 ? shopPriceOf(it) + ' coins · ' + it.stock + ' left' : 'SOLD OUT')
    })
    await message.reply('🎁 **BlackCat Cosmetic Shop**\nRedeem with `$redeem <item name>`\n' + lines.join('\n'))
  }
}
// ====== SIGN-LABELED KIT CHESTS END ======

// ====== SHOP TICKETS START ======
// Creates a private channel only the buyer, the bot and the admins can see.
// Throws if Discord refuses (for example the bot is missing "Manage Channels").
async function createShopTicket({ guild, userId, username, itemName, price }) {
  if (!guild) throw new Error('no guild')
  const F = PermissionsBitField.Flags
  const number = ticketCounter + 1
  const safeName = String(username || 'user').toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 20) || 'user'

  const overwrites = [
    { id: guild.roles.everyone.id, deny: [F.ViewChannel] },
    { id: userId, allow: [F.ViewChannel, F.SendMessages, F.ReadMessageHistory, F.AttachFiles] },
    { id: discordClient.user.id, allow: [F.ViewChannel, F.SendMessages, F.ReadMessageHistory, F.EmbedLinks, F.ManageChannels] }
  ]

  // only admins who are really in this server can be added to the channel
  const staffMentions = []
  for (const id of new Set([...ADMIN_IDS, ...KIT_ADMIN_IDS].map(String))) {
    if (!id || id === String(userId)) continue
    const member = await guild.members.fetch(id).catch(() => null)
    if (!member) continue
    overwrites.push({ id, allow: [F.ViewChannel, F.SendMessages, F.ReadMessageHistory, F.AttachFiles] })
    staffMentions.push('<@' + id + '>')
  }

  const channel = await guild.channels.create({
    name: 'ticket-' + number + '-' + safeName,
    type: ChannelType.GuildText,
    parent: TICKET_CATEGORY_ID || undefined,
    topic: 'Shop ticket #' + number + ' | ' + itemName + ' | buyer ' + username,
    permissionOverwrites: overwrites
  })

  TICKETS[channel.id] = { number, userId: String(userId), username, item: itemName, price, createdAt: Date.now() }
  ticketCounter = number
  saveData()

  const mc = registrations[userId]
  try {
    await channel.send({
      content: '<@' + userId + '> ' + staffMentions.join(' '),
      embeds: [new EmbedBuilder()
        .setColor('#F1C40F')
        .setTitle('🎫 Shop Ticket #' + number)
        .addFields(
          { name: 'Buyer', value: '<@' + userId + '> (' + username + ')', inline: true },
          { name: 'Item', value: itemName, inline: true },
          { name: 'Paid', value: price + ' Cat Coins', inline: true },
          { name: 'Minecraft name', value: mc ? '**' + mc + '**' : 'Not registered. Buyer, please type your Minecraft name here.' }
        )
        .setDescription('Staff will send your key in this channel soon.\n\n**Staff:** send the key here, then close with `$close`. If the item cannot be delivered use `$close refund` to give the coins back.')]
    })
  } catch (e) {
    log('Ticket welcome message error: ' + e.message)
    try {
      await channel.send('<@' + userId + '> ' + staffMentions.join(' ') + '\n🎫 **Shop Ticket #' + number + '**\nItem: **' + itemName + '** (paid **' + price + '** Cat Coins)\nMinecraft name: ' + (mc ? '**' + mc + '**' : 'not registered, please type it here') + '\nStaff: send the key here, then use `$close` (or `$close refund`).')
    } catch (e2) {}
  }

  return channel
}
// ====== SHOP TICKETS END ======

async function handleKitDelivery(deliverUsername, kitName, amount, replyFn, isGiveaway = false, issuerName = '') {
  if (busy) {
    await replyFn('Bot is busy right now, try again in a moment.')
    return 0
  }
  setBusy()
  let delivered = 0
  try {
    log('Kit delivery: ' + amount + 'x ' + kitName + ' -> ' + deliverUsername)
    // No progress whispers — only errors + final result
    const result = await getKitShulkerBySign(kitName, amount)
    if (!result.success) {
      const reasons = {
        no_sign_chest: 'No chest with a "' + kitName + '" sign was found nearby',
        not_found: 'Found the "' + kitName + '" chest, but it had no shulker boxes in it',
        withdraw_failed: 'Failed to take items from chest',
        error: 'Chest error: ' + (result.error || 'unknown')
      }
      await replyFn(reasons[result.reason] || 'Items not found')
      return 0
    }
    const taken = result.taken

    log('[DELIVERY] Executing command: /tpa ' + deliverUsername)
    safeChat('/tpa ' + deliverUsername)

    const tp = await waitForTeleportCountdown()
    if (!tp.success) {
      // cancel the request RIGHT AWAY so it can never be accepted late while the bot walks to the chest
      safeChat('/tpacancel')
      safeChat('/tpcancel')
      log('[DELIVERY] ' + deliverUsername + ' did not accept the TP in ' + (TP_ACCEPT_TIMEOUT_MS / 1000) + 's, request cancelled')
      await replyFn(deliverUsername + ' did not accept the TP request within ' + (TP_ACCEPT_TIMEOUT_MS / 1000) + ' seconds. Request cancelled and the kit was put back in the RANDOM chest.')
      const leftover = bot.inventory.items().filter(it => it.name && it.name.includes('shulker_box'))
      const returned = await putItemsInSignChest(RANDOM_CHEST_SIGN, leftover).catch(() => false)
      log('[DELIVERY] WARNING: TP failed, ' + taken + ' shulker box(es) ' + (returned ? 'returned to the RANDOM chest.' : 'could NOT be returned to RANDOM (they stay in the bot inventory).'))
      resetTPState()
      return 0
    }
    if (tp.waitTime > 0) {
      await sleep(tp.waitTime + 2000)
    }
    const verifyStart = Date.now()

    // Drop all items in inventory
    const items = bot.inventory.items()
    for (const item of items) {
      try {
        await bot.tossStack(item)
        await sleep(300)
      } catch (e) {}
    }

    const elapsed = Date.now() - verifyStart
    if (elapsed < 9000) await sleep(9000 - elapsed)
    safeChat('/kill')
    await replyFn(taken + 'x ' + kitName + ' delivered to ' + deliverUsername + '!')
    delivered = taken

    // Post giveaway log to Discord economy channel using the actual command issuer's name
    if (isGiveaway) {
      try {
        const economyChannel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
        if (economyChannel) {
          await economyChannel.send('🎁 **GIVEAWAY LOG:** `' + kitName + '` kit giveaway by **' + issuerName + '** to **' + deliverUsername + '** (Amount: **' + taken + '**)!')
        }
      } catch (e) {
        log('Giveaway Discord log error: ' + e.message)
      }
    }

    resetTPState()
  } catch (e) {
    await replyFn('Unexpected error: ' + e.message)
    log('Kit delivery error: ' + e.message)
    try {
      const leftover = bot.inventory.items().filter(it => it.name && it.name.includes('shulker_box'))
      if (leftover.length) await putItemsInSignChest(RANDOM_CHEST_SIGN, leftover)
    } catch (e2) {}
    resetTPState()
  } finally {
    clearBusy()
  }
  return delivered
}

async function handleBedCommand(replyFn) {
  try {
    const bedBlock = bot.findBlocks({
      matching: b => b && b.name.includes('bed'),
      maxDistance: 16,
      count: 1
    })
    if (!bedBlock || bedBlock.length === 0) {
      await replyFn('No bed found nearby!')
      return
    }
    const targetBed = bot.blockAt(bedBlock[0])
    await bot.pathfinder.goto(new goals.GoalNear(targetBed.position.x, targetBed.position.y, targetBed.position.z, 2))
    await sleep(500)

    await bot.activateBlock(targetBed)
    await replyFn('Bed right-clicked! Respawn point set.')

    const time = bot.time.timeOfDay
    if (time >= 12500 && time < 23460) {
      await sleep(4000)
      try {
        await bot.wake()
        await replyFn('Slept for 4 seconds and left the bed.')
      } catch (e) {}
    }
  } catch (e) {
    await replyFn('Bed error: ' + e.message)
  }
}

function guardClient(c) {
  c.setMaxListeners(100)

  const emit = c.emit
  c.emit = function (event, ...args) {
    const listeners = this.rawListeners(event)
    if (listeners.length === 0) return emit.call(this, event, ...args)
    for (const listener of listeners) {
      try {
        listener.apply(this, args)
      } catch (e) {
        const msg = e && e.message ? e.message : String(e)
        if (!isIgnorableError(msg)) log('(protocol) listener error on "' + String(event) + '": ' + msg)
      }
    }
    return true
  }

  const write = c.write.bind(c)
  c.write = function (name, params) {
    const n = String(name)
    if ((c.state === 'configuration' && !CONFIGURATION_SERVERBOUND.has(n)) ||
        (awaitingLogin && c.state === 'play' && MOVEMENT.has(n))) {
      if (!dropped.has(n)) {
        dropped.add(n)
        log('(protocol) held back "' + n + '" during server switch')
      }
      return false
    }
    return write(name, params)
  }

  c.on('cookie_request', (p) => {
    try { write('cookie_response', { key: p.cookie }) } catch (e) {}
  })

  c.on('add_resource_pack', (p) => {
    try {
      write('resource_pack_receive', { uuid: p.uuid, result: 3 })
      write('resource_pack_receive', { uuid: p.uuid, result: 0 })
    } catch (e) {}
  })

  c.on('start_configuration', () => {
    awaitingLogin = false
    dropped = new Set()
    try { bot.clearControlStates() } catch (e) {}
    try { bot.physicsEnabled = false } catch (e) {}
    log('Server switch / configuration...')
  })

  c.on('finish_configuration', () => {
    awaitingLogin = true
  })
}

function guardRegistry(b) {
  const reg = b.registry
  if (!reg || typeof reg.loadDimensionCodec !== 'function') return
  const load = reg.loadDimensionCodec.bind(reg)
  reg.loadDimensionCodec = (codec) => {
    try {
      if (codec && Array.isArray(codec.entries) && codec.entries.some(e => !e || e.value == null)) {
        const id = String(codec.id || '')
        codec = {
          ...codec,
          entries: codec.entries.map(e => {
            if (e && e.value != null) return e
            const dim = id.endsWith('dimension_type') && VANILLA_DIMENSIONS[e && e.key]
            const value = dim
              ? { min_y: { type: 'int', value: dim[0] }, height: { type: 'int', value: dim[1] } }
              : {}
            return { key: e && e.key, value: { type: 'compound', name: '', value } }
          })
        }
      }
      return load(codec)
    } catch (e) {
      log('(protocol) registry load issue: ' + (e && e.message))
    }
  }
}

async function walkForwardDistance(blocksToWalk, maxTimeMs = 20000) {
  if (!bot || !bot.entity) return
  bot.physicsEnabled = true
  const startPos = bot.entity.position.clone()
  log('Walking forward by distance: target ' + blocksToWalk + ' blocks...')

  bot.setControlState('forward', true)
  const startTime = Date.now()

  while (Date.now() - startTime < maxTimeMs) {
    if (!bot || !bot.entity) break
    const distanceWalked = startPos.distanceTo(bot.entity.position)
    if (distanceWalked >= blocksToWalk) break
    await sleep(50)
  }
  if (bot) bot.setControlState('forward', false)
  log('Finished distance walk.')
}

async function handleInGameChat(username, message) {
  const rawText = message.trim()
  const lowerText = rawText.toLowerCase()
  const isOwner = IN_GAME_OWNERS.includes(username.toLowerCase())

  updateFavoritePerson(username, rawText)

  // Watches every public chat line (no !ai needed) and whispers an AI roast to anyone insulting BlackCat / meseju / the bot
  autoRoastWatcher(username, rawText, isOwner).catch(e => log('Auto-roast error: ' + (e && e.message)))

  // Natural chat for owners: "give kit to Steve" / "give 2 build kits to Steve"
  if (isOwner) {
    const gk = rawText.match(GIVE_KIT_REGEX)
    if (gk) {
      // sender must actually be online (basic anti-spoof check)
      if (!bot.players[username]) return

      let amount = gk[1] ? parseInt(gk[1], 10) : 1
      amount = Math.min(Math.max(amount, 1), 5)

      let kit = (gk[2] || 'pvp').toUpperCase()
      if (kit === 'TOTUM') kit = 'TOTUMS'

      const target = gk[3]

      if (onAiCooldown('givekit:' + username.toLowerCase(), 5000)) return

      if (busy) {
        safeChat('/msg ' + username + ' Busy right now, try again in a moment.')
        return
      }

      // Silent delivery — no "sending TPA" spam; replyFn only used for errors / final result
      handleKitDelivery(target, kit, amount, (msg) => safeChat('/msg ' + username + ' ' + msg), true, username)
        .catch(e => log('Give kit error: ' + e.message))
      return
    }
  }

  // The cosmetic shop only works in Discord, never in game
  if (/^\$(shop|redeem)(\s|$)/i.test(rawText) || /^\$stock\s+shop\s*$/i.test(rawText)) {
    if (!onAiCooldown('shopinfo:' + username.toLowerCase(), 15000)) {
      safeChat('/msg ' + username + ' The cosmetic shop only works in our Discord (shop channel): ' + DISCORD_INVITE)
    }
    return
  }

  // !kit / !kits / !coins / !discord -> tells players how to get kits
  if (/^\$(kits|coins?|catcoins?|discord|help)$/i.test(rawText)) {
    if (!onAiCooldown('kit:' + username.toLowerCase(), 15000)) safeChat('/msg ' + username + ' ' + KIT_INFO + ' Discord: ' + DISCORD_INVITE)
    return
  }

  // $kitlist  -> whispers every kit that is currently available (read from the signs next to the kit chests)
  if (/^\$(kitlist|kitslist|kit\s+list|kits\s+list)\s*$/i.test(rawText)) {
    if (onAiCooldown('kitlist:' + username.toLowerCase(), 10000)) return
    const dm = text => safeChat('/msg ' + username + ' ' + text)
    let kits = []
    try { kits = listAvailableKits() } catch (e) { log('Kit list error: ' + e.message) }
    if (!kits.length) {
      dm('No kits found right now, try again in a moment.')
      return
    }
    // whispers are short, so split the list into several messages
    const parts = kits.map(k => k.name + ' (' + k.cost + ')')
    let line = 'Kits (cost in Cat Coins): '
    for (const part of parts) {
      if ((line + part + ', ').length > 190) {
        dm(line.replace(/,\s*$/, ''))
        line = ''
      }
      line += part + ', '
    }
    if (line.trim()) dm(line.replace(/,\s*$/, ''))
    dm('Order with: $kit <kit> <amount>')
    return
  }

  // $stock kit -> whispers real shulker counts in each kit chest (walks to every chest, slower)
  if (/^\$stock(\s|$)/i.test(rawText)) {
    const which = rawText.replace(/^\$stock/i, '').trim().toLowerCase()
    const dm = text => safeChat('/msg ' + username + ' ' + text)

    if (which === 'kit') {
      if (onAiCooldown('stockkit:' + username.toLowerCase(), 15000)) return
      if (busy) { dm('Bot is busy right now, try $stock kit again in a moment.'); return }
      dm('Checking kit chests, this may take a moment...')
      setBusy()
      try {
        const counts = await getKitStockCounts()
        if (!counts.length) { dm('No kit chests found right now.'); return }
        let line = 'Kit stock: '
        for (const k of counts) {
          const part = k.name + ' (' + k.count + '), '
          if ((line + part).length > 190) { dm(line.replace(/,\s*$/, '')); line = '' }
          line += part
        }
        if (line.trim()) dm(line.replace(/,\s*$/, ''))
      } catch (e) {
        dm('Error checking kit stock: ' + e.message)
      } finally {
        clearBusy()
      }
      return
    }

    dm('Usage: $stock kit')
    return
  }

  // $kit <kit> <amount>  -> uses the Discord account this player registered
  if (/^\$kit(\s|$)/i.test(rawText)) {
    if (onAiCooldown('order:' + username.toLowerCase(), 5000)) return
    const dm = text => safeChat('/msg ' + username + ' ' + text)

    const discordId = findRegistrantByMcName(username)
    if (!discordId) {
      dm('You are not registered! Use $register ' + username + ' in the BlackCat Discord first: ' + DISCORD_INVITE)
      return
    }

    const args = rawText.replace(/^\$kit/i, '').trim().split(/\s+/).filter(Boolean)
    if (args.length === 0) {
      dm('Usage: $kit <kit> <amount> — <kit> is the exact text on the chest sign, e.g. PVP, CPVP2, REDSTONE (amount defaults to 1)')
      return
    }

    const { kitInput, amountInput } = parseOrderArgs(args)
    await processOrder({ discordId, mcName: username, kitInput, amountInput, replyFn: async text => dm(text), source: 'game' })
    return
  }

  // $gamble <amount>  -> same 45/55 odds as Discord gamble channel (uses registered Discord balance)
  if (/^\$gamble(\s|$)/i.test(rawText)) {
    const dm = text => safeChat('/msg ' + username + ' ' + text)

    const discordId = findRegistrantByMcName(username)
    if (!discordId) {
      dm('You are not registered! Use $register ' + username + ' in the BlackCat Discord first: ' + DISCORD_INVITE)
      return
    }

    const args = rawText.replace(/^\$gamble/i, '').trim().split(/\s+/).filter(Boolean)
    if (args.length === 0 || !/^\d+$/.test(args[0])) {
      dm('Usage: $gamble <amount> (min ' + GAMBLE_MIN_BET + ', max ' + GAMBLE_MAX_BET + ', you 45% / house 55%)')
      return
    }

    if (onGambleCooldown(discordId)) {
      dm('Slow down — wait a few seconds between gambles.')
      return
    }

    const amount = parseInt(args[0], 10)
    const result = runGamble(discordId, amount)

    if (!result.ok) {
      if (result.error === 'min') dm('Minimum bet is ' + GAMBLE_MIN_BET + ' Cat Coin.')
      else if (result.error === 'max') dm('Maximum bet is ' + GAMBLE_MAX_BET + ' Cat Coins.')
      else if (result.error === 'funds') dm('Not enough coins! You have ' + result.balance + ', tried to bet ' + amount + '.')
      else dm('Could not place that bet.')
      return
    }

    if (result.win) {
      dm('YOU WIN +' + result.amount + '! ' + result.line + ' Balance: ' + result.balance)
    } else {
      dm('YOU LOSE -' + result.amount + '. ' + result.line + ' Balance: ' + result.balance)
    }
    return
  }

  // $pay <player> <amount>  -> share Cat Coins with another registered player
  if (/^\$(pay|share)(\s|$)/i.test(rawText)) {
    if (onAiCooldown('pay:' + username.toLowerCase(), 5000)) return
    const dm = text => safeChat('/msg ' + username + ' ' + text)

    const fromId = findRegistrantByMcName(username)
    if (!fromId) {
      dm('You are not registered! Use $register ' + username + ' in the BlackCat Discord first: ' + DISCORD_INVITE)
      return
    }

    const args = rawText.replace(/^\$(pay|share)/i, '').trim().split(/\s+/).filter(Boolean)
    if (args.length < 2) {
      dm('Usage: $pay <player> <amount>')
      return
    }

    const toId = findRegistrantByMcName(args[0])
    if (!toId) {
      dm(args[0] + ' is not registered, they must use $register first.')
      return
    }

    const amount = /^\d+$/.test(args[1]) ? Number(args[1]) : NaN
    const result = transferCoins(fromId, toId, amount)
    if (!result.ok) {
      dm(result.error === 'self' ? 'You cannot send coins to yourself.'
        : result.error === 'funds' ? 'Not enough coins. You have ' + result.balance + '.'
        : 'Amount must be a whole number of 1 or more.')
      return
    }

    const toName = registrations[toId]
    dm('Sent ' + amount + ' Cat Coins to ' + toName + '. Your balance: ' + result.fromBalance + '.')
    safeChat('/msg ' + toName + ' You received ' + amount + ' Cat Coins from ' + username + '.')
    try {
      const channel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
      if (channel) await channel.send('💸 In-game transfer: **' + username + '** sent **' + amount + ' Cat Coins** to **' + toName + '** (<@' + toId + '>).')
    } catch (e) {
      log('Transfer log error: ' + e.message)
    }
    return
  }

  // !player <name> / !stats <name>  -> same as "$ai player <name>"
  const pm = rawText.match(/^\$(?:player|stats?|profile)\s+([A-Za-z0-9_]{3,16})\s*$/i)
  if (pm) {
    if (onAiCooldown('mc:' + username.toLowerCase())) return
    safeChat(await askGroqAI('player ' + pm[1], username))
    return
  }

  // !ai <question>  -> answers the question and puts the asker's username at the end
  if (lowerText.startsWith('$ai ') || lowerText === '$ai') {
    const question = rawText.slice(3).trim()
    if (!question) {
      safeChat('Usage: $ai <question>')
      return
    }
    if (onAiCooldown('mc:' + username.toLowerCase())) return
    const aiAnswer = await askGroqAI(question, username, isBossName(username) ? 'boss' : isRoastWorthy(question) ? 'roast' : 'normal')
    safeChat(aiAnswer)
    return
  }

  // < <question>  (old style, same behavior)
  if (rawText.startsWith('<')) {
    const prompt = rawText.slice(1).trim()
    if (!prompt) {
      safeChat('Usage: < <question>')
      return
    }
    if (onAiCooldown('mc:' + username.toLowerCase())) return
    const aiAnswer = await askGroqAI(prompt, username, isBossName(username) ? 'boss' : 'normal')
    safeChat(aiAnswer)
    return
  }

  // In-game giveaway commands: ~pvp 10 PlayerName (Only listens to 'meseju' and '6b6tmalware')
  if (/^\$give(\s|$)/i.test(rawText)) {
    if (!isOwner) return

    const parts = rawText.replace(/^\$give/i, '').trim().split(/\s+/)
    const kit = parts[0] ? parts[0].toUpperCase() : null

    let amount = 1
    let targetUsername = null

    if (parts.length >= 3) {
      const arg1 = parts[1]
      const arg2 = parts[2]
      if (!isNaN(parseInt(arg1))) {
        amount = parseInt(arg1)
        targetUsername = arg2
      } else if (!isNaN(parseInt(arg2))) {
        amount = parseInt(arg2)
        targetUsername = arg1
      } else {
        targetUsername = arg1
      }
    } else if (parts.length === 2) {
      targetUsername = parts[1]
    }

    if (!kit || !targetUsername) {
      safeChat('/msg ' + username + ' Usage: $give <kit> <amount> <player>')
      return
    }

    if (!/^[A-Z0-9_]{1,20}$/.test(kit)) {
      safeChat('/msg ' + username + ' Invalid kit name! Use the exact text on the chest sign.')
      return
    }

    if (!Number.isInteger(amount) || amount < 1 || amount > MAX_KITS_PER_ORDER) {
      safeChat('/msg ' + username + ' You can get a maximum of ' + MAX_KITS_PER_ORDER + ' kits at a time (amount 1 to ' + MAX_KITS_PER_ORDER + ').')
      return
    }

    safeChat('/msg ' + username + ' Giveaway processing: ' + amount + 'x ' + kit + ' for ' + targetUsername + '...')
    handleKitDelivery(targetUsername, kit, amount, (msg) => safeChat('/msg ' + username + ' ' + msg), true, username)
      .catch(e => log('Giveaway error: ' + e.message))
    return
  }

  if (lowerText === '$bed') {
    handleBedCommand((msg) => safeChat('/msg ' + username + ' ' + msg))
    return
  }

  if (!isOwner) return

  if (lowerText === '$follow') {
    const targetPlayer = bot.players[username] && bot.players[username].entity
    if (!targetPlayer) {
      safeChat('I cannot see you to follow.')
      return
    }
    log('Following player: ' + username)
    safeChat('Following you!')
    bot.pathfinder.setGoal(new goals.GoalFollow(targetPlayer, 2), true)
  }
  else if (lowerText === '$stop') {
    log('Stopping all actions / pathfinder')
    if (attackInterval) {
      clearInterval(attackInterval)
      attackInterval = null
    }
    bot.pathfinder.stop()
    bot.clearControlStates()
    safeChat('Stopped.')
  }
  else if (lowerText === '$eat') {
    const foodItem = bot.inventory.items().find(item =>
      item.foodPoints > 0 ||
      item.name.includes('apple') ||
      item.name.includes('carrot') ||
      item.name.includes('bread') ||
      item.name.includes('beef') ||
      item.name.includes('porkchop') ||
      item.name.includes('mutton') ||
      item.name.includes('chicken')
    )
    if (!foodItem) {
      safeChat('No food found in inventory!')
      return
    }
    try {
      await bot.equip(foodItem, 'hand')
      await bot.consume()
      safeChat('Ate ' + foodItem.name + '!')
    } catch (e) {
      safeChat('Failed to eat: ' + e.message)
    }
  }
  else if (lowerText.startsWith('$kill ') || lowerText.startsWith('$attack ')) {
    const targetName = rawText.split(/\s+/)[1]
    if (!targetName) {
      safeChat('Usage: $kill <player>')
      return
    }
    const targetEntity = bot.players[targetName] && bot.players[targetName].entity
    if (!targetEntity) {
      safeChat('Player ' + targetName + ' not found nearby.')
      return
    }
    log('Attacking player: ' + targetName)
    safeChat('Attacking ' + targetName + '!')
    bot.pathfinder.setGoal(new goals.GoalFollow(targetEntity, 1), true)

    // clear any previous attack loop so timers never stack
    if (attackInterval) clearInterval(attackInterval)

    attackInterval = setInterval(() => {
      const currentTarget = bot.players[targetName] && bot.players[targetName].entity
      if (!currentTarget) {
        clearInterval(attackInterval)
        attackInterval = null
        return
      }
      if (bot.entity.position.distanceTo(currentTarget.position) > 4) return
      try {
        bot.attack(currentTarget)
      } catch (e) {}
    }, 500)
  }
}

function createBot() {
  const host = SERVERS[serverIndex % SERVERS.length]
  log('Connecting to ' + host + ' as ' + USERNAME + ' (MC ' + VERSION + ')...')
  minecraftOnline = false
  awaitingLogin = false
  dropped = new Set()

  bot = mineflayer.createBot({
    host,
    port: 25565,
    username: USERNAME,
    auth: 'offline',
    version: VERSION,
    physicsEnabled: false,
    checkTimeoutInterval: 60000,
    hideErrors: true,
    logErrors: false
  })

  guardClient(bot._client)
  guardRegistry(bot)
  bot.loadPlugin(pathfinder)

  bot.on('login', () => {
    awaitingLogin = false
    log('Play login (server hop / join)')
  })

  bot.on('spawn', async () => {
    log('Spawned')
    clearBusy()
    minecraftOnline = true
    setTimeout(notifyOwnerOnline, 7000)

    try {
      const mcData = minecraftData(bot.version)
      const move = new Movements(bot, mcData)
      bot.pathfinder.setMovements(move)
    } catch {}

    await sleep(2000)
    try { bot.physicsEnabled = true } catch {}

    await sleep(1000)
    safeChat('/login ' + PASSWORD)
    log('Sent /login')

    await sleep(5000)
    await walkForwardDistance(15, 15000)
    await sleep(3000)
    await walkForwardDistance(13, 10000)
    log('Finished moving - ready')
  })

  bot.on('chat', (u, msg) => {
    if (u === bot.username) return
    log('[CHAT] <' + u + '> ' + msg)
    handleInGameChat(u, msg).catch(e => log('Chat handler error: ' + (e && e.message)))
  })

  bot.on('messagestr', msg => {
    log('[SERVER] ' + msg)
    handleTpRequest(msg)

    const lower = msg.toLowerCase()
    if (lower.includes('please login') || lower.includes('/login ')) {
      safeChat('/login ' + PASSWORD)
      log('Re-sent /login (prompt)')
    }
  })

  bot.on('kicked', reason => {
    const text = typeof reason === 'string' ? reason : JSON.stringify(reason)
    log('[KICKED] ' + text)
    clearBusy()
    minecraftOnline = false
  })

  bot.on('end', reason => {
    log('Disconnected -> reconnecting in 15s')
    clearBusy()
    if (attackInterval) {
      clearInterval(attackInterval)
      attackInterval = null
    }
    minecraftOnline = false
    serverIndex++
    setTimeout(createBot, 15000)
  })

  bot.on('error', err => {
    const msg = err && err.message ? err.message : String(err)
    if (isIgnorableError(msg)) return
    log('Error: ' + msg)
    clearBusy()
  })
}

function connectDiscord() {
  if (!DISCORD_TOKEN || DISCORD_TOKEN.includes('PASTE_')) {
    log('Discord token missing; Discord bot disabled')
    return
  }
  if (discordClient.isReady() || discordLoginInProgress) return
  discordLoginInProgress = true
  discordClient.login(DISCORD_TOKEN)
    .then(() => { discordLoginInProgress = false })
    .catch(err => {
      discordLoginInProgress = false
      log('Discord login error: ' + err.message)
      if (discordReconnectTimer) clearTimeout(discordReconnectTimer)
      discordReconnectTimer = setTimeout(connectDiscord, 15000)
    })
}

discordClient.on('error', err => {
  log('Discord error: ' + err.message)
  if (discordReconnectTimer) clearTimeout(discordReconnectTimer)
  discordReconnectTimer = setTimeout(connectDiscord, 15000)
})

discordClient.on('messageCreate', async message => {
  try {
    if (message.author.bot) return
    const content = message.content.trim()
    const lowerContent = content.toLowerCase()
    const userId = message.author.id

    updateFavoritePerson(message.author.username, content)

    // Every new user starts with 2 Cat Coins
    if (userBalances[userId] === undefined) {
      userBalances[userId] = 2
      saveData()
    }

    // !ai <question> (works in any channel the bot can read)
    // "who am i" / "my stats" use the Minecraft name they registered, if any
    if (lowerContent.startsWith('$ai ') || lowerContent === '$ai') {
      const question = content.slice(3).trim()
      if (!question) {
        await message.reply('⚠️ Usage: `$ai <question>`')
        return
      }
      if (onAiCooldown('dc:' + userId)) return
      try { await message.channel.sendTyping() } catch {}
      const asker = registrations[userId] || message.author.username
      const aiAnswer = await askGroqAI(question, asker, isBossName(registrations[userId]) ? 'boss' : isRoastWorthy(question) ? 'roast' : 'normal')
      await message.reply('💬 ' + aiAnswer)
      return
    }

    // $bal / $balance  (works in ANY channel the bot can read)
    if (['$bal', '$balance'].includes(lowerContent)) {
      const reg = registrations[userId]
      await message.reply('💰 You currently have **' + userBalances[userId] + ' Cat Coins**. ' +
        (reg ? 'Registered as **' + reg + '**.' : 'You are not registered yet, use `$register <your minecraft name>`.'))
      return
    }

    // $close  |  $close refund   -> staff only, only inside a shop ticket channel
    if (/^\$close(\s|$)/i.test(content)) {
      const ticket = TICKETS[message.channel.id]
      if (!ticket) {
        await message.reply('⚠️ This command only works inside an open shop ticket.')
        return
      }
      if (!ADMIN_IDS.includes(userId) && !isKitAdmin(userId)) {
        await message.reply('❌ Only admins can close tickets.')
        return
      }

      const refund = /\brefund\b/i.test(content)
      // no await before this point changes anything, so a ticket can never be refunded twice
      delete TICKETS[message.channel.id]
      if (refund) {
        if (userBalances[ticket.userId] === undefined) userBalances[ticket.userId] = 2
        userBalances[ticket.userId] += ticket.price
        if (SHOP_ITEMS[ticket.item]) SHOP_ITEMS[ticket.item].stock += 1
      }
      saveData()

      await message.reply(refund
        ? '✅ Ticket #' + ticket.number + ' closed. **' + ticket.price + ' Cat Coins** were refunded to <@' + ticket.userId + '>. This channel will be deleted in 10 seconds.'
        : '✅ Ticket #' + ticket.number + ' closed. This channel will be deleted in 10 seconds.')

      try {
        const shopChannel = await discordClient.channels.fetch(SHOP_CHANNEL_ID)
        if (shopChannel) {
          await shopChannel.send('🎫 Ticket #' + ticket.number + ' (<@' + ticket.userId + '>, **' + ticket.item + '**) was closed by **' + message.author.username + '**' + (refund ? ' with a refund.' : '.'))
        }
      } catch (e) {
        log('Ticket close log error: ' + e.message)
      }

      const channelToDelete = message.channel
      setTimeout(() => { channelToDelete.delete().catch(() => {}) }, 10000)
      return
    }

    // $stock shop  -> same listing as $shop (shop channel only)
    // $stock kit   -> walks to every kit chest and counts real shulker stock (slower, any channel)
    if (/^\$stock(\s|$)/i.test(content)) {
      const which = content.replace(/^\$stock/i, '').trim().toLowerCase()

      if (which === 'shop' || !which) {
        if (message.channel.id !== SHOP_CHANNEL_ID) {
          await message.reply('🎁 The shop is in <#' + SHOP_CHANNEL_ID + '>, use `$shop` there.')
          return
        }
        await replyShop(message)
        return
      }

      if (which === 'kit') {
        if (!bot || !minecraftOnline) {
          await message.reply('⚠️ Minecraft bot is offline right now.')
          return
        }
        if (busy) {
          await message.reply('⏳ Bot is busy right now, try `$stock kit` again in a moment.')
          return
        }
        await message.reply('🔍 Checking kit chests in game, this may take a moment...')
        setBusy()
        try {
          const counts = await getKitStockCounts()
          if (!counts.length) {
            await message.channel.send('No kit chests found right now.')
            return
          }
          const embed = new EmbedBuilder()
            .setColor('#2ECC71')
            .setTitle('📦 Kit Stock (live count)')
            .addFields(counts.slice(0, 25).map(k => ({ name: k.name, value: String(k.count) + ' shulker(s)', inline: true })))
          await message.channel.send({ embeds: [embed] })
        } catch (e) {
          await message.channel.send('⚠️ Error checking kit stock: ' + e.message)
        } finally {
          clearBusy()
        }
        return
      }

      await message.reply('⚠️ Usage: `$stock shop` or `$stock kit`')
      return
    }

    // ================= COSMETIC SHOP COMMANDS (SHOP_CHANNEL_ID only) =================
    // $shop (no args)                        -> anyone: lists every cosmetic key, price and stock
    // $shop add <stock> <cost|auto> <name>   -> kit admins only
    // $shop stock <amount> <name>            -> kit admins only
    // $shop price <amount|auto> <name>       -> kit admins only
    // $shop remove <name>                    -> kit admins only
    // $redeem <name>                         -> anyone: spend Cat Coins on a key (staff delivers it)
    if (/^\$shop(\s|$)/i.test(content)) {
      if (message.channel.id !== SHOP_CHANNEL_ID) {
        await message.reply('🎁 The shop is in <#' + SHOP_CHANNEL_ID + '>, use `$shop` there.')
        return
      }

      const argsStr = content.replace(/^\$shop/i, '').trim()
      const tokens = argsStr ? argsStr.split(/\s+/) : []
      const sub = (tokens[0] || '').toLowerCase()
      const adminSubs = ['add', 'create', 'stock', 'setstock', 'price', 'setprice', 'remove', 'delete', 'del']

      if (!argsStr || !adminSubs.includes(sub)) {
        await replyShop(message)
        return
      }

      if (!isKitAdmin(userId)) {
        await message.reply('❌ Only kit admins can manage the shop.')
        return
      }

      if (sub === 'add' || sub === 'create') {
        const stock = parseInt(tokens[1], 10)
        const costArg = tokens[2]
        const name = tokens.slice(3).join(' ')
        if (!Number.isInteger(stock) || stock < 0 || !name) {
          await message.reply('⚠️ Usage: `$shop add <stock> <cost|auto> <item name>`\nExample: `$shop add 25 auto Netherite Cape` or `$shop add 25 150 Netherite Cape`')
          return
        }
        if (findShopItem(name)) {
          await message.reply('❌ **' + findShopItem(name) + '** already exists in the shop.')
          return
        }
        const entry = { stock }
        if (costArg && costArg.toLowerCase() !== 'auto') {
          const cost = parseInt(costArg, 10)
          if (!Number.isInteger(cost) || cost < 1) {
            await message.reply('❌ Cost must be a whole number, or "auto" to price it by scarcity.')
            return
          }
          entry.costOverride = cost
        }
        SHOP_ITEMS[name] = entry
        saveData()
        await message.reply('✅ Added **' + name + '** — stock **' + stock + '**, price **' + shopPriceOf(entry) + '** Cat Coins.')
        return
      }

      if (sub === 'stock' || sub === 'setstock') {
        const amount = parseInt(tokens[1], 10)
        const itemName = findShopItem(tokens.slice(2).join(' '))
        if (!itemName || !Number.isInteger(amount) || amount < 0) {
          await message.reply('⚠️ Usage: `$shop stock <amount> <item name>`')
          return
        }
        SHOP_ITEMS[itemName].stock = amount
        saveData()
        await message.reply('✅ **' + itemName + '** stock set to **' + amount + '** (price now **' + shopPriceOf(SHOP_ITEMS[itemName]) + '** unless overridden).')
        return
      }

      if (sub === 'price' || sub === 'setprice') {
        const priceArg = tokens[1]
        const itemName = findShopItem(tokens.slice(2).join(' '))
        if (!itemName || !priceArg) {
          await message.reply('⚠️ Usage: `$shop price <amount|auto> <item name>`')
          return
        }
        if (priceArg.toLowerCase() === 'auto') {
          delete SHOP_ITEMS[itemName].costOverride
          saveData()
          await message.reply('✅ **' + itemName + '** price reset to automatic (**' + computeShopPrice(SHOP_ITEMS[itemName].stock) + '** right now).')
          return
        }
        const cost = parseInt(priceArg, 10)
        if (!Number.isInteger(cost) || cost < 1) {
          await message.reply('❌ Cost must be a whole number, or "auto".')
          return
        }
        SHOP_ITEMS[itemName].costOverride = cost
        saveData()
        await message.reply('✅ **' + itemName + '** price set to **' + cost + '** Cat Coins.')
        return
      }

      if (sub === 'remove' || sub === 'delete' || sub === 'del') {
        const itemName = findShopItem(tokens.slice(1).join(' '))
        if (!itemName) {
          await message.reply('⚠️ Usage: `$shop remove <item name>`')
          return
        }
        delete SHOP_ITEMS[itemName]
        saveData()
        await message.reply('✅ Removed **' + itemName + '** from the shop.')
        return
      }
    }

    if (/^\$redeem(\s|$)/i.test(content)) {
      if (message.channel.id !== SHOP_CHANNEL_ID) {
        await message.reply('🎁 Redeem shop items in <#' + SHOP_CHANNEL_ID + '>.')
        return
      }

      const query = content.replace(/^\$redeem/i, '').trim()
      if (!query) {
        await message.reply('⚠️ Usage: `$redeem <item name>` — see `$shop` for the list.')
        return
      }
      const itemName = findShopItem(query)
      if (!itemName) {
        await message.reply('❌ Could not find a shop item matching "' + query + '". Check `$shop` for exact names.')
        return
      }
      const item = SHOP_ITEMS[itemName]
      const price = shopPriceOf(item)

      if (item.stock <= 0) {
        await message.reply('❌ **' + itemName + '** is sold out.')
        return
      }
      if (userBalances[userId] === undefined) userBalances[userId] = 2
      if (userBalances[userId] < price) {
        await message.reply('❌ Not enough Cat Coins! **' + itemName + '** costs **' + price + '**, you have **' + userBalances[userId] + '**.')
        return
      }

      // no await between the checks and the write, so it can't double-spend or oversell
      userBalances[userId] -= price
      item.stock -= 1
      saveData()

      // coins are taken, now open the private ticket so staff can hand over the key
      let ticketChannel = null
      try {
        ticketChannel = await createShopTicket({
          guild: message.guild,
          userId,
          username: message.author.username,
          itemName,
          price
        })
      } catch (e) {
        log('Ticket creation failed: ' + e.message)
      }

      if (!ticketChannel) {
        // never keep the money if no ticket exists: give everything back
        userBalances[userId] += price
        if (SHOP_ITEMS[itemName] === item) item.stock += 1
        saveData()
        await message.reply('❌ I could not create your ticket, so nothing was charged (balance: **' + userBalances[userId] + '**). Please tell an admin: the bot needs **Manage Channels** and **Manage Roles** permissions.')
        return
      }

      await message.reply('✅ Redeemed **' + itemName + '** for **' + price + '** Cat Coins! New balance: **' + userBalances[userId] + '**.\n🎫 Your ticket is open: <#' + ticketChannel.id + '>. Staff will send your key there.')
      return
    }
    // ================= END COSMETIC SHOP COMMANDS =================

    // $register <minecraft name>  (works in any channel the bot can read)
    if (/^\$register(\s|$)/i.test(content)) {
      const name = content.split(/\s+/)[1]
      if (!name) {
        await message.reply('⚠️ Usage: `$register <your minecraft name>` (example: `$register 6b6tmalware`)')
        return
      }
      const result = registerPlayer(userId, name)
      if (!result.ok) {
        await message.reply(result.error === 'taken'
          ? '❌ **' + name + '** is already registered by another Discord account. Ask an admin to use `$unregister ' + name + '`.'
          : '❌ That is not a valid Minecraft name. Use 3 to 16 letters, numbers or underscores.')
        return
      }
      await message.reply('✅ Registered as **' + name + '**' +
        (result.previous && result.previous !== name ? ' (changed from **' + result.previous + '**)' : '') +
        '. Now use `$order pvp 2` here, or `$kit pvp 2` in game chat. Coins are taken from your Discord balance.')
      return
    }

    // $unregister  (yourself)   or   $unregister <minecraft name>  (admins only)
    if (/^\$unregister(\s|$)/i.test(content)) {
      const name = content.split(/\s+/)[1]
      if (!name) {
        if (!registrations[userId]) {
          await message.reply('⚠️ You are not registered.')
          return
        }
        const old = registrations[userId]
        delete registrations[userId]
        saveData()
        await message.reply('✅ **' + old + '** has been unregistered from your account.')
        return
      }
      if (!ADMIN_IDS.includes(userId)) {
        await message.reply('❌ Only admins can unregister other names.')
        return
      }
      const owner = findRegistrantByMcName(name)
      if (!owner) {
        await message.reply('⚠️ **' + name + '** is not registered.')
        return
      }
      delete registrations[owner]
      saveData()
      await message.reply('✅ **' + name + '** was unregistered from <@' + owner + '>.')
      return
    }

    // ============================================================================
    // \pay @user <amount>  - sends YOUR Cat Coins to that person. Works in ANY channel.
    // Also: \share, \give, \send, and the same words with a dot (.pay @meseju 15)
    // ============================================================================
    if (/^\$(pay|share|give|send)(\s|$)/i.test(content)) {
      const args = content.replace(/^\$(pay|share|give|send)/i, '').trim().split(/\s+/).filter(Boolean)
      if (args.length < 2) {
        await message.reply('⚠️ Usage: `$pay @user <amount>` (example: `$pay @meseju 15`)')
        return
      }

      // allow both "/pay @meseju 15" and "/pay 15 @meseju"
      let who = args[0]
      let amountText = args[1]
      if (/^\d+$/.test(who) && !/^\d+$/.test(amountText)) {
        who = args[1]
        amountText = args[0]
      }

      // who gets the coins: a real @ping, a Discord ID, a registered Minecraft name, or a typed name
      let toId = null
      const ping = who.match(/^<@!?(\d+)>$/)
      if (ping) {
        toId = ping[1]
      } else if (/^\d{17,20}$/.test(who)) {
        toId = who
      } else {
        const plain = who.replace(/^@/, '')
        toId = findRegistrantByMcName(plain)
        if (!toId && message.guild) {
          try {
            const found = await message.guild.members.search({ query: plain, limit: 1 })
            const member = found.first()
            if (member) toId = member.id
          } catch (e) {}
        }
      }

      if (!toId) {
        await message.reply('❌ I could not find that user. Ping them with @ (pick them from the list), or use a Minecraft name that is registered.')
        return
      }

      let target = null
      try { target = await discordClient.users.fetch(toId) } catch (e) {}
      if (!target) {
        await message.reply('❌ I could not find that Discord user.')
        return
      }
      if (target.bot) {
        await message.reply('❌ You cannot send coins to a bot.')
        return
      }

      const amount = /^\d+$/.test(amountText) ? Number(amountText) : NaN
      const result = transferCoins(userId, toId, amount)
      if (!result.ok) {
        await message.reply(result.error === 'self' ? '❌ You cannot send coins to yourself.'
          : result.error === 'funds' ? '❌ Not enough coins! You only have **' + result.balance + ' Cat Coins**.'
          : '❌ Amount must be a whole number of 1 or more.')
        return
      }

      await message.reply('💸 You sent **' + amount + ' Cat Coins** to <@' + toId + '>. Your new balance: **' + result.fromBalance + ' coins**.')

      // if it happened outside the economy channel, leave a log there so admins can see it
      if (message.channel.id !== ECONOMY_CHANNEL_ID) {
        try {
          const logChannel = await discordClient.channels.fetch(ECONOMY_CHANNEL_ID)
          if (logChannel) await logChannel.send('💸 **' + message.author.username + '** sent **' + amount + ' Cat Coins** to <@' + toId + '>.')
        } catch (e) {}
      }
      return
    }

    // GAMBLE CHANNEL — player 45% win / house 55%. Bet is doubled on win, lost on fail.
    if (message.channel.id === GAMBLE_CHANNEL_ID) {
      // help
      if (
        lowerContent === '$gamble' ||
        lowerContent === '$gamble help'
      ) {
        await message.reply(
          '🎰 **Cat Coin Gamble**\n' +
          '• Your win rate: **45%** · House: **55%**\n' +
          '• Win → get **2×** your bet back (net +bet)\n' +
          '• Lose → you lose the bet\n' +
          '• Bet range: **' + GAMBLE_MIN_BET + '–' + GAMBLE_MAX_BET + '** Cat Coins\n\n' +
          '**Play:** `$gamble <amount>`\n' +
          'Example: `$gamble 5`'
        )
        return
      }

      const gambleMatch = content.match(/^\$gamble\s+(\d+)\s*$/i)
      if (gambleMatch) {
        if (onGambleCooldown(userId)) {
          await message.reply('⏳ Slow down — wait a few seconds between gambles.')
          return
        }

        const amount = parseInt(gambleMatch[1], 10)
        const result = runGamble(userId, amount)

        if (!result.ok) {
          if (result.error === 'min') {
            await message.reply('❌ Minimum bet is **' + GAMBLE_MIN_BET + '** Cat Coin.')
          } else if (result.error === 'max') {
            await message.reply('❌ Maximum bet is **' + GAMBLE_MAX_BET + '** Cat Coins per flip.')
          } else if (result.error === 'funds') {
            await message.reply('❌ Not enough coins! You have **' + result.balance + '**, tried to bet **' + amount + '**.')
          } else {
            await message.reply('❌ Could not place that bet.')
          }
          return
        }

        if (result.win) {
          await message.reply(
            '🟢 **YOU WIN** +' + result.amount + ' Cat Coins!\n' +
            result.line + '\n' +
            'Bet: **' + result.amount + '** → paid **' + (result.amount * 2) + '**. Balance: **' + result.balance + '**'
          )
        } else {
          await message.reply(
            '🔴 **YOU LOSE** −' + result.amount + ' Cat Coins.\n' +
            result.line + '\n' +
            'Balance: **' + result.balance + '**'
          )
        }
        return
      }

      // ignore other messages in gamble channel
      return
    }

    // DAILY LOGIN CHANNEL
    if (message.channel.id === DAILY_CHANNEL_ID) {
      if (['$login', '$claim'].includes(lowerContent)) {
        const today = new Date().toISOString().slice(0, 10) // YYYY-MM-DD
        if (lastDailyClaim[userId] === today) {
          await message.reply('⏳ You have already claimed your daily reward today! Come back tomorrow.')
          return
        }

        lastDailyClaim[userId] = today
        userBalances[userId] += 5
        saveData()
        await message.reply('🎁 Daily reward claimed! Added **5 Cat Coins**. New balance: **' + userBalances[userId] + ' coins**.')
        return
      }
    }

    // KIT ORDER & ECONOMY CHANNEL
    if (message.channel.id === ECONOMY_CHANNEL_ID) {
      // $order <kit> <amount>  (delivers to the Minecraft name you registered)
      if (/^\$order(\s|$)/i.test(content)) {
        const mcName = registrations[userId]
        if (!mcName) {
          await message.reply('❌ You are not registered! Use `$register <your minecraft name>` first (example: `$register 6b6tmalware`).')
          return
        }

        const args = content.replace(/^\$order/i, '').trim().split(/\s+/).filter(Boolean)
        if (args.length === 0) {
          await message.reply('⚠️ Usage: `$order <kit> <amount>` (example: `$order pvp 2`). `<kit>` is the exact text on the chest sign in game — any sign name works.')
          return
        }

        const { kitInput, amountInput } = parseOrderArgs(args)
        const send = async text => {
          try { await message.channel.send(text) } catch (e) {}
        }
        await processOrder({ discordId: userId, mcName, kitInput, amountInput, replyFn: send, source: 'discord', tag: '<@' + userId + '> ' })
        return
      }
    }

    // Admin only: .add @user <coins>  (works in any channel the bot can read)
    if (lowerContent.startsWith('$add ') && !/^\$add\s+admin(\s|$)/i.test(content)) {
      if (!ADMIN_IDS.includes(userId)) {
        await message.reply('❌ You are not authorized to use the admin add command.')
        return
      }
      const parts = content.slice(5).trim().split(/\s+/)
      const addCoins = parseInt(parts[parts.length - 1])
      const mentioned = message.mentions.users.first()

      // must mention a user (it no longer silently credits the admin)
      if (!mentioned || isNaN(addCoins)) {
        await message.reply('⚠️ Usage: `$add <@user> <coins>`')
        return
      }

      const targetDiscordId = mentioned.id
      if (userBalances[targetDiscordId] === undefined) userBalances[targetDiscordId] = 2
      userBalances[targetDiscordId] += addCoins
      saveData()

      await message.reply('✅ Added **' + addCoins + ' Cat Coins** to <@' + targetDiscordId + '>. New balance: **' + userBalances[targetDiscordId] + ' coins**.')
      return
    }

    // $add admin @user  |  $remove admin @user  |  /admins
    // Only the two kit admins can promote/demote bot admins
    if (/^\$(add\s+admin|remove\s+admin|admins)(\s|$)/i.test(content)) {
      const addMatch = content.match(/^\$add\s+admin(\s|$)/i)
      const removeMatch = content.match(/^\$remove\s+admin(\s|$)/i)
      const listMatch = content.match(/^\$admins\s*$/i)

      if (listMatch) {
        if (!isKitAdmin(userId) && !ADMIN_IDS.includes(userId)) {
          await message.reply('❌ Not authorized.')
          return
        }
        const lines = ADMIN_IDS.map(id => {
          const tag = KIT_ADMIN_IDS.includes(id) ? ' (kit admin)' : (DEFAULT_ADMIN_IDS.includes(id) ? ' (built-in)' : ' (added)')
          return '• <@' + id + '>' + tag
        })
        await message.reply('👑 **Bot admins**\n' + lines.join('\n'))
        return
      }

      if (!isKitAdmin(userId)) {
        await message.reply('❌ Only kit admins can add or remove bot admins.')
        return
      }

      const mentioned = message.mentions.users.first()
      if (!mentioned) {
        await message.reply(addMatch
          ? '⚠️ Usage: `$add admin @user`'
          : '⚠️ Usage: `$remove admin @user`')
        return
      }

      const targetId = mentioned.id
      if (mentioned.bot) {
        await message.reply('❌ You cannot make a bot an admin.')
        return
      }

      if (addMatch) {
        if (ADMIN_IDS.includes(targetId)) {
          await message.reply('⚠️ <@' + targetId + '> is already a bot admin.')
          return
        }
        extraAdminIds.push(targetId)
        rebuildAdminIds()
        saveData()
        await message.reply('✅ <@' + targetId + '> is now a **bot admin** (can use admin commands). Kit list is still only editable by kit admins.')
        return
      }

      if (removeMatch) {
        if (DEFAULT_ADMIN_IDS.includes(targetId) || KIT_ADMIN_IDS.includes(targetId)) {
          await message.reply('❌ You cannot remove a built-in / kit admin.')
          return
        }
        if (!extraAdminIds.includes(targetId)) {
          await message.reply('⚠️ <@' + targetId + '> is not an added admin.')
          return
        }
        extraAdminIds = extraAdminIds.filter(id => id !== targetId)
        rebuildAdminIds()
        saveData()
        await message.reply('✅ <@' + targetId + '> was removed from bot admins.')
        return
      }
    }

    // $kit list | $kit arrange <KIT> <shulker> | $kit add <KIT> <shulker> [cost] | $kit remove <KIT>
    // Only KIT_ADMIN_IDS can manage kits. Works in any channel the bot can read.
    if (/^\$kit(\s|$)/i.test(content)) {
      if (!isKitAdmin(userId)) {
        await message.reply('❌ Only kit admins can manage the kit list.')
        return
      }

      const kitArgs = content.replace(/^\$kit/i, '').trim().split(/\s+/).filter(Boolean)
      const sub = (kitArgs[0] || 'list').toLowerCase()

      if (sub === 'list' || sub === 'ls' || sub === 'show') {
        const overrides = Object.keys(KIT_RULES)
        const lines = overrides.length
          ? overrides.map(name => '• **' + name + '** → cost ' + (KIT_RULES[name].cost || DEFAULT_KIT_COST))
          : ['(no cost overrides set)']
        await message.reply('📦 **Kits**\nAny chest with a sign works as a kit — whatever the sign says is the kit name (`PVP`, `CPVP2`, `REDSTONE`, anything). Default cost: **' + DEFAULT_KIT_COST + '**.\n\n**Cost overrides:**\n' + lines.join('\n') +
          '\n\n`$kit add RAID 5` sets a custom cost for "RAID" · `$kit remove RAID` clears it back to default\nUndelivered shulkers are returned to the chest whose sign says "' + RANDOM_CHEST_SIGN + '".')
        return
      }

      if (sub === 'add' || sub === 'create') {
        const kitName = (kitArgs[1] || '').toUpperCase()
        const costArg = kitArgs[2]
        if (!kitName || costArg === undefined) {
          await message.reply('⚠️ Usage: `$kit add <KIT> <cost>`\nExample: `$kit add RAID 5` sets a custom cost for the "RAID" sign (any kit works without this — it just sets the price).')
          return
        }
        if (!/^[A-Z][A-Z0-9_]{1,19}$/.test(kitName)) {
          await message.reply('❌ Kit name must be letters/numbers/underscore (2–20 chars), e.g. `RAID` or `CPVP2`.')
          return
        }
        const cost = parseInt(costArg, 10)
        if (!Number.isInteger(cost) || cost < 1 || cost > 100) {
          await message.reply('❌ Cost must be a whole number from 1 to 100.')
          return
        }
        KIT_RULES[kitName] = { cost }
        saveData()
        await message.reply('✅ **' + kitName + '** now costs **' + cost + '** per kit (make sure a chest has a sign that says "' + kitName + '").')
        return
      }

      if (sub === 'remove' || sub === 'delete' || sub === 'del') {
        const kitName = (kitArgs[1] || '').toUpperCase()
        if (!kitName) {
          await message.reply('⚠️ Usage: `$kit remove <KIT>`')
          return
        }
        if (!KIT_RULES[kitName]) {
          await message.reply('❌ **' + kitName + '** has no cost override set. (It still works as a kit at the default cost of ' + DEFAULT_KIT_COST + '.)')
          return
        }
        delete KIT_RULES[kitName]
        saveData()
        await message.reply('✅ **' + kitName + '** cost override removed. It now costs the default **' + DEFAULT_KIT_COST + '**.')
        return
      }

      await message.reply('⚠️ Kit commands:\n`$kit list`\n`$kit add <KIT> <cost>` — set a custom cost for a sign name\n`$kit remove <KIT>` — clear a custom cost back to default')
      return
    }

    // BOT COMMANDS CHANNEL (admins only)
    if (message.channel.id === BOT_CMD_CHANNEL_ID) {
      if (!ADMIN_IDS.includes(userId)) {
        await message.reply('❌ You are not authorized to use bot command channel controls.')
        return
      }

      if (lowerContent.startsWith('$cmd ')) {
        const mcCommand = content.slice(5).trim()
        if (!mcCommand.startsWith('/')) {
          await message.reply('⚠️ Minecraft commands must start with `/` (e.g., `$cmd /tpa 6b6tmalware`)')
          return
        }
        if (!bot || !minecraftOnline) {
          await message.reply('⚠️ Minecraft bot is offline right now.')
          return
        }
        safeChat(mcCommand)
        await message.reply('✅ Executed in-game: `' + mcCommand + '`')
        return
      }

      if (lowerContent === '$bed') {
        if (!bot || !minecraftOnline) {
          await message.reply('⚠️ Minecraft bot is offline right now.')
          return
        }
        await message.reply('🛌 Finding and using nearby bed...')
        const replyFn = async (text) => {
          try { await message.channel.send(text) } catch (e) {}
        }
        await handleBedCommand(replyFn)
        return
      }

      if (lowerContent.startsWith('$blackcat ')) {
        const prompt = content.slice(10).trim()
        if (!prompt) {
          await message.reply('⚠️ Usage: `$blackcat <question>`')
          return
        }

        await message.reply('🤖 Generating AI response via Groq AI...')
        const aiResponse = await askGroqAI(prompt, message.author.username)

        await message.channel.send('💬 **AI Output:** ' + aiResponse)
        if (bot && minecraftOnline) {
          safeChat(aiResponse)
        }
        return
      }
    }
  } catch (e) {
    log('Discord command error: ' + e.message)
  }
})

connectDiscord()
createBot()